package Modelo;

public class Producto {
    public String codigo;
    public String nombre;
    public String tipo;
    public int puntos;

    public Producto() {}

    public Producto(String codigo, String nombre, String tipo, int puntos) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipo = tipo;
        this.puntos = puntos;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public int getPuntos() { return puntos; }
    public void setPuntos(int puntos) { this.puntos = puntos; }

    @Override
    public String toString() {
        return nombre + " [" + tipo + "] - " + puntos + " pts";
    }
}
