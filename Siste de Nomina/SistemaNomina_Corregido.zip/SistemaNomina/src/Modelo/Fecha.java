package Modelo;

public class Fecha {
    private int dia;
    private int mes;
    private int anio;

    public Fecha() {}

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public int getDia() { return dia; }
    public void setDia(int dia) { this.dia = dia; }

    public int getMes() { return mes; }
    public void setMes(int mes) { this.mes = mes; }

    public int getAnio() { return anio; }
    public void setAnio(int anio) { this.anio = anio; }

    public int calcularAniosDesde(Fecha actual) {
        int anios = actual.anio - this.anio;
        if (actual.mes < this.mes || (actual.mes == this.mes && actual.dia < this.dia)) {
            anios--;
        }
        return Math.max(0, anios);
    }

    @Override
    public String toString() {
        return String.format("%02d/%02d/%04d", dia, mes, anio);
    }
}
