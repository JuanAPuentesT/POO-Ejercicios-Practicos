package Modelo;

public class Ocasional extends Profesor {
    private int tiempoContrato;   // en meses
    private double salarioMes;
    private boolean modalidad;    // true = tiempo completo, false = medio tiempo

    public Ocasional() {}

    public Ocasional(String nip, String codigo, String nombre, String direccion,
                     String email, Fecha fechaVinculacion, String especialidad,
                     int tiempoContrato, double salarioMes, boolean modalidad) {
        super(nip, codigo, nombre, direccion, email, fechaVinculacion, salarioMes, especialidad);
        this.tiempoContrato = tiempoContrato;
        this.salarioMes = salarioMes;
        this.modalidad = modalidad;
        this.salarioBase = modalidad ? salarioMes : salarioMes * 0.5;
    }

    @Override
    public double CalcularSalario() {
        double base = modalidad ? salarioMes : salarioMes * 0.5;
        double descuento = (deduccion != null) ? deduccion.getValor() : 0;
        double bonif = (bonificacion != null) ? bonificacion.getValor() : CalcularBonificacion();
        return base + bonif - descuento;
    }

    public int getTiempoContrato() { return tiempoContrato; }
    public void setTiempoContrato(int tiempoContrato) { this.tiempoContrato = tiempoContrato; }

    public double getSalarioMes() { return salarioMes; }
    public void setSalarioMes(double salarioMes) { this.salarioMes = salarioMes; }

    public boolean isModalidad() { return modalidad; }
    public void setModalidad(boolean modalidad) { this.modalidad = modalidad; }

    @Override
    public String getTipoEmpleado() { return "Ocasional"; }
}
