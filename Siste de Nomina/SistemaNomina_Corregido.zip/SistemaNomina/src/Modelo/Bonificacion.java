package Modelo;

public class Bonificacion {
    private String codigoBonificacion;
    private String descripcion;
    private double valor;

    public Bonificacion() {}

    public Bonificacion(String codigoBonificacion, String descripcion, double valor) {
        this.codigoBonificacion = codigoBonificacion;
        this.descripcion = descripcion;
        this.valor = valor;
    }

    public String getCodigoBonificacion() { return codigoBonificacion; }
    public void setCodigoBonificacion(String codigoBonificacion) { this.codigoBonificacion = codigoBonificacion; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    @Override
    public String toString() {
        return descripcion + " ($" + String.format("%.2f", valor) + ")";
    }
}
