package Modelo;

import java.util.ArrayList;

public class Empleado {
    protected String nip;
    protected String codigo;
    protected String nombre;
    protected String direccion;
    protected String email;
    protected Fecha fechaVinculacion;
    protected double salarioBase;
    protected Deduccion deduccion;

    public Empleado() {}

    public Empleado(String nip, String codigo, String nombre, String direccion,
                    String email, Fecha fechaVinculacion, double salarioBase) {
        this.nip = nip;
        this.codigo = codigo;
        this.nombre = nombre;
        this.direccion = direccion;
        this.email = email;
        this.fechaVinculacion = fechaVinculacion;
        this.salarioBase = salarioBase;
    }

    public double CalcularSalario() {
        double descuento = (deduccion != null) ? deduccion.getValor() : 0;
        return salarioBase - descuento;
    }

    public int CalcularAntiguedad() {
        if (fechaVinculacion == null) return 0;
        Fecha hoy = obtenerFechaActual();
        return fechaVinculacion.calcularAniosDesde(hoy);
    }

    private Fecha obtenerFechaActual() {
        java.time.LocalDate hoy = java.time.LocalDate.now();
        return new Fecha(hoy.getDayOfMonth(), hoy.getMonthValue(), hoy.getYear());
    }

    // Getters y Setters
    public String getNip() { return nip; }
    public void setNip(String nip) { this.nip = nip; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Fecha getFechaVinculacion() { return fechaVinculacion; }
    public void setFechaVinculacion(Fecha fechaVinculacion) { this.fechaVinculacion = fechaVinculacion; }

    public double getSalarioBase() { return salarioBase; }
    public void setSalarioBase(double salarioBase) { this.salarioBase = salarioBase; }

    public Deduccion getDeduccion() { return deduccion; }
    public void setDeduccion(Deduccion deduccion) { this.deduccion = deduccion; }

    public String getTipoEmpleado() { return "Empleado"; }

    @Override
    public String toString() {
        return "[" + getTipoEmpleado() + "] " + nombre + " (Cód: " + codigo + ")";
    }
}
