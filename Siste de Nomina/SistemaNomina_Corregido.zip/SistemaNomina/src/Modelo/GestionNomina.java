package Modelo;

import java.util.ArrayList;

public class GestionNomina {
    public ArrayList<Empleado> empleados;

    public GestionNomina() {
        empleados = new ArrayList<>();
    }

    public void RegistrarEmpleado(Empleado e) {
        empleados.add(e);
    }

    public double CalcularNomina() {
        double total = 0;
        for (Empleado e : empleados) {
            total += e.CalcularSalario();
        }
        return total;
    }

    public ArrayList<Empleado> MostrarEmpleados() {
        return empleados;
    }

    public Empleado buscarPorCodigo(String codigo) {
        for (Empleado e : empleados) {
            if (e.getCodigo().equals(codigo)) return e;
        }
        return null;
    }

    public void eliminarEmpleado(String codigo) {
        empleados.removeIf(e -> e.getCodigo().equals(codigo));
    }
}
