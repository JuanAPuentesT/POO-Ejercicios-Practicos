package Modelo;

public enum TipoDeProyecto {
    INVESTIGACION,
    EXTENSION,
    DOCENCIA;

    @Override
    public String toString() {
        switch (this) {
            case INVESTIGACION: return "Investigación";
            case EXTENSION:     return "Extensión";
            case DOCENCIA:      return "Docencia";
            default:            return name();
        }
    }
}
