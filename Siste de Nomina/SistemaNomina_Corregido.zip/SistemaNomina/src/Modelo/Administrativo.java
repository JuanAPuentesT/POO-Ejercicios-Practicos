package Modelo;

public class Administrativo extends Empleado {
    public Dependencia dependencia;
    public String cargo;

    public Administrativo() {}

    public Administrativo(String nip, String codigo, String nombre, String direccion,
                          String email, Fecha fechaVinculacion, double salarioBase,
                          Dependencia dependencia, String cargo) {
        super(nip, codigo, nombre, direccion, email, fechaVinculacion, salarioBase);
        this.dependencia = dependencia;
        this.cargo = cargo;
    }

    public Dependencia getDependencia() { return dependencia; }
    public void setDependencia(Dependencia dependencia) { this.dependencia = dependencia; }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = cargo; }

    @Override
    public String getTipoEmpleado() { return "Administrativo"; }
}
