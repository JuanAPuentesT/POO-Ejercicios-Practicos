package Modelo;

import java.util.ArrayList;

public class Profesor extends Empleado {
    protected String especialidad;
    protected ArrayList<Asignatura> asignaturas;
    protected ArrayList<Proyecto> proyectos;
    protected Dependencia dependencia;
    protected Bonificacion bonificacion;

    public Profesor() {
        asignaturas = new ArrayList<>();
        proyectos = new ArrayList<>();
    }

    public Profesor(String nip, String codigo, String nombre, String direccion,
                    String email, Fecha fechaVinculacion, double salarioBase, String especialidad) {
        super(nip, codigo, nombre, direccion, email, fechaVinculacion, salarioBase);
        this.especialidad = especialidad;
        this.asignaturas = new ArrayList<>();
        this.proyectos = new ArrayList<>();
    }

    public double CalcularBonificacion() {
        int antiguedad = CalcularAntiguedad();
        double bono = 0;
        if (antiguedad >= 10) bono = salarioBase * 0.15;
        else if (antiguedad >= 5) bono = salarioBase * 0.10;
        else if (antiguedad >= 1) bono = salarioBase * 0.05;
        return bono;
    }

    @Override
    public double CalcularSalario() {
        double descuento = (deduccion != null) ? deduccion.getValor() : 0;
        double bonif = (bonificacion != null) ? bonificacion.getValor() : CalcularBonificacion();
        return salarioBase + bonif - descuento;
    }

    @Override
    public int CalcularAntiguedad() {
        return super.CalcularAntiguedad();
    }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public ArrayList<Asignatura> getAsignaturas() { return asignaturas; }
    public void agregarAsignatura(Asignatura a) { asignaturas.add(a); }

    public ArrayList<Proyecto> getProyectos() { return proyectos; }
    public void agregarProyecto(Proyecto p) { proyectos.add(p); }

    public Dependencia getDependencia() { return dependencia; }
    public void setDependencia(Dependencia dependencia) { this.dependencia = dependencia; }

    public Bonificacion getBonificacion() { return bonificacion; }
    public void setBonificacion(Bonificacion bonificacion) { this.bonificacion = bonificacion; }

    @Override
    public String getTipoEmpleado() { return "Profesor"; }
}
