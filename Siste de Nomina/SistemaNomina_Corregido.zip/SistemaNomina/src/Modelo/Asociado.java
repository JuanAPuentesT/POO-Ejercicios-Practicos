package Modelo;

public class Asociado extends Profesor {
    // salarioBase heredado de Empleado, se declara aquí para reafirmar la referencia del diagrama
    private double salarioBaseAsociado;

    public Asociado() {}

    public Asociado(String nip, String codigo, String nombre, String direccion,
                    String email, Fecha fechaVinculacion, String especialidad, double salarioBase) {
        super(nip, codigo, nombre, direccion, email, fechaVinculacion, salarioBase, especialidad);
        this.salarioBaseAsociado = salarioBase;
    }

    @Override
    public double CalcularSalario() {
        double descuento = (deduccion != null) ? deduccion.getValor() : 0;
        double bonif = (bonificacion != null) ? bonificacion.getValor() : CalcularBonificacion();
        return salarioBase + bonif - descuento;
    }

    public double getSalarioBaseAsociado() { return salarioBaseAsociado; }
    public void setSalarioBaseAsociado(double s) {
        this.salarioBaseAsociado = s;
        this.salarioBase = s;
    }

    @Override
    public String getTipoEmpleado() { return "Asociado"; }
}
