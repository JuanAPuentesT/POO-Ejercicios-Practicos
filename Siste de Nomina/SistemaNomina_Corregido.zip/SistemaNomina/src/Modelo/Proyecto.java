package Modelo;

import java.util.ArrayList;

public class Proyecto {
    protected String nombre;
    protected TipoDeProyecto tipo;
    protected String codigo;
    private ArrayList<Producto> productos;

    public Proyecto() {
        productos = new ArrayList<>();
    }

    public Proyecto(String codigo, String nombre, TipoDeProyecto tipo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipo = tipo;
        this.productos = new ArrayList<>();
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public TipoDeProyecto getTipo() { return tipo; }
    public void setTipo(TipoDeProyecto tipo) { this.tipo = tipo; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public ArrayList<Producto> getProductos() { return productos; }
    public void agregarProducto(Producto p) { productos.add(p); }

    @Override
    public String toString() {
        return nombre + " [" + tipo + "]";
    }
}
