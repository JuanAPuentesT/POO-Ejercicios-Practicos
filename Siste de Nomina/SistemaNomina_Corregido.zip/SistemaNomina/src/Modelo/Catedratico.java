package Modelo;

public class Catedratico extends Profesor {
    private int horas;
    private double valorHora;

    public Catedratico() {}

    public Catedratico(String nip, String codigo, String nombre, String direccion,
                       String email, Fecha fechaVinculacion, String especialidad,
                       int horas, double valorHora) {
        super(nip, codigo, nombre, direccion, email, fechaVinculacion, 0, especialidad);
        this.horas = horas;
        this.valorHora = valorHora;
        this.salarioBase = calcularSalarioCatedratico(horas, valorHora);
    }

    public double calcularSalarioCatedratico(int horas, double valorHora) {
        return horas * valorHora;
    }

    @Override
    public double CalcularSalario() {
        double base = calcularSalarioCatedratico(horas, valorHora);
        double descuento = (deduccion != null) ? deduccion.getValor() : 0;
        double bonif = (bonificacion != null) ? bonificacion.getValor() : CalcularBonificacion();
        return base + bonif - descuento;
    }

    public int getHoras() { return horas; }
    public void setHoras(int horas) {
        this.horas = horas;
        this.salarioBase = calcularSalarioCatedratico(horas, valorHora);
    }

    public double getValorHora() { return valorHora; }
    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
        this.salarioBase = calcularSalarioCatedratico(horas, valorHora);
    }

    @Override
    public String getTipoEmpleado() { return "Catedrático"; }
}
