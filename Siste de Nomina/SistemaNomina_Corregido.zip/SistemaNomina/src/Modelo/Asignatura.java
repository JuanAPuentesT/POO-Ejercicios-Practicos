package Modelo;

public class Asignatura {
    protected String codigo;
    protected String nombre;
    protected int creditos;
    protected int numHoras;

    public Asignatura() {}

    public Asignatura(String codigo, String nombre, int creditos, int numHoras) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.creditos = creditos;
        this.numHoras = numHoras;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getCreditos() { return creditos; }
    public void setCreditos(int creditos) { this.creditos = creditos; }

    public int getNumHoras() { return numHoras; }
    public void setNumHoras(int numHoras) { this.numHoras = numHoras; }

    @Override
    public String toString() {
        return nombre + " (" + creditos + " cr.)";
    }
}
