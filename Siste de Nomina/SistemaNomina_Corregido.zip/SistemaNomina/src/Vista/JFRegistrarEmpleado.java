package Vista;

import javax.swing.*;
import java.awt.*;

public class JFRegistrarEmpleado extends JFrame {

    // Campos comunes
    public JTextField txtNip;
    public JTextField txtCodigo;
    public JTextField txtNombre;
    public JTextField txtDireccion;
    public JTextField txtEmail;
    public JTextField txtDia;
    public JTextField txtMes;
    public JTextField txtAnio;
    public JTextField txtSalarioBase;
    public JComboBox<String> cmbTipoEmpleado;

    // Panel específico por tipo (cards)
    public JPanel panelEspecifico;
    public CardLayout cardLayout;

    // --- Campos Administrativo ---
    public JTextField txtCargoCodDep;
    public JTextField txtNombreDep;
    public JTextField txtCargo;

    // --- Campos Profesor (todos los subtipos) ---
    public JTextField txtEspecialidad;
    public JComboBox<String> cmbSubtipoProfesor;
    public JPanel panelSubtipo;
    public CardLayout cardSubtipo;

    // Catedrático
    public JTextField txtHoras;
    public JTextField txtValorHora;

    // Ocasional
    public JTextField txtTiempoContrato;
    public JTextField txtSalarioMes;
    public JCheckBox chkModalidad;

    // Asociado (usa salarioBase general)

    // Botones
    public JButton btnGuardar;
    public JButton btnLimpiar;
    public JButton btnCerrar;

    public JTextArea areaInfo;

    public JFRegistrarEmpleado() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Registrar Empleado");
        setSize(560, 620);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        // ---- Panel datos comunes ----
        JPanel panelComun = new JPanel(new GridBagLayout());
        panelComun.setBorder(BorderFactory.createTitledBorder("Datos Generales"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 5, 3, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        String[] labels = {"NIP:", "Código:", "Nombre:", "Dirección:", "Email:",
                           "Día vinculación:", "Mes vinculación:", "Año vinculación:", "Salario Base:", "Tipo:"};
        txtNip = new JTextField(12);
        txtCodigo = new JTextField(12);
        txtNombre = new JTextField(12);
        txtDireccion = new JTextField(12);
        txtEmail = new JTextField(12);
        txtDia = new JTextField(4);
        txtMes = new JTextField(4);
        txtAnio = new JTextField(6);
        txtSalarioBase = new JTextField(12);
        cmbTipoEmpleado = new JComboBox<>(new String[]{"Administrativo", "Catedrático", "Ocasional", "Asociado"});

        Component[] fields = {txtNip, txtCodigo, txtNombre, txtDireccion, txtEmail,
                              txtDia, txtMes, txtAnio, txtSalarioBase, cmbTipoEmpleado};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.3;
            panelComun.add(new JLabel(labels[i]), gbc);
            gbc.gridx = 1; gbc.weightx = 0.7;
            panelComun.add(fields[i], gbc);
        }

        // ---- Panel específico por tipo (CardLayout) ----
        cardLayout = new CardLayout();
        panelEspecifico = new JPanel(cardLayout);
        panelEspecifico.setBorder(BorderFactory.createTitledBorder("Datos Específicos"));

        // Card Administrativo
        JPanel cardAdmin = new JPanel(new GridBagLayout());
        GridBagConstraints g2 = new GridBagConstraints();
        g2.insets = new Insets(3, 5, 3, 5);
        g2.fill = GridBagConstraints.HORIZONTAL;
        txtCargoCodDep = new JTextField(10);
        txtNombreDep = new JTextField(10);
        txtCargo = new JTextField(10);
        addRow(cardAdmin, g2, 0, "Cód. Dependencia:", txtCargoCodDep);
        addRow(cardAdmin, g2, 1, "Nombre Dependencia:", txtNombreDep);
        addRow(cardAdmin, g2, 2, "Cargo:", txtCargo);
        panelEspecifico.add(cardAdmin, "Administrativo");

        // Card Catedrático
        JPanel cardCat = new JPanel(new GridBagLayout());
        GridBagConstraints g3 = new GridBagConstraints();
        g3.insets = new Insets(3, 5, 3, 5);
        g3.fill = GridBagConstraints.HORIZONTAL;
        txtEspecialidad = new JTextField(10);
        txtHoras = new JTextField(6);
        txtValorHora = new JTextField(8);
        addRow(cardCat, g3, 0, "Especialidad:", txtEspecialidad);
        addRow(cardCat, g3, 1, "Horas:", txtHoras);
        addRow(cardCat, g3, 2, "Valor por hora:", txtValorHora);
        panelEspecifico.add(cardCat, "Catedrático");

        // Card Ocasional
        JPanel cardOcas = new JPanel(new GridBagLayout());
        GridBagConstraints g4 = new GridBagConstraints();
        g4.insets = new Insets(3, 5, 3, 5);
        g4.fill = GridBagConstraints.HORIZONTAL;
        JTextField txtEspOcas = new JTextField(10);
        // Compartir campo especialidad - se reutilizará en el controlador
        txtTiempoContrato = new JTextField(6);
        txtSalarioMes = new JTextField(8);
        chkModalidad = new JCheckBox("Tiempo completo");
        addRow(cardOcas, g4, 0, "Especialidad:", txtEspOcas);
        addRow(cardOcas, g4, 1, "Tiempo contrato (meses):", txtTiempoContrato);
        addRow(cardOcas, g4, 2, "Salario por mes:", txtSalarioMes);
        g4.gridx = 0; g4.gridy = 3; g4.gridwidth = 2;
        cardOcas.add(chkModalidad, g4);
        // guardamos referencia al campo
        txtEspOcas.setName("txtEspOcas");
        panelEspecifico.add(cardOcas, "Ocasional");

        // Card Asociado
        JPanel cardAsoc = new JPanel(new GridBagLayout());
        GridBagConstraints g5 = new GridBagConstraints();
        g5.insets = new Insets(3, 5, 3, 5);
        g5.fill = GridBagConstraints.HORIZONTAL;
        JTextField txtEspAsoc = new JTextField(10);
        txtEspAsoc.setName("txtEspAsoc");
        addRow(cardAsoc, g5, 0, "Especialidad:", txtEspAsoc);
        JLabel lblAsoc = new JLabel("(Salario se toma del campo Salario Base)");
        lblAsoc.setForeground(Color.GRAY);
        g5.gridx = 0; g5.gridy = 1; g5.gridwidth = 2;
        cardAsoc.add(lblAsoc, g5);
        panelEspecifico.add(cardAsoc, "Asociado");

        // ---- Panel botones ----
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnGuardar = new JButton("Guardar");
        btnLimpiar = new JButton("Limpiar");
        btnCerrar = new JButton("Cerrar");
        panelBotones.add(btnGuardar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnCerrar);

        areaInfo = new JTextArea(3, 40);
        areaInfo.setEditable(false);
        areaInfo.setForeground(new Color(0, 100, 0));

        JPanel panelSur = new JPanel(new BorderLayout(5, 5));
        panelSur.add(panelBotones, BorderLayout.NORTH);
        panelSur.add(new JScrollPane(areaInfo), BorderLayout.CENTER);

        add(panelComun, BorderLayout.NORTH);
        add(panelEspecifico, BorderLayout.CENTER);
        add(panelSur, BorderLayout.SOUTH);
    }

    private void addRow(JPanel panel, GridBagConstraints gbc, int row, String label, Component field) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.4; gbc.gridwidth = 1;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1; gbc.weightx = 0.6;
        panel.add(field, gbc);
    }
}
