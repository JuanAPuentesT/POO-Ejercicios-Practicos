package Vista;

import javax.swing.*;
import java.awt.*;

public class JFPrincipal extends JFrame {

    public JButton btnRegistrarEmpleado;
    public JButton btnCalcularNomina;
    public JButton btnMostrarEmpleados;
    public JButton btnSalir;
    public JTextArea areaResultados;

    public JFPrincipal() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Sistema de Nómina");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Panel título
        JLabel lblTitulo = new JLabel("Sistema de Gestión de Nómina", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

        // Panel botones
        JPanel panelBotones = new JPanel(new GridLayout(4, 1, 5, 5));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btnRegistrarEmpleado = new JButton("Registrar Empleado");
        btnCalcularNomina = new JButton("Calcular Nómina Total");
        btnMostrarEmpleados = new JButton("Mostrar Empleados");
        btnSalir = new JButton("Salir");

        btnRegistrarEmpleado.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCalcularNomina.setFont(new Font("Arial", Font.PLAIN, 14));
        btnMostrarEmpleados.setFont(new Font("Arial", Font.PLAIN, 14));
        btnSalir.setFont(new Font("Arial", Font.PLAIN, 14));

        panelBotones.add(btnRegistrarEmpleado);
        panelBotones.add(btnCalcularNomina);
        panelBotones.add(btnMostrarEmpleados);
        panelBotones.add(btnSalir);
        add(panelBotones, BorderLayout.WEST);

        // Área de resultados
        areaResultados = new JTextArea();
        areaResultados.setEditable(false);
        areaResultados.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaResultados.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JScrollPane scroll = new JScrollPane(areaResultados);
        scroll.setBorder(BorderFactory.createTitledBorder("Resultados"));
        add(scroll, BorderLayout.CENTER);
    }
}
