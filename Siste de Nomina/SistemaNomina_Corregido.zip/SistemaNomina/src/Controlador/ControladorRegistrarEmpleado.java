package Controlador;

import Modelo.*;
import Vista.JFRegistrarEmpleado;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Component;
import javax.swing.*;

public class ControladorRegistrarEmpleado implements ActionListener {

    private JFRegistrarEmpleado vista;
    private GestionNomina gestionNomina;
    private ControladorPrincipal controladorPrincipal;

    public ControladorRegistrarEmpleado(JFRegistrarEmpleado vista, GestionNomina gestionNomina,
                                        ControladorPrincipal controladorPrincipal) {
        this.vista = vista;
        this.gestionNomina = gestionNomina;
        this.controladorPrincipal = controladorPrincipal;

        vista.btnGuardar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
        vista.btnCerrar.addActionListener(this);

        // Cambio de tipo actualiza CardLayout
        vista.cmbTipoEmpleado.addActionListener(e -> {
            String tipo = (String) vista.cmbTipoEmpleado.getSelectedItem();
            vista.cardLayout.show(vista.panelEspecifico, tipo);
            // Salario base no aplica para catedrático (se calcula por horas)
            vista.txtSalarioBase.setEnabled(!tipo.equals("Catedrático"));
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) {
            guardarEmpleado();
        } else if (e.getSource() == vista.btnLimpiar) {
            limpiarCampos();
        } else if (e.getSource() == vista.btnCerrar) {
            vista.dispose();
        }
    }

    private void guardarEmpleado() {
        try {
            // Datos comunes
            String nip = vista.txtNip.getText().trim();
            String codigo = vista.txtCodigo.getText().trim();
            String nombre = vista.txtNombre.getText().trim();
            String direccion = vista.txtDireccion.getText().trim();
            String email = vista.txtEmail.getText().trim();

            if (nip.isEmpty() || codigo.isEmpty() || nombre.isEmpty()) {
                vista.areaInfo.setText("Por favor complete NIP, Código y Nombre.");
                return;
            }

            if (gestionNomina.buscarPorCodigo(codigo) != null) {
                vista.areaInfo.setText("Ya existe un empleado con el código: " + codigo);
                return;
            }

            int dia = Integer.parseInt(vista.txtDia.getText().trim());
            int mes = Integer.parseInt(vista.txtMes.getText().trim());
            int anio = Integer.parseInt(vista.txtAnio.getText().trim());
            Fecha fecha = new Fecha(dia, mes, anio);

            String tipo = (String) vista.cmbTipoEmpleado.getSelectedItem();
            Empleado nuevo = null;

            switch (tipo) {
                case "Administrativo": {
                    double salario = Double.parseDouble(vista.txtSalarioBase.getText().trim());
                    String codDep = vista.txtCargoCodDep.getText().trim();
                    String nomDep = vista.txtNombreDep.getText().trim();
                    String cargo = vista.txtCargo.getText().trim();
                    Dependencia dep = new Dependencia(codDep, nomDep);
                    nuevo = new Administrativo(nip, codigo, nombre, direccion, email, fecha,
                                               salario, dep, cargo);
                    break;
                }
                case "Catedrático": {
                    String esp = getTextFromCard("Catedrático", "Especialidad:");
                    int horas = Integer.parseInt(vista.txtHoras.getText().trim());
                    double valorHora = Double.parseDouble(vista.txtValorHora.getText().trim());
                    String especialidad = vista.txtEspecialidad.getText().trim();
                    nuevo = new Catedratico(nip, codigo, nombre, direccion, email, fecha,
                                            especialidad, horas, valorHora);
                    break;
                }
                case "Ocasional": {
                    int tiempo = Integer.parseInt(vista.txtTiempoContrato.getText().trim());
                    double salMes = Double.parseDouble(vista.txtSalarioMes.getText().trim());
                    boolean modalidad = vista.chkModalidad.isSelected();
                    // Buscar campo especialidad en card Ocasional
                    String espOcas = getComponentText(vista.panelEspecifico, "txtEspOcas");
                    nuevo = new Ocasional(nip, codigo, nombre, direccion, email, fecha,
                                          espOcas, tiempo, salMes, modalidad);
                    break;
                }
                case "Asociado": {
                    double salario = Double.parseDouble(vista.txtSalarioBase.getText().trim());
                    String espAsoc = getComponentText(vista.panelEspecifico, "txtEspAsoc");
                    nuevo = new Asociado(nip, codigo, nombre, direccion, email, fecha,
                                         espAsoc, salario);
                    break;
                }
            }

            if (nuevo != null) {
                gestionNomina.RegistrarEmpleado(nuevo);
                vista.areaInfo.setText("✔ Empleado registrado: " + nombre + " (" + tipo + ")");
                controladorPrincipal.actualizarLista();
                limpiarCampos();
            }

        } catch (NumberFormatException ex) {
            vista.areaInfo.setText("Error: verifique que los campos numéricos sean válidos.");
        }
    }

    private String getComponentText(java.awt.Container container, String name) {
        for (Component c : container.getComponents()) {
            if (name.equals(c.getName()) && c instanceof JTextField) {
                return ((JTextField) c).getText().trim();
            }
            if (c instanceof java.awt.Container) {
                String result = getComponentText((java.awt.Container) c, name);
                if (result != null) return result;
            }
        }
        return "";
    }

    private String getTextFromCard(String card, String label) {
        return "";
    }

    private void limpiarCampos() {
        vista.txtNip.setText("");
        vista.txtCodigo.setText("");
        vista.txtNombre.setText("");
        vista.txtDireccion.setText("");
        vista.txtEmail.setText("");
        vista.txtDia.setText("");
        vista.txtMes.setText("");
        vista.txtAnio.setText("");
        vista.txtSalarioBase.setText("");
        vista.txtEspecialidad.setText("");
        vista.txtHoras.setText("");
        vista.txtValorHora.setText("");
        vista.txtTiempoContrato.setText("");
        vista.txtSalarioMes.setText("");
        vista.chkModalidad.setSelected(false);
        vista.txtCargoCodDep.setText("");
        vista.txtNombreDep.setText("");
        vista.txtCargo.setText("");
        vista.areaInfo.setText("");
    }
}
