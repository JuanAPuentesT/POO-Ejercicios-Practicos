package Controlador;

import Modelo.*;
import Vista.JFPrincipal;
import Vista.JFRegistrarEmpleado;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ControladorPrincipal implements ActionListener {

    private JFPrincipal vista;
    private GestionNomina gestionNomina;

    public ControladorPrincipal(JFPrincipal vista, GestionNomina gestionNomina) {
        this.vista = vista;
        this.gestionNomina = gestionNomina;

        vista.btnRegistrarEmpleado.addActionListener(this);
        vista.btnCalcularNomina.addActionListener(this);
        vista.btnMostrarEmpleados.addActionListener(this);
        vista.btnSalir.addActionListener(this);

        cargarDatosDemostracion();
        mostrarEmpleados();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnRegistrarEmpleado) {
            abrirRegistro();
        } else if (e.getSource() == vista.btnCalcularNomina) {
            calcularNomina();
        } else if (e.getSource() == vista.btnMostrarEmpleados) {
            mostrarEmpleados();
        } else if (e.getSource() == vista.btnSalir) {
            System.exit(0);
        }
    }

    private void abrirRegistro() {
        JFRegistrarEmpleado frmRegistrar = new JFRegistrarEmpleado();
        frmRegistrar.setVisible(true);
        new ControladorRegistrarEmpleado(frmRegistrar, gestionNomina, this);
    }

    private void calcularNomina() {
        ArrayList<Empleado> empleados = gestionNomina.MostrarEmpleados();
        if (empleados.isEmpty()) {
            vista.areaResultados.setText("No hay empleados registrados.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("══════════════════════════════════════════════════\n");
        sb.append("               CÁLCULO DE NÓMINA\n");
        sb.append("══════════════════════════════════════════════════\n\n");

        double total = 0;
        for (Empleado emp : empleados) {
            double salario = emp.CalcularSalario();
            total += salario;
            sb.append(String.format("%-30s [%14s]  Antigüedad: %d año(s)\n",
                emp.getNombre(), emp.getTipoEmpleado(), emp.CalcularAntiguedad()));
            sb.append(String.format("  Salario base: $%,.2f    Salario neto: $%,.2f\n", 
                emp.getSalarioBase(), salario));
            if (emp.getDeduccion() != null) {
                sb.append("  Deducción: " + emp.getDeduccion() + "\n");
            }
            if (emp instanceof Profesor) {
                Profesor p = (Profesor) emp;
                double bono = p.CalcularBonificacion();
                sb.append(String.format("  Bonificación calculada: $%,.2f\n", bono));
            }
            sb.append("──────────────────────────────────────────────────\n");
        }
        sb.append(String.format("\n  TOTAL NÓMINA: $%,.2f\n", total));
        sb.append("══════════════════════════════════════════════════\n");
        vista.areaResultados.setText(sb.toString());
    }

    public void mostrarEmpleados() {
        ArrayList<Empleado> empleados = gestionNomina.MostrarEmpleados();
        if (empleados.isEmpty()) {
            vista.areaResultados.setText("No hay empleados registrados.\n\nUse 'Registrar Empleado' para agregar.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("══════════════════════════════════════════════════\n");
        sb.append("               LISTA DE EMPLEADOS\n");
        sb.append("══════════════════════════════════════════════════\n\n");
        for (Empleado emp : empleados) {
            sb.append(String.format("▶ %s\n", emp.getNombre()));
            sb.append(String.format("  Tipo: %-18s  Código: %s\n", emp.getTipoEmpleado(), emp.getCodigo()));
            sb.append(String.format("  Email: %-30s\n", emp.getEmail()));
            if (emp.getFechaVinculacion() != null)
                sb.append(String.format("  Vinculación: %s   Antigüedad: %d año(s)\n",
                    emp.getFechaVinculacion(), emp.CalcularAntiguedad()));
            if (emp instanceof Administrativo) {
                Administrativo a = (Administrativo) emp;
                sb.append(String.format("  Cargo: %s | Dependencia: %s\n",
                    a.getCargo(), a.getDependencia()));
            } else if (emp instanceof Catedratico) {
                Catedratico c = (Catedratico) emp;
                sb.append(String.format("  Especialidad: %s | Horas: %d | Valor/hora: $%.2f\n",
                    c.getEspecialidad(), c.getHoras(), c.getValorHora()));
            } else if (emp instanceof Ocasional) {
                Ocasional o = (Ocasional) emp;
                sb.append(String.format("  Especialidad: %s | Contrato: %d meses | Modalidad: %s\n",
                    o.getEspecialidad(), o.getTiempoContrato(),
                    o.isModalidad() ? "Tiempo completo" : "Medio tiempo"));
            } else if (emp instanceof Asociado) {
                Asociado as = (Asociado) emp;
                sb.append(String.format("  Especialidad: %s\n", as.getEspecialidad()));
            }
            sb.append("──────────────────────────────────────────────────\n");
        }
        vista.areaResultados.setText(sb.toString());
    }

    public void actualizarLista() {
        mostrarEmpleados();
    }

    private void cargarDatosDemostracion() {
        Dependencia depSistemas = new Dependencia("DEP01", "Departamento de Sistemas");
        Dependencia depAdmin = new Dependencia("DEP02", "Administración General");

        // Administrativo
        Administrativo admin = new Administrativo(
            "NIP001", "ADM001", "Carlos Ramírez", "Calle 10 #5-20", "cramírez@uni.edu",
            new Fecha(15, 3, 2018), 3500000, depAdmin, "Coordinador"
        );
        Deduccion ded1 = new Deduccion("DED01", "Salud", 140000);
        admin.setDeduccion(ded1);
        gestionNomina.RegistrarEmpleado(admin);

        // Profesor Asociado
        Asociado asociado = new Asociado(
            "NIP002", "ASOC001", "María González", "Av. 15 #8-40", "mgonzalez@uni.edu",
            new Fecha(10, 8, 2015), "Ingeniería de Software", 4200000
        );
        Bonificacion bon = new Bonificacion("BON01", "Bonificación antigüedad", 420000);
        asociado.setBonificacion(bon);
        gestionNomina.RegistrarEmpleado(asociado);

        // Catedrático
        Catedratico cat = new Catedratico(
            "NIP003", "CAT001", "Luis Pérez", "Carrera 7 #12-3", "lperez@uni.edu",
            new Fecha(1, 2, 2022), "Matemáticas", 80, 45000
        );
        gestionNomina.RegistrarEmpleado(cat);

        // Ocasional
        Ocasional ocas = new Ocasional(
            "NIP004", "OCAS001", "Ana Torres", "Calle 5 #3-15", "atorres@uni.edu",
            new Fecha(5, 6, 2023), "Historia", 6, 3000000, false
        );
        gestionNomina.RegistrarEmpleado(ocas);
    }
}
