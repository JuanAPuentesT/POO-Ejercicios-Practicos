package sistemanomina;

import Controlador.ControladorPrincipal;
import Modelo.GestionNomina;
import Vista.JFPrincipal;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class SistemaNomina {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            GestionNomina gestionNomina = new GestionNomina();
            JFPrincipal vista = new JFPrincipal();
            new ControladorPrincipal(vista, gestionNomina);
            vista.setVisible(true);
        });
    }
}
