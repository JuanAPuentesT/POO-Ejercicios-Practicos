package modelo;

import java.util.ArrayList;
import java.util.List;

public class Escenario {
    private String nombre;
    private String ubicacion;
    private int cantidadEnemigos;
    private List<Enemigo> enemigos;

    public Escenario(String nombre, String ubicacion) {
        this.nombre           = nombre;
        this.ubicacion        = ubicacion;
        this.cantidadEnemigos = 0;
        this.enemigos         = new ArrayList<>();
    }

    public void cargar() { System.out.println("Cargando: " + nombre); }

    public void agregarEnemigo(Enemigo e) {
        enemigos.add(e);
        cantidadEnemigos++;
    }

    public List<Enemigo> getEnemigos()  { return enemigos; }
    public String getNombre()           { return nombre; }
    public String getUbicacion()        { return ubicacion; }
    public int getCantidadEnemigos()    { return cantidadEnemigos; }
}
