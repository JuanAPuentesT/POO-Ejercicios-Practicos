package modelo;

public class Ares extends Enemigo {
    private String poderesDivinos;
    private boolean faseFinal;

    public Ares() {
        super("Ares", "Dios de la Guerra", 150, 20, 1000);
        this.poderesDivinos = "Manipulación de la guerra, Tormenta divina";
        this.faseFinal      = false;
    }

    public void activarPoderDivino(String poder) { System.out.println("Ares usa: " + poder); }
    public void activarFaseFinal()  { faseFinal = true; reducirFuerza(-20); }
    public boolean isFaseFinal()    { return faseFinal; }
    public String getPoderesDivinos() { return poderesDivinos; }
}
