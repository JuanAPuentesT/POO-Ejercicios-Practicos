package modelo;

public class Enemigo extends Personaje {
    private String tipo;
    private int fuerza;
    private int recompensa;

    public Enemigo(String nombre, String tipo, int salud, int fuerza, int recompensa) {
        super(nombre, salud, 1);
        this.tipo       = tipo;
        this.fuerza     = fuerza;
        this.recompensa = recompensa;
    }

    @Override
    public void atacar() { System.out.println(nombre + " ataca con fuerza " + fuerza); }

    public void morir()                     { salud = 0; }
    public void reducirFuerza(int cantidad)  { fuerza = Math.max(0, fuerza - cantidad); }
    public String getTipo()    { return tipo; }
    public int getFuerza()     { return fuerza; }
    public int getRecompensa() { return recompensa; }
}
