package modelo;

public class Aliado extends Personaje {
    private String rol;
    private String[] dialogos;
    private int indiceDialogo;

    public Aliado(String nombre, String rol, String[] dialogos) {
        super(nombre, 80, 3);
        this.rol           = rol;
        this.dialogos      = dialogos;
        this.indiceDialogo = 0;
    }

    @Override
    public void atacar() { System.out.println(nombre + " ayuda en combate."); }

    public String getSiguienteDialogo() {
        String d = dialogos[indiceDialogo % dialogos.length];
        indiceDialogo++;
        return d;
    }

    public void hablar() { System.out.println(nombre + ": " + getSiguienteDialogo()); }
    public void ayudar() { System.out.println(nombre + " ayuda a Diana."); }
    public String getRol() { return rol; }
}
