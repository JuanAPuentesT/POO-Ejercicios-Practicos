package modelo;

public class Objeto {
    private String nombre;
    private String tipo;
    private String efecto;
    private boolean disponible;
    private int reduccionFuerza;

    public Objeto(String nombre, String tipo, String efecto, int reduccionFuerza) {
        this.nombre         = nombre;
        this.tipo           = tipo;
        this.efecto         = efecto;
        this.reduccionFuerza = reduccionFuerza;
        this.disponible     = true;
    }

    public Objeto(String nombre, String tipo, String efecto) {
        this(nombre, tipo, efecto, 0);
    }

    public void usar()               { if (disponible) disponible = false; }
    public String getDescripcion()   { return nombre + " (" + tipo + "): " + efecto; }
    public boolean estaDisponible()  { return disponible; }
    public String getNombre()        { return nombre; }
    public String getTipo()          { return tipo; }
    public String getEfecto()        { return efecto; }
    public int getReduccionFuerza()  { return reduccionFuerza; }
}
