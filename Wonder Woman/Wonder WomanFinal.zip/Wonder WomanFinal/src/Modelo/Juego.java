package modelo;

public class Juego {
    public static final int SALUD_MAX_ARES = 150;

    private WonderWoman diana;
    private Ares        ares;
    private Aliado      steve;
    private Objeto      lazo;
    private Objeto      escudo;
    private Escenario   escenario;
    private int         turno;
    private boolean     terminado;
    private boolean     victoria;

    public Juego() { reiniciar(); }

    public void reiniciar() {
        diana = new WonderWoman();
        ares  = new Ares();
        steve = new Aliado("Steve Trevor", "Soldado aliado",
                    new String[]{
                        "Confía en mí, Diana.",
                        "Juntos podemos detenerlo.",
                        "Eres increíble, Diana.",
                        "No te rindas, el mundo te necesita."
                    });
        lazo   = new Objeto("Lazo de la Verdad", "Arma",    "Revela la verdad y reduce fuerza", 30);
        escudo = new Objeto("Escudo de Atenea",  "Defensa", "Reduce el daño recibido al 40%");
        escenario = new Escenario("Themyscira", "Isla de las Amazonas");
        escenario.agregarEnemigo(ares);
        turno     = 1;
        terminado = false;
        victoria  = false;
    }

    public void avanzarTurno()      { turno++; }
    public void terminar(boolean v) { terminado = true; victoria = v; }

    public WonderWoman getDiana()   { return diana; }
    public Ares getAres()           { return ares; }
    public Aliado getSteve()        { return steve; }
    public Objeto getLazo()         { return lazo; }
    public Objeto getEscudo()       { return escudo; }
    public Escenario getEscenario() { return escenario; }
    public int getTurno()           { return turno; }
    public boolean isTerminado()    { return terminado; }
    public boolean isVictoria()     { return victoria; }
}
