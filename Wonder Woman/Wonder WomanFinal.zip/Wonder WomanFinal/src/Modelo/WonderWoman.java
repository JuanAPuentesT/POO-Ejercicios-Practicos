package modelo;

public class WonderWoman extends Personaje {
    public static final int SALUDMAX    = 100;
    public static final int DANIONORMAL = 15;
    public static final int DANIOFURIA  = 30;

    private String origen;
    private String habilidades;
    private String equipo;
    private boolean modoFuria;
    private boolean escudoActivo;

    public WonderWoman() {
        super("Wonder Woman", SALUDMAX, 10);
        this.origen       = "Themyscira";
        this.habilidades  = "Superfuerza, Vuelo, Combate";
        this.equipo       = "Lazo de la Verdad, Escudo de Atenea, Brazaletes";
        this.modoFuria    = false;
        this.escudoActivo = false;
    }

    @Override
    public void atacar() { System.out.println("Diana ataca con su espada."); }

    public int recibirDanioConInfo(int cantidad) {
        int real = escudoActivo ? (int)(cantidad * 0.4) : cantidad;
        recibirDanio(real);
        return real;
    }

    public void activarFuria()  { modoFuria    = !modoFuria; }
    public void activarEscudo() { escudoActivo = true; }
    public void usarHabilidad(String n) { System.out.println("Diana usa: " + n); }
    public void usarObjeto(Objeto o)    { o.usar(); }

    public boolean isModoFuria()    { return modoFuria; }
    public boolean isEscudoActivo() { return escudoActivo; }
    public String getOrigen()       { return origen; }
    public String getHabilidades()  { return habilidades; }
    public String getEquipo()       { return equipo; }
}
