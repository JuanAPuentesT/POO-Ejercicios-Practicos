/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class VistaJuegoSwing extends JFrame {

    // ── HUD superior ─────────────────────────────────────────────
    public JLabel lblTurnoVal;
    public JLabel lblEscenarioVal;

    // ── Panel Diana ───────────────────────────────────────────────
    public JProgressBar barDiana;
    public JLabel lblDianaHPVal;
    public JLabel lblFuriaVal;
    public JLabel lblEscudoVal;

    // ── Panel Ares ────────────────────────────────────────────────
    public JProgressBar barAres;
    public JLabel lblAresHPVal;
    public JLabel lblFaseVal;

    // ── Panel Steve ───────────────────────────────────────────────
    public JTextArea txtDialogoSteve;

    // ── Log de combate ────────────────────────────────────────────
    public JTextArea txtLog;

    // ── Objetos ───────────────────────────────────────────────────
    public JButton btnLazo;
    public JButton btnEscudo;

    // ── Acciones ──────────────────────────────────────────────────
    public JButton btnAtacar;
    public JButton btnFuria;
    public JButton btnSteve;
    public JButton btnNuevo;

    // ── Panel derecho (info) ──────────────────────────────────────
    public JLabel lblUbicacionVal;
    public JLabel lblEnemigosVal;
    public JLabel lblTerminadoVal;
    public JLabel lblVictoriaVal;
    public JTextArea txtDialogoDiana;

    // ── Barra de estado ───────────────────────────────────────────
    public JLabel lblStatus;

    // ─────────────────────────────────────────────────────────────

    public VistaJuegoSwing() {
        super("Wonder Woman — El Juego");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(860, 580);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(26, 26, 46));

        add(buildHUD(),    BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildStatus(), BorderLayout.SOUTH);
    }

    // ── HUD (barra superior) ──────────────────────────────────────
    private JPanel buildHUD() {
        JPanel hud = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 8));
        hud.setBackground(new Color(20, 20, 40));
        hud.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(80, 80, 120)));

        JLabel titulo = new JLabel("  WONDER WOMAN");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 14));
        titulo.setForeground(new Color(232, 201, 106));
        hud.add(titulo);

        hud.add(buildHudStat("TURNO", lblTurnoVal = hudVal("1")));
        hud.add(buildHudStat("DIANA HP", lblDianaHPVal = hudVal("100")));
        hud.add(buildHudStat("ARES HP",  lblAresHPVal  = hudVal("150")));
        hud.add(buildHudStat("ESCENARIO", lblEscenarioVal = hudVal("Themyscira")));

        return hud;
    }

    private JPanel buildHudStat(String label, JLabel val) {
        JPanel p = new JPanel(new BorderLayout(0, 2));
        p.setBackground(new Color(20, 20, 40));
        JLabel lbl = new JLabel(label, SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lbl.setForeground(new Color(160, 160, 160));
        p.add(lbl, BorderLayout.NORTH);
        p.add(val, BorderLayout.SOUTH);
        return p;
    }

    private JLabel hudVal(String txt) {
        JLabel l = new JLabel(txt, SwingConstants.CENTER);
        l.setFont(new Font("SansSerif", Font.BOLD, 13));
        l.setForeground(new Color(232, 201, 106));
        return l;
    }

    // ── Área central: izquierda + centro + derecha ────────────────
    private JSplitPane buildCenter() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildLeft(), buildMiddleAndRight());
        split.setDividerLocation(210);
        split.setDividerSize(1);
        split.setEnabled(false);
        split.setBackground(new Color(26, 26, 46));
        return split;
    }

    // ── Panel izquierdo: tarjetas de personajes ───────────────────
    private JPanel buildLeft() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(new Color(22, 22, 38));
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        p.add(sectionLabel("PERSONAJES"));
        p.add(Box.createVerticalStrut(6));
        p.add(buildCardDiana());
        p.add(Box.createVerticalStrut(8));
        p.add(buildCardSteve());
        p.add(Box.createVerticalStrut(8));
        p.add(buildCardAres());
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel buildCardDiana() {
        JPanel card = darkCard();
        card.setLayout(new BorderLayout(0, 6));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        top.setOpaque(false);
        JLabel ico = iconCircle("\u2605", new Color(24, 95, 165));
        top.add(ico);
        JPanel names = new JPanel(new GridLayout(2, 1));
        names.setOpaque(false);
        names.add(cardName("Wonder Woman"));
        names.add(cardSub("Diana Prince"));
        top.add(names);
        card.add(top, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout(0, 2));
        mid.setOpaque(false);
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        JLabel lbl = tinyLabel("Salud");
        lblDianaHPVal = new JLabel("100 / 100");
        lblDianaHPVal.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblDianaHPVal.setForeground(new Color(160, 160, 160));
        row.add(lbl, BorderLayout.WEST);
        row.add(lblDianaHPVal, BorderLayout.EAST);
        barDiana = makeBar(new Color(29, 158, 117), 100, 100);
        mid.add(row, BorderLayout.NORTH);
        mid.add(barDiana, BorderLayout.CENTER);
        card.add(mid, BorderLayout.CENTER);

        JPanel tags = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        tags.setOpaque(false);
        lblFuriaVal  = makeTag("Furia: OFF");
        lblEscudoVal = makeTag("Escudo: OFF");
        tags.add(lblFuriaVal);
        tags.add(lblEscudoVal);
        card.add(tags, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildCardSteve() {
        JPanel card = darkCard();
        card.setLayout(new BorderLayout(0, 6));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        top.setOpaque(false);
        top.add(iconCircle("S", new Color(15, 110, 86)));
        JPanel names = new JPanel(new GridLayout(2, 1));
        names.setOpaque(false);
        names.add(cardName("Steve Trevor"));
        names.add(cardSub("Aliado · Soldado"));
        top.add(names);
        card.add(top, BorderLayout.NORTH);

        txtDialogoSteve = new JTextArea("Confia en mi, Diana.");
        txtDialogoSteve.setWrapStyleWord(true);
        txtDialogoSteve.setLineWrap(true);
        txtDialogoSteve.setEditable(false);
        txtDialogoSteve.setFont(new Font("SansSerif", Font.ITALIC, 11));
        txtDialogoSteve.setForeground(new Color(160, 160, 180));
        txtDialogoSteve.setBackground(new Color(30, 30, 50));
        txtDialogoSteve.setBorder(new EmptyBorder(4, 6, 4, 6));
        card.add(txtDialogoSteve, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildCardAres() {
        JPanel card = darkCard();
        card.setLayout(new BorderLayout(0, 6));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        top.setOpaque(false);
        top.add(iconCircle("A", new Color(153, 60, 29)));
        JPanel names = new JPanel(new GridLayout(2, 1));
        names.setOpaque(false);
        names.add(cardName("Ares"));
        names.add(cardSub("Dios de la Guerra"));
        top.add(names);
        card.add(top, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout(0, 2));
        mid.setOpaque(false);
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        JLabel lbl = tinyLabel("Salud");
        lblAresHPVal = new JLabel("150 / 150");
        lblAresHPVal.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblAresHPVal.setForeground(new Color(160, 160, 160));
        row.add(lbl, BorderLayout.WEST);
        row.add(lblAresHPVal, BorderLayout.EAST);
        barAres = makeBar(new Color(216, 90, 48), 150, 150);
        mid.add(row, BorderLayout.NORTH);
        mid.add(barAres, BorderLayout.CENTER);
        card.add(mid, BorderLayout.CENTER);

        JPanel tags = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        tags.setOpaque(false);
        lblFaseVal = makeTag("Fase final: OFF");
        tags.add(lblFaseVal);
        card.add(tags, BorderLayout.SOUTH);
        return card;
    }

    // ── Centro + derecha en otro split ────────────────────────────
    private JSplitPane buildMiddleAndRight() {
        JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildMiddle(), buildRight());
        sp.setDividerLocation(430);
        sp.setDividerSize(1);
        sp.setEnabled(false);
        sp.setBackground(new Color(26, 26, 46));
        return sp;
    }

    // ── Panel central: log + objetos + botones ────────────────────
    private JPanel buildMiddle() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(new Color(26, 26, 46));
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Log
        JPanel logPanel = new JPanel(new BorderLayout(0, 4));
        logPanel.setOpaque(false);
        logPanel.add(sectionLabel("REGISTRO DE COMBATE"), BorderLayout.NORTH);
        txtLog = new JTextArea();
        txtLog.setEditable(false);
        txtLog.setLineWrap(true);
        txtLog.setWrapStyleWord(true);
        txtLog.setFont(new Font("Monospaced", Font.PLAIN, 11));
        txtLog.setBackground(new Color(18, 18, 32));
        txtLog.setForeground(new Color(180, 180, 200));
        txtLog.setBorder(new EmptyBorder(6, 8, 6, 8));
        JScrollPane scroll = new JScrollPane(txtLog);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 90), 1));
        scroll.setPreferredSize(new Dimension(0, 180));
        logPanel.add(scroll, BorderLayout.CENTER);
        p.add(logPanel, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(0, 8));
        bottom.setOpaque(false);

        // Objetos
        JPanel objPanel = new JPanel(new BorderLayout(0, 4));
        objPanel.setOpaque(false);
        objPanel.add(sectionLabel("OBJETOS ESPECIALES"), BorderLayout.NORTH);
        JPanel pills = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        pills.setOpaque(false);
        btnLazo   = pillButton("Lazo de la Verdad");
        btnEscudo = pillButton("Escudo de Atenea");
        pills.add(btnLazo);
        pills.add(btnEscudo);
        objPanel.add(pills, BorderLayout.CENTER);
        bottom.add(objPanel, BorderLayout.NORTH);

        // Botones de acción
        JPanel accionPanel = new JPanel(new BorderLayout(0, 4));
        accionPanel.setOpaque(false);
        accionPanel.add(sectionLabel("ACCIONES"), BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(2, 2, 6, 6));
        grid.setOpaque(false);
        btnAtacar = actionButton("Atacar",        new Color(170, 50, 50));
        btnFuria  = actionButton("Activar Furia", new Color(60, 60, 100));
        btnSteve  = actionButton("Hablar con Steve", new Color(40, 90, 80));
        btnNuevo  = actionButton("Nuevo Juego",   new Color(50, 50, 70));
        grid.add(btnAtacar);
        grid.add(btnFuria);
        grid.add(btnSteve);
        grid.add(btnNuevo);
        accionPanel.add(grid, BorderLayout.CENTER);
        bottom.add(accionPanel, BorderLayout.CENTER);
        p.add(bottom, BorderLayout.SOUTH);

        return p;
    }

    // ── Panel derecho: escenario + estado + diálogo ───────────────
    private JPanel buildRight() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(new Color(22, 22, 38));
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        p.add(sectionLabel("ESCENARIO"));
        p.add(Box.createVerticalStrut(4));
        JPanel esc = darkCard();
        esc.setLayout(new GridLayout(3, 1, 0, 3));
        JLabel lNombre = cardName("Themyscira");
        lNombre.setName("escNombre");
        lblEscenarioVal = lNombre;
        esc.add(lNombre);
        lblUbicacionVal = cardSub("Isla de las Amazonas");
        esc.add(lblUbicacionVal);
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        row.setOpaque(false);
        row.add(tinyLabel("Enemigos: "));
        lblEnemigosVal = tinyLabel("1");
        lblEnemigosVal.setForeground(new Color(240, 153, 123));
        row.add(lblEnemigosVal);
        esc.add(row);
        p.add(esc);

        p.add(Box.createVerticalStrut(10));
        p.add(sectionLabel("ESTADO DEL JUEGO"));
        p.add(Box.createVerticalStrut(4));
        JPanel est = darkCard();
        est.setLayout(new GridLayout(3, 2, 4, 4));
        est.add(tinyLabel("Terminado:"));
        lblTerminadoVal = tinyLabel("No");
        lblTerminadoVal.setForeground(new Color(226, 75, 74));
        est.add(lblTerminadoVal);
        est.add(tinyLabel("Victoria:"));
        lblVictoriaVal = tinyLabel("—");
        est.add(lblVictoriaVal);
        est.add(tinyLabel("Turno:"));
        lblTurnoVal = tinyLabel("1");
        est.add(lblTurnoVal);
        p.add(est);

        p.add(Box.createVerticalStrut(10));
        p.add(sectionLabel("DIALOGO ACTIVO"));
        p.add(Box.createVerticalStrut(4));
        txtDialogoDiana = new JTextArea("Luchare por quienes no pueden hacerlo.");
        txtDialogoDiana.setWrapStyleWord(true);
        txtDialogoDiana.setLineWrap(true);
        txtDialogoDiana.setEditable(false);
        txtDialogoDiana.setFont(new Font("SansSerif", Font.ITALIC, 11));
        txtDialogoDiana.setForeground(new Color(160, 160, 200));
        txtDialogoDiana.setBackground(new Color(28, 28, 48));
        txtDialogoDiana.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 90), 1),
                new EmptyBorder(6, 8, 6, 8)));
        txtDialogoDiana.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        p.add(txtDialogoDiana);
        p.add(Box.createVerticalGlue());
        return p;
    }

    // ── Barra de estado ───────────────────────────────────────────
    private JPanel buildStatus() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(20, 20, 40));
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(80, 80, 120)));
        lblStatus = new JLabel("  Juego en curso   |   MVC: Modelo · Vista · Controlador");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(new Color(120, 120, 160));
        bar.add(lblStatus, BorderLayout.WEST);
        return bar;
    }

    // ── Helpers de construcción ───────────────────────────────────

    private JPanel darkCard() {
        JPanel c = new JPanel();
        c.setBackground(new Color(32, 32, 54));
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 90), 1),
                new EmptyBorder(8, 8, 8, 8)));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));
        return c;
    }

    private JLabel iconCircle(String letter, Color bg) {
        JLabel l = new JLabel(letter, SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(bg);
                g.fillOval(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        l.setOpaque(false);
        l.setForeground(Color.WHITE);
        l.setFont(new Font("SansSerif", Font.BOLD, 14));
        l.setPreferredSize(new Dimension(32, 32));
        return l;
    }

    private JLabel cardName(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.BOLD, 12));
        l.setForeground(new Color(220, 220, 240));
        return l;
    }

    private JLabel cardSub(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.PLAIN, 10));
        l.setForeground(new Color(130, 130, 160));
        return l;
    }

    private JLabel tinyLabel(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.PLAIN, 11));
        l.setForeground(new Color(140, 140, 170));
        return l;
    }

    private JLabel sectionLabel(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.BOLD, 10));
        l.setForeground(new Color(100, 100, 140));
        return l;
    }

    private JLabel makeTag(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.PLAIN, 10));
        l.setForeground(new Color(130, 130, 160));
        l.setBackground(new Color(40, 40, 60));
        l.setOpaque(true);
        l.setBorder(new EmptyBorder(2, 6, 2, 6));
        return l;
    }

    private JProgressBar makeBar(Color color, int value, int max) {
        JProgressBar b = new JProgressBar(0, max);
        b.setValue(value);
        b.setStringPainted(false);
        b.setForeground(color);
        b.setBackground(new Color(40, 40, 60));
        b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(0, 6));
        return b;
    }

    private JButton pillButton(String txt) {
        JButton b = new JButton(txt);
        b.setFont(new Font("SansSerif", Font.PLAIN, 11));
        b.setBackground(new Color(40, 40, 65));
        b.setForeground(new Color(200, 180, 100));
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 180, 100, 100), 1),
                new EmptyBorder(3, 10, 3, 10)));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JButton actionButton(String txt, Color bg) {
        JButton b = new JButton(txt);
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setBackground(bg);
        b.setForeground(new Color(230, 230, 245));
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(bg.brighter(), 1),
                new EmptyBorder(7, 10, 7, 10)));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ── Métodos para actualizar la vista (llamados por el controlador) ──

    public void agregarLog(String msg) {
        txtLog.append(msg + "\n");
        txtLog.setCaretPosition(txtLog.getDocument().getLength());
    }

    public void actualizarDiana(int hp, boolean furia, boolean escudo) {
        barDiana.setValue(hp);
        barDiana.setForeground(hp > 50 ? new Color(29, 158, 117) :
                               hp > 25 ? new Color(186, 117, 23) :
                                         new Color(226, 75, 74));
        lblDianaHPVal.setText(hp + " / 100");
        lblTurnoVal.setText(String.valueOf(hp)); // se sobreescribe en actualizarTurno
        lblFuriaVal.setText("Furia: "  + (furia  ? "ON" : "OFF"));
        lblFuriaVal.setForeground(furia  ? new Color(216, 90, 48)  : new Color(130, 130, 160));
        lblEscudoVal.setText("Escudo: " + (escudo ? "ON" : "OFF"));
        lblEscudoVal.setForeground(escudo ? new Color(24, 95, 165) : new Color(130, 130, 160));
    }

    public void actualizarAres(int hp, boolean faseFinal) {
        barAres.setValue(hp);
        lblAresHPVal.setText(hp + " / 150");
        lblFaseVal.setText("Fase final: " + (faseFinal ? "ON" : "OFF"));
        lblFaseVal.setForeground(faseFinal ? new Color(216, 90, 48) : new Color(130, 130, 160));
    }

    public void actualizarTurno(int t) {
        lblTurnoVal.setText(String.valueOf(t));
    }

    public void actualizarEstado(boolean terminado, boolean victoria) {
        lblTerminadoVal.setText(terminado ? "Si" : "No");
        lblTerminadoVal.setForeground(terminado ? new Color(29, 158, 117) : new Color(226, 75, 74));
        lblVictoriaVal.setText(terminado ? (victoria ? "Victoria!" : "Derrota") : "—");
        lblVictoriaVal.setForeground(victoria ? new Color(29, 158, 117) : new Color(226, 75, 74));
        if (terminado) {
            btnAtacar.setEnabled(false);
            btnFuria.setEnabled(false);
            btnSteve.setEnabled(false);
            btnLazo.setEnabled(false);
            btnEscudo.setEnabled(false);
            lblStatus.setText("  " + (victoria ? "Victoria! Diana ha derrotado a Ares." :
                    "Derrota. Diana ha caido en combate.") +
                    "  |  Presiona Nuevo Juego para reiniciar.");
        }
    }

    public void resetVista() {
        btnAtacar.setEnabled(true);
        btnFuria.setEnabled(true);
        btnSteve.setEnabled(true);
        btnLazo.setEnabled(true);
        btnEscudo.setEnabled(true);
        txtLog.setText("");
        lblStatus.setText("  Juego en curso   |   MVC: Modelo · Vista · Controlador");
        txtDialogoSteve.setText("Confia en mi, Diana.");
        txtDialogoDiana.setText("Luchare por quienes no pueden hacerlo.");
        lblTerminadoVal.setText("No");
        lblVictoriaVal.setText("—");
    }
}
