/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.VistaJuegoSwing;
import modelo.Ares;
import modelo.Juego;
import modelo.Objeto;
import modelo.WonderWoman;

public class JuegoControlador {

    private Juego juego;
    private VistaJuegoSwing vista;

    private static final String[] DIALOGOS_DIANA = {
        "Luchare por quienes no pueden hacerlo.",
        "El amor es la respuesta, no la guerra.",
        "No soy tu enemiga, Ares.",
        "Por las amazonas!"
    };

    public JuegoControlador() {
        juego = new Juego();
        vista = new VistaJuegoSwing();
        conectarBotones();
        sincronizarVista();
        vista.agregarLog("— El juego ha comenzado en Themyscira —");
        vista.agregarLog("Diana Prince entra en combate contra Ares.");
    }

    public void iniciar() {
        vista.setVisible(true);
    }

    private void conectarBotones() {
        vista.btnAtacar.addActionListener(e -> accionAtacar());
        vista.btnFuria.addActionListener(e  -> accionActivarFuria());
        vista.btnSteve.addActionListener(e  -> accionHablarConSteve());
        vista.btnLazo.addActionListener(e   -> accionUsarLazo());
        vista.btnEscudo.addActionListener(e -> accionUsarEscudo());
        vista.btnNuevo.addActionListener(e  -> accionNuevoJuego());
    }

    private void accionAtacar() {
        if (juego.isTerminado()) return;

        WonderWoman diana = juego.getDiana();
        Ares ares = juego.getAres();

        int danio = diana.isModoFuria() ? diana.DANIOFURIA : diana.DANIONORMAL;
        ares.recibirDanio(danio);
        vista.agregarLog("Diana ataca a Ares: -" + danio + " HP");

        if (ares.getSalud() <= 75 && !ares.isFaseFinal()) {
            ares.activarFaseFinal();
            vista.agregarLog("Ares activa su fase final! +20 de fuerza.");
        }

        if (ares.estaVivo()) {
            int danioAres = ares.isFaseFinal() ? 25 : ares.getFuerza();
            int recibido  = diana.recibirDanioConInfo(danioAres);
            vista.agregarLog("Ares contraataca: -" + recibido + " HP" +
                    (diana.isEscudoActivo() ? " (escudo activo)" : ""));
        }

        juego.avanzarTurno();
        actualizarDialogoDiana();
        sincronizarVista();
        terminarJuego(ares.getSalud() <= 0);
    }

    private void accionActivarFuria() {
        juego.getDiana().activarFuria();
        boolean f = juego.getDiana().isModoFuria();
        vista.agregarLog(f ? "Diana activa el Modo Furia (daño x2)." : "Diana desactiva el Modo Furia.");
        sincronizarVista();
    }

    private void accionUsarLazo() {
        Objeto lazo = juego.getLazo();
        if (!lazo.estaDisponible()) { vista.agregarLog("El lazo ya fue usado."); return; }
        lazo.usar();
        juego.getAres().recibirDanio(lazo.getReduccionFuerza());
        juego.getAres().reducirFuerza(10);
        vista.agregarLog("Diana usa el Lazo de la Verdad: Ares pierde " + lazo.getReduccionFuerza() + " HP y fuerza reducida.");
        vista.btnLazo.setEnabled(false);
        juego.avanzarTurno();
        sincronizarVista();
        terminarJuego(juego.getAres().getSalud() <= 0);
    }

    private void accionUsarEscudo() {
        Objeto escudo = juego.getEscudo();
        if (!escudo.estaDisponible()) { vista.agregarLog("El escudo ya fue usado."); return; }
        escudo.usar();
        juego.getDiana().activarEscudo();
        vista.agregarLog("Diana activa el Escudo de Atenea: daño recibido reducido al 40%.");
        vista.btnEscudo.setEnabled(false);
        sincronizarVista();
    }

    private void accionHablarConSteve() {
        if (juego.isTerminado()) return;
        String dialogo = juego.getSteve().getSiguienteDialogo();
        vista.txtDialogoSteve.setText(dialogo);
        vista.agregarLog("Steve Trevor: " + dialogo);
        juego.getDiana().setSalud(juego.getDiana().getSalud() + 10);
        vista.agregarLog("Steve ayuda a Diana: +10 HP");
        juego.avanzarTurno();
        sincronizarVista();
    }

    private void accionNuevoJuego() {
        juego.reiniciar();
        vista.resetVista();
        sincronizarVista();
        vista.agregarLog("— Nuevo juego iniciado en Themyscira —");
    }

    private void terminarJuego(boolean victoria) {
        if (!victoria && !juego.getDiana().estaVivo()) {
            juego.terminar(false);
            vista.agregarLog("Ares ha vencido. Diana ha caido.");
            vista.actualizarEstado(true, false);
        } else if (victoria) {
            juego.terminar(true);
            vista.agregarLog("Victoria! Diana ha derrotado a Ares y salvado al mundo.");
            vista.actualizarEstado(true, true);
        }
    }

    private void actualizarDialogoDiana() {
        int t = juego.getTurno();
        vista.txtDialogoDiana.setText(DIALOGOS_DIANA[t % DIALOGOS_DIANA.length]);
    }

    private void sincronizarVista() {
        WonderWoman diana = juego.getDiana();
        Ares ares         = juego.getAres();

        vista.actualizarDiana(diana.getSalud(), diana.isModoFuria(), diana.isEscudoActivo());
        vista.actualizarAres(ares.getSalud(), ares.isFaseFinal());
        vista.actualizarTurno(juego.getTurno());

        // HUD superior
        vista.lblTurnoVal.setText(String.valueOf(juego.getTurno()));
        vista.lblEscenarioVal.setText(juego.getEscenario().getNombre());
    }
}

