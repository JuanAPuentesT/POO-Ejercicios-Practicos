package juego;

import controlador.HogwartsControlador;


public class HarryPotterJuego
{
    public static void main(String[] args)
    {
        java.awt.EventQueue.invokeLater(() ->
        {
            new HogwartsControlador().iniciar();
        });
    }
}
