package modelo;


public class Profesores extends NPC
{
    private String materia;

    public Profesores(String nombre, Casa casa, String materia)
    {
        super(nombre, casa, 10, Habilidades.LEGILIMENCY, "Profesor");
        this.materia = materia;
        salud = 150;
        magia = 150;
        hechizosAprendidos.add(new Hechizo("Protego Maxima",Elemento.LUZ,25,0));
        hechizosAprendidos.add(new Hechizo("Avada Kedavra",Elemento.OSCURIDAD,50, 100));
    }

    public String getMateria() { return materia; }

    @Override
    public String toString() { 
        return nombre + " (Profesor de " + materia + ")"; 
    }
}
