package modelo;



public enum TipoObjeto
{
    OFENSIVO,DEFENSIVO,CURATIVO,UTILITARIO
}
