package modelo;


public enum Item
{
   VARITA,POCION,CAPA,LIBRO,AMULETO,ESCOBA
}
