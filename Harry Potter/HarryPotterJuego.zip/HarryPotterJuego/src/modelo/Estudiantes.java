package modelo;


public class Estudiantes extends NPC
{
    private int anioEscolar;

    public Estudiantes(String nombre, Casa casa, int anioEscolar)
    {
        super(nombre, casa, anioEscolar, Habilidades.PATRONUS, "Estudiante");
        this.anioEscolar = anioEscolar;
        hechizosAprendidos.add(new Hechizo("Wingardium Leviosa", Elemento.TIERRA, 10, 10));
    }

    public void estudiar()
    {
        lvlMagia = Math.min(lvlMagia + 1, 10);
        System.out.println(nombre + " estudia. Nivel magia: " + lvlMagia);
    }

    public int getAnioEscolar() { return anioEscolar; }

    @Override
    public String toString() { return nombre + " (Estudiante - " + casaHogwarts + " - Año " + anioEscolar + ")"; }
}
