package modelo;


public class ObjetoMagico
{
    protected String nombre;
    protected Item item;
    protected TipoObjeto tipo;
    private boolean disponible;
    private int valor;      // curacion o bonificacion de danio

    public ObjetoMagico(String nombre, Item item, TipoObjeto tipo, int valor)
    {
        this.nombre = nombre;
        this.item = item;
        this.tipo = tipo;
        this.valor = valor;
        this.disponible = true;
    }

    public void usar()
    {
        if (disponible)
        {
            disponible = false;
            System.out.println("Se usa: " + nombre);
        }
    }

    public boolean estaDisponible(){ 
        return disponible;  
    }
    public String getNombre(){ 
        return nombre;      
    }
    public void setNombre(String n){ 
        nombre = n;      
    }
    public Item getItem(){ 
        return item;       
    }
    public TipoObjeto getTipo(){
        return tipo;        
    }
    public int getValor(){ 
        return valor;       
    }

    @Override
    public String toString()
    {
        return nombre + " [" + item + "/" + tipo + "] valor=" + valor;
    }
}
