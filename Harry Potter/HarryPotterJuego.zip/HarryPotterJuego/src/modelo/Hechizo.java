package modelo;

// ============================================================
//  MODELO - Hechizo.java
//  Representa un hechizo que puede lanzar un personaje
// ============================================================

public class Hechizo
{
    private String   nombre;
    private Elemento elemento;
    private double   consumoMagia;
    private int      danio;

    public Hechizo(String nombre, Elemento elemento, double consumoMagia, int danio)
    {
        this.nombre       = nombre;
        this.elemento     = elemento;
        this.consumoMagia = consumoMagia;
        this.danio        = danio;
    }

    public double getConsumoMagia()              { return consumoMagia; }
    public void   setConsumoMagia(double c)      { consumoMagia = c;    }
    public String   getNombre()                  { return nombre;       }
    public Elemento getElemento()                { return elemento;     }
    public int      getDanio()                   { return danio;        }

    @Override
    public String toString()
    {
        return nombre + " [" + elemento + "] - Danio: " + danio + " | Magia: " + consumoMagia;
    }
}
