package modelo;

import java.util.ArrayList;
import java.util.List;



public abstract class Personaje
{
    public static final int MAGIA_MAX = 100;
    public static final int SALUD_MAX = 100;

    protected String      nombre;
    protected Casa        casaHogwarts;
    protected int         lvlMagia;
    protected Habilidades habilidadesEspeciales;
    protected int         salud;
    protected int         magia;
    protected List<Hechizo>      hechizosAprendidos;
    protected List<ObjetoMagico> inventario;

    public Personaje(String nombre, Casa casaHogwarts, int lvlMagia, Habilidades habilidad)
    {
        this.nombre               = nombre;
        this.casaHogwarts         = casaHogwarts;
        this.lvlMagia             = lvlMagia;
        this.habilidadesEspeciales = habilidad;
        this.salud                = SALUD_MAX;
        this.magia                = MAGIA_MAX;
        this.hechizosAprendidos   = new ArrayList<>();
        this.inventario           = new ArrayList<>();
    }

    // Metodos abstractos
    public abstract void entrarEnCombate();
    public abstract void interactuar(Personaje p);

    // Metodos concretos
    public void asistirAClases()
    {
        lvlMagia = Math.min(lvlMagia + 1, 10);
        System.out.println(nombre + " asiste a clases. Nivel magia: " + lvlMagia);
    }

    public void aprenderHechizo(Hechizo h)
    {
        hechizosAprendidos.add(h);
        System.out.println(nombre + " aprende: " + h.getNombre());
    }

    public void usarObjeto(ObjetoMagico o)
    {
        if (o.estaDisponible())
        {
            o.usar();
            if (o.getTipo() == TipoObjeto.CURATIVO)
                salud = Math.min(SALUD_MAX, salud + o.getValor());
        }
    }

    public void usarHechizo(Hechizo h)
    {
        if (magia >= h.getConsumoMagia())
            magia -= (int) h.getConsumoMagia();
    }

    public boolean estaVivo()            { return salud > 0;                    }
    public void    recibirDanio(int d)   { salud = Math.max(0, salud - d);      }
    public void    restaurarMagia(int m) { magia = Math.min(MAGIA_MAX, magia+m);}

    // Getters / Setters
    public String      getNombre()         { return nombre;               }
    public int         getLvlMagia()       { return lvlMagia;             }
    public void        setLvlMagia(int l)  { lvlMagia = l;                }
    public Casa        getCasa()           { return casaHogwarts;         }
    public Habilidades getHabilidad()      { return habilidadesEspeciales;}
    public int         getSalud()          { return salud;                }
    public void        setSalud(int s)     { salud = Math.max(0, s);      }
    public int         getMagia()          { return magia;                }
    public List<Hechizo>      getHechizos(){ return hechizosAprendidos;   }
    public List<ObjetoMagico> getInventario(){ return inventario;         }
}
