package modelo;

import java.util.ArrayList;
import java.util.List;


//  Hogwarts: contiene todos los elementos del juego

public class Escuela
{
    protected String  nombre;
    protected List<Casa> casas;
    protected List<Escenario> escenarios;
    protected List<Estudiantes> estudiantes;
    protected List<Profesores> profesores;
    protected List<Criaturas> criaturas;

    // Estado del juego
    private Usuario jugador;
    private Duelo dueloActual;
    private int turno;
    private boolean juegoTerminado;

    public Escuela(String nombre, Usuario jugador)
    {
        this.nombre = nombre;
        this.jugador = jugador;
        this.casas = new ArrayList<>();
        this.escenarios = new ArrayList<>();
        this.estudiantes = new ArrayList<>();
        this.profesores = new ArrayList<>();
        this.criaturas = new ArrayList<>();
        this.turno = 1;
        this.juegoTerminado = false;

        inicializarEscuela();
    }

    private void inicializarEscuela()
    {
        // crea el cmbbox con casas
        for (Casa c : Casa.values()) casas.add(c);

        // Escenarios
        escenarios.add(new Escenario("Gran Salon","Hogwarts",0,0));
        escenarios.add(new Escenario("Torre Gryffindor","Hogwarts",1,0));
        escenarios.add(new Escenario("Salon de Clases","Hogwarts",0,1));
        escenarios.add(new Escenario("Bosque Prohibido","Exterior",2,2));

        // NPCs
        Profesores voldemort = new Profesores("Lord Voldemort",Casa.SLYTHERIN,"Artes Oscuras");
        voldemort.aprenderHechizo(new Hechizo("Cruciatus",Elemento.OSCURIDAD,30,45));
        voldemort.aprenderHechizo(new Hechizo("Avada Kedavra",Elemento.OSCURIDAD,50,100));
        profesores.add(voldemort);
        profesores.add(new Profesores("Albus Dumbledore",Casa.GRYFFINDOR,"Magia Avanzada"));

        Estudiantes draco = new Estudiantes("Draco Malfoy",Casa.SLYTHERIN,6);
        draco.aprenderHechizo(new Hechizo("Expulso", Elemento.RAYO,20,35));
        estudiantes.add(draco);
        estudiantes.add(new Estudiantes("Hermione Granger",Casa.GRYFFINDOR, 6));

        criaturas.add(new Criaturas("Basilisco","Serpiente gigante",40));
        criaturas.add(new Criaturas("Dementor", "Dementor",25));
        criaturas.add(new Criaturas("Troll", "Troll de montana",35));
    }

    public void reiniciar(String nombreJugador, Casa casa)
    {
        jugador = new Usuario(nombreJugador, casa);
        dueloActual = null;
        turno = 1;
        juegoTerminado = false;
        inicializarEscuela();
    }

    public Duelo iniciarDuelo(Personaje rival)
    {
        dueloActual = new Duelo(jugador, rival);
        dueloActual.comenzarDuelo();
        return dueloActual;
    }

    public void aggEstudiante(Estudiantes e) { 
        estudiantes.add(e); 
    }
    public void aggProfesor(Profesores p){
        profesores.add(p);  
    }

    public Personaje buscarPersonaje(String nombre)
    {
        for (Profesores p : profesores)
            if (p.getNombre().equalsIgnoreCase(nombre)) return p;
        for (Estudiantes e : estudiantes)
            if (e.getNombre().equalsIgnoreCase(nombre)) return e;
        for (Criaturas c : criaturas)
            if (c.getNombre().equalsIgnoreCase(nombre)) return c;
        return null;
    }

    public void avanzarTurno(){
        turno++; 
    }
    public void terminarJuego(){ 
        juegoTerminado = true; 
    }

    public Usuario  getJugador(){ 
        return jugador;        
    }
    public Duelo getDuelo(){ 
        return dueloActual;    
    }
    public int getTurno(){ 
        return turno;          
    }
    public boolean isTerminado(){ 
        return juegoTerminado; 
    }
    public String getNombre(){ 
        return nombre;         
    }
    public List<Escenario> getEscenarios(){
        return escenarios;     
    }
    public List<Profesores> getProfesores(){
        return profesores;     
    }
    public List<Estudiantes>getEstudiantes(){
        return estudiantes;    
    }
    public List<Criaturas> getCriaturas(){ 
        return criaturas;     
    }

    
    
}
