package modelo;


public class Duelo
{
    private Personaje retador;
    private Personaje rival;
    private Personaje ganador;
    private boolean activo;
    private int turno;
    private String ultimoEvento;

    public Duelo(Personaje retador, Personaje rival)
    {
        this.retador = retador;
        this.rival = rival;
        this.ganador = null;
        this.activo = false;
        this.turno = 0;
        this.ultimoEvento = "";
    }

    public void comenzarDuelo()
    {
        activo = true;
        turno  = 1;
        ultimoEvento = "El duelo entre " + retador.getNombre()+ " y " + rival.getNombre() + " ha comenzado!";
        System.out.println(ultimoEvento);
    }

      //Ejecuta un intercambio de ataques con los hechizos dados.
      //Devuelve la descripcion del turno para mostrar en el log.
    public String ejecutarTurno(Hechizo hechizoRetador, Hechizo hechizoRival)
    {
        if (!activo) return "El duelo no esta activo.";
        StringBuilder sb = new StringBuilder();

        // Retador ataca
        if (hechizoRetador != null && retador.getMagia() >= hechizoRetador.getConsumoMagia())
        {
            retador.usarHechizo(hechizoRetador);
            rival.recibirDanio(hechizoRetador.getDanio());
            sb.append(retador.getNombre()).append(" lanza ").append(hechizoRetador.getNombre()).append(": -").append(hechizoRetador.getDanio()).append(" HP al rival.\n");
        }

        // Rival contraataca si sigue vivo
        if (rival.estaVivo() && hechizoRival != null && rival.getMagia() >= hechizoRival.getConsumoMagia())
        {
            rival.usarHechizo(hechizoRival);
            retador.recibirDanio(hechizoRival.getDanio());
            sb.append(rival.getNombre()).append(" contraataca con ").append(hechizoRival.getNombre()).append(": -").append(hechizoRival.getDanio()).append(" HP al retador.\n");
        }

        turno++;
        ultimoEvento = sb.toString().trim();

        if (!retador.estaVivo() || !rival.estaVivo())
            definirGanador();

        return ultimoEvento;
    }

    public void finalizarDuelo()
    {
        activo = false;
        definirGanador();
    }

    public void definirGanador()
    {
        if (retador.estaVivo() && !rival.estaVivo())     ganador = retador;
        else if (!retador.estaVivo() && rival.estaVivo()) ganador = rival;
        activo = false;
    }

    public Personaje getRetador(){ 
        return retador;      
    }
    public Personaje getRival(){ 
        return rival;        
    }
    public Personaje getGanador(){
        return ganador;      
    }
    public boolean isActivo(){ 
        return activo;       
    }
    public int getTurno(){ 
        return turno;       
    }
    public String  getUltimoEvento() {
        return ultimoEvento; 
    }
}
