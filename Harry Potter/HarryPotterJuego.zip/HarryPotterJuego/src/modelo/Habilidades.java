package modelo;

//  Habilidades especiales de los personajes


public enum Habilidades
{
    OCCLUMENCY,LEGILIMENCY,ANIMAGUS,PATRONUS,PARSELTONGUE,VUELO
}
