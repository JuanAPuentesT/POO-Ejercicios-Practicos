package modelo;

import java.util.ArrayList;
import java.util.List;



public class Dialogo
{
    protected List<Personaje> participantes;
    protected String contenido;
    private boolean activo;

    public Dialogo(String contenido)
    {
        this.participantes = new ArrayList<>();
        this.contenido  = contenido;
        this.activo = false;
    }

    public void agregarParticipante(Personaje p){ 
        participantes.add(p); 
    }

    public void iniciarDialogo()
    {
        activo = true;
        System.out.println("Dialogo iniciado: " + contenido);
    }

    public void finalizarDialogo()
    {
        activo = false;
        System.out.println("Dialogo finalizado.");
    }

    public String getContenido(){ 
        return contenido;     
    }
    public List<Personaje>  getParticipantes() { return participantes; }
    public void setContenido(String c) {
        contenido = c;    
    }
    public boolean isActivo(){ 
        return activo;        
    }
}
