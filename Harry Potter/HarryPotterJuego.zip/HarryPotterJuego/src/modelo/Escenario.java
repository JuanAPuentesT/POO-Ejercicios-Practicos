package modelo;


public class Escenario
{
    private String lugar;
    private String nombre;
    private int coordenadaEnX;
    private int coordenadaEnY;

    public Escenario(String nombre, String lugar, int x, int y)
    {
        this.nombre = nombre;
        this.lugar = lugar;
        this.coordenadaEnX = x;
        this.coordenadaEnY = y;
    }

    public void cargar() { System.out.println("Escenario cargado: " + nombre + " en " + lugar); }

    public String getLugar(){ 
        return lugar;         
    }
    public String getNombre(){ 
        return nombre;        
    }
    public int getCoordenadaEnX(){ 
        return coordenadaEnX; 
    }
    public int getCoordenadaEnY(){ 
        return coordenadaEnY; 
    }
    public void setLugar(String l){ 
        lugar = l;            
    }
    public void setNombre(String n){ 
        nombre = n;           
    }
    public void setCoordenadaEnX(int x) { 
        coordenadaEnX = x; 
    }
    public void setCoordenadaEnY(int y) {
        coordenadaEnY = y; 
    }
}
