package modelo;


public enum Casa
{
    GRYFFINDOR,HUFFLEPUFF,RAVENCLAW,SLYTHERIN
}
