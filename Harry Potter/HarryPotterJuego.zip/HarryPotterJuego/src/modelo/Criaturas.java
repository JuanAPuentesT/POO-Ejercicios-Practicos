package modelo;




public class Criaturas extends NPC
{
    private String especie;
    private int    fuerza;

    public Criaturas(String nombre, String especie, int fuerza)
    {
        super(nombre, Casa.SLYTHERIN, 3, Habilidades.ANIMAGUS, "Criatura");
        this.especie = especie;
        this.fuerza  = fuerza;
        salud = 80 + fuerza * 2;
        hechizosAprendidos.add(new Hechizo("Zarpazo", Elemento.TIERRA, 0, fuerza));
    }

    public String getEspecie() { 
        return especie; 
    }
    public int    getFuerza()  { 
        return fuerza;  
    }

    @Override
    public String toString() { return nombre + " (" + especie + " - Fuerza: " + fuerza + ")"; }
}
