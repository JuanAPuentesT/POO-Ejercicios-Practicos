package modelo;


public class Usuario extends Personaje
{
    private String[] secretosDescubiertos;
    private int cantidadSecretos;
    private int puntaje;

    public Usuario(String nombre, Casa casa)
    {
        super(nombre, casa, 1, Habilidades.PATRONUS);
        this.secretosDescubiertos = new String[20];
        this.cantidadSecretos = 0;
        this.puntaje = 0;

        // Hechizos iniciales segun la casa
        hechizosAprendidos.add(new Hechizo("Expelliarmus", Elemento.LUZ,15,20));
        hechizosAprendidos.add(new Hechizo("Stupefy",Elemento.RAYO,20,30));
        hechizosAprendidos.add(new Hechizo("Lumos",Elemento.LUZ,5,5));

        // Objeto inicial
        inventario.add(new ObjetoMagico("Pocion Curativa", Item.POCION, TipoObjeto.CURATIVO, 30));
    }

    @Override
    public void entrarEnCombate()
    {
        System.out.println(nombre + " entra en combate!");
    }

    @Override
    public void interactuar(Personaje p)
    {
        System.out.println(nombre + " interactua con " + p.getNombre());
    }

    public void descubrirSecretos()
    {
        String secreto = "Secreto #" + (cantidadSecretos + 1) + " descubierto";secretosDescubiertos[cantidadSecretos] = secreto;cantidadSecretos++;puntaje += 10;
        System.out.println(nombre + ": " + secreto);
    }

    public int getPuntaje()           { 
        return puntaje;           
    }
    public void addPuntaje(int p)     { 
        puntaje += p;             
    }
    public int getCantidadSecretos()  { 
        return cantidadSecretos;  
    }
}
