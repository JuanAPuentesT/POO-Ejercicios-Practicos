package modelo;



public enum Elemento
{
    FUEGO,AGUA,TIERRA,RAYO,LUZ,OSCURIDAD
}
