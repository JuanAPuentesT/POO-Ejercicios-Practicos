package modelo;


public abstract class NPC extends Personaje
{
    protected String rol;

    public NPC(String nombre, Casa casa, int lvlMagia, Habilidades habilidad, String rol)
    {
        super(nombre, casa, lvlMagia, habilidad);
        this.rol = rol;
    }

    @Override
    public void entrarEnCombate()
    {
        System.out.println(nombre + " [" + rol + "] entra en combate!");
    }

    @Override
    public void interactuar(Personaje p)
    {
        System.out.println(nombre + " interactua con " + p.getNombre());
    }

    public String getRol() { return rol; }
}
