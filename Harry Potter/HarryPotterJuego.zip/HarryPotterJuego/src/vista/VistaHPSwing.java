package vista;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import modelo.*;


public class VistaHPSwing extends JFrame
{
    // Colores tema Hogwarts
    private static final Color BG_DARK = new Color(18, 14, 30);
    private static final Color BG_PANEL = new Color(28, 22, 46);
    private static final Color BG_CARD = new Color(40, 32, 64);
    private static final Color GOLD = new Color(212, 175, 55);
    private static final Color BORDER_C = new Color(80, 65, 110);
    private static final Color TEXT_DIM = new Color(160, 150, 200);
    private static final Color TEXT_MAIN = new Color(230, 225, 245);
    private static final Color GREEN_HP = new Color(50, 180, 100);
    private static final Color BLUE_MP = new Color(80, 140, 220);
    private static final Color RED_BAD = new Color(210, 60, 60);

    // ── HUD ────────────────────────────────────────────────
    public JLabel lblTurnoVal;
    public JLabel lblEscenarioVal;
    public JLabel lblPuntajeVal;

    // ── Tarjeta jugador ────────────────────────────────────
    public JProgressBar barSaludJugador;
    public JProgressBar barMagiaJugador;
    public JLabel       lblSaludJugadorVal;
    public JLabel       lblMagiaJugadorVal;
    public JLabel       lblNivelMagiaVal;
    public JLabel       lblCasaVal;
    public JComboBox<String> cmbHechizos;

    // ── Tarjeta rival ──────────────────────────────────────
    public JProgressBar barSaludRival;
    public JLabel       lblSaludRivalVal;
    public JLabel       lblNombreRivalVal;
    public JLabel       lblTipoRivalVal;

    // ── Log ────────────────────────────────────────────────
    public JTextArea txtLog;

    // ── Seleccion de rival ─────────────────────────────────
    public JComboBox<String> cmbRivales;
    public JButton           btnIniciarDuelo;

    // ── Botones accion ─────────────────────────────────────
    public JButton btnLanzarHechizo;
    public JButton btnUsarPocion;
    public JButton btnDescubrirSecreto;
    public JButton btnAsistirClase;
    public JButton btnNuevoJuego;

    // ── Panel setup (nombre y casa) ────────────────────────
    public JPanel        panelSetup;
    public JPanel        panelJuego;
    public JTextField    txtNombreJugador;
    public JComboBox<String> cmbCasaInicial;
    public JButton       btnComenzar;

    // ── Estado ─────────────────────────────────────────────
    public JLabel lblStatus;

    // ═══════════════════════════════════════════════════════

    public VistaHPSwing()
    {
        super("Harry Potter — Hogwarts");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(BG_DARK);
        setLayout(new CardLayout());

        panelSetup = buildSetup();
        panelJuego = buildJuego();

        add(panelSetup, "setup");
        add(panelJuego, "juego");
    }

    // ── Pantalla de inicio ────────────────────────────────────────
    private JPanel buildSetup()
    {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(BG_DARK);

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(GOLD, 1),new EmptyBorder(30, 40, 30, 40)));

        JLabel titulo = new JLabel("HOGWARTS", SwingConstants.CENTER);
        titulo.setFont(new Font("Serif", Font.BOLD, 28));
        titulo.setForeground(GOLD);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Escuela de Magia y Hechiceria", SwingConstants.CENTER);
        sub.setFont(new Font("Serif", Font.ITALIC, 14));
        sub.setForeground(TEXT_DIM);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblNombre = new JLabel("Tu nombre:");
        lblNombre.setForeground(TEXT_MAIN);
        lblNombre.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtNombreJugador = new JTextField("Harry Potter", 20);
        txtNombreJugador.setBackground(BG_PANEL);
        txtNombreJugador.setForeground(TEXT_MAIN);
        txtNombreJugador.setCaretColor(GOLD);
        txtNombreJugador.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER_C, 1),new EmptyBorder(5, 8, 5, 8)));
        txtNombreJugador.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));

        JLabel lblCasa = new JLabel("Elige tu casa:");
        lblCasa.setForeground(TEXT_MAIN);
        lblCasa.setAlignmentX(Component.LEFT_ALIGNMENT);

        cmbCasaInicial = new JComboBox<>(new String[]{"GRYFFINDOR","HUFFLEPUFF","RAVENCLAW","SLYTHERIN"});
        cmbCasaInicial.setBackground(BG_PANEL);
        cmbCasaInicial.setForeground(TEXT_MAIN);
        cmbCasaInicial.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));

        btnComenzar = new JButton("Entrar a Hogwarts");
        btnComenzar.setFont(new Font("Serif", Font.BOLD, 14));
        btnComenzar.setBackground(new Color(80, 50, 120));
        btnComenzar.setForeground(GOLD);
        btnComenzar.setFocusPainted(false);
        btnComenzar.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(GOLD, 1),new EmptyBorder(8, 20, 8, 20)));
        btnComenzar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnComenzar.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(titulo);
        card.add(Box.createVerticalStrut(4));
        card.add(sub);
        card.add(Box.createVerticalStrut(24));
        card.add(lblNombre);
        card.add(Box.createVerticalStrut(6));
        card.add(txtNombreJugador);
        card.add(Box.createVerticalStrut(14));
        card.add(lblCasa);
        card.add(Box.createVerticalStrut(6));
        card.add(cmbCasaInicial);
        card.add(Box.createVerticalStrut(24));
        card.add(btnComenzar);

        p.add(card);
        return p;
    }

    // ── Pantalla de juego ─────────────────────────────────────────
    private JPanel buildJuego()
    {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(BG_DARK);
        p.add(buildHUD(), BorderLayout.NORTH);
        p.add(buildCenter(),BorderLayout.CENTER);
        p.add(buildStatus(),BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildHUD()
    {
        JPanel hud = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 8));
        hud.setBackground(new Color(14, 10, 24));
        hud.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_C));

        JLabel titulo = new JLabel("  HOGWARTS");
        titulo.setFont(new Font("Serif", Font.BOLD, 15));
        titulo.setForeground(GOLD);
        hud.add(titulo);

        lblTurnoVal    = hudVal("1");
        lblEscenarioVal = hudVal("Gran Salon");
        lblPuntajeVal   = hudVal("0");

        hud.add(hudStat("TURNO",lblTurnoVal));
        hud.add(hudStat("ESCENARIO",lblEscenarioVal));
        hud.add(hudStat("PUNTAJE", lblPuntajeVal));
        return hud;
    }

    private JPanel hudStat(String label, JLabel val)
    {
        JPanel p = new JPanel(new BorderLayout(0, 2));
        p.setBackground(new Color(14, 10, 24));
        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(new Font("SansSerif", Font.PLAIN, 10));
        l.setForeground(TEXT_DIM);
        p.add(l,   BorderLayout.NORTH);
        p.add(val, BorderLayout.SOUTH);
        return p;
    }

    private JLabel hudVal(String txt)
    {
        JLabel l = new JLabel(txt, SwingConstants.CENTER);
        l.setFont(new Font("SansSerif", Font.BOLD, 13));
        l.setForeground(GOLD);
        return l;
    }

    private JSplitPane buildCenter()
    {
        JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,buildLeft(), buildCenterRight());
        sp.setDividerLocation(220);
        sp.setDividerSize(1);
        sp.setEnabled(false);
        sp.setBackground(BG_DARK);
        return sp;
    }

    // ── Panel izquierdo: jugador + rival ─────────────────────────
    private JPanel buildLeft()
    {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG_PANEL);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        p.add(secLabel("TU PERSONAJE"));
        p.add(Box.createVerticalStrut(6));
        p.add(buildCardJugador());
        p.add(Box.createVerticalStrut(10));
        p.add(secLabel("RIVAL ACTUAL"));
        p.add(Box.createVerticalStrut(6));
        p.add(buildCardRival());
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel buildCardJugador()
    {
        JPanel c = darkCard();
        c.setLayout(new BorderLayout(0, 6));

        JPanel top = rowPanel();
        top.add(iconCircle("H", new Color(155, 0, 0)));
        JPanel names = new JPanel(new GridLayout(2, 1));
        names.setOpaque(false);
        names.add(cardName("Harry Potter"));
        lblCasaVal = cardSub("GRYFFINDOR");
        names.add(lblCasaVal);
        top.add(names);
        c.add(top, BorderLayout.NORTH);

        JPanel bars = new JPanel(new GridLayout(4, 1, 0, 3));
        bars.setOpaque(false);

        JPanel r1 = barRow("Salud");
        lblSaludJugadorVal = tinyLabel("100/100");
        r1.add(lblSaludJugadorVal, BorderLayout.EAST);
        bars.add(r1);
        barSaludJugador = makeBar(GREEN_HP, 100, 100);
        bars.add(barSaludJugador);

        JPanel r2 = barRow("Magia");
        lblMagiaJugadorVal = tinyLabel("100/100");
        r2.add(lblMagiaJugadorVal, BorderLayout.EAST);
        bars.add(r2);
        barMagiaJugador = makeBar(BLUE_MP, 100, 100);
        bars.add(barMagiaJugador);
        c.add(bars, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(2, 1, 0, 3));
        bottom.setOpaque(false);
        JPanel rowN = rowPanel();
        rowN.add(tinyLabel("Nivel magia: "));
        lblNivelMagiaVal = tinyLabel("1");
        lblNivelMagiaVal.setForeground(GOLD);
        rowN.add(lblNivelMagiaVal);
        bottom.add(rowN);

        cmbHechizos = new JComboBox<>();
        cmbHechizos.setBackground(BG_CARD);
        cmbHechizos.setForeground(TEXT_MAIN);
        cmbHechizos.setFont(new Font("SansSerif", Font.PLAIN, 11));
        bottom.add(cmbHechizos);
        c.add(bottom, BorderLayout.SOUTH);
        return c;
    }

    private JPanel buildCardRival()
    {
        JPanel c = darkCard();
        c.setLayout(new BorderLayout(0, 6));

        JPanel top = rowPanel();
        top.add(iconCircle("?", new Color(100, 20, 20)));
        JPanel names = new JPanel(new GridLayout(2, 1));
        names.setOpaque(false);
        lblNombreRivalVal = cardName("(ninguno)");
        lblTipoRivalVal   = cardSub("Selecciona un rival");
        names.add(lblNombreRivalVal);
        names.add(lblTipoRivalVal);
        top.add(names);
        c.add(top, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout(0, 2));
        mid.setOpaque(false);
        JPanel row = barRow("Salud rival");
        lblSaludRivalVal = tinyLabel("—");
        row.add(lblSaludRivalVal, BorderLayout.EAST);
        mid.add(row, BorderLayout.NORTH);
        barSaludRival = makeBar(RED_BAD, 0, 100);
        mid.add(barSaludRival, BorderLayout.CENTER);
        c.add(mid, BorderLayout.CENTER);

        JPanel bot = new JPanel(new BorderLayout(0, 4));
        bot.setOpaque(false);
        cmbRivales = new JComboBox<>();
        cmbRivales.setBackground(BG_CARD);
        cmbRivales.setForeground(TEXT_MAIN);
        cmbRivales.setFont(new Font("SansSerif", Font.PLAIN, 11));
        btnIniciarDuelo = pillButton("Iniciar Duelo");
        bot.add(cmbRivales,     BorderLayout.NORTH);
        bot.add(btnIniciarDuelo, BorderLayout.SOUTH);
        c.add(bot, BorderLayout.SOUTH);
        return c;
    }

    // ── Centro derecho: log + acciones ───────────────────────────
    private JSplitPane buildCenterRight()
    {
        JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,buildMiddle(), buildRight());
        sp.setDividerLocation(420);
        sp.setDividerSize(1);
        sp.setEnabled(false);
        return sp;
    }

    private JPanel buildMiddle()
    {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(BG_DARK);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel logPanel = new JPanel(new BorderLayout(0, 4));
        logPanel.setOpaque(false);
        logPanel.add(secLabel("REGISTRO DE EVENTOS"), BorderLayout.NORTH);
        txtLog = new JTextArea();
        txtLog.setEditable(false);
        txtLog.setLineWrap(true);
        txtLog.setWrapStyleWord(true);
        txtLog.setFont(new Font("Monospaced", Font.PLAIN, 11));
        txtLog.setBackground(new Color(12, 9, 20));
        txtLog.setForeground(new Color(190, 185, 220));
        txtLog.setBorder(new EmptyBorder(6, 8, 6, 8));
        JScrollPane scroll = new JScrollPane(txtLog);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_C, 1));
        logPanel.add(scroll, BorderLayout.CENTER);
        p.add(logPanel, BorderLayout.CENTER);

        JPanel accPanel = new JPanel(new BorderLayout(0, 6));
        accPanel.setOpaque(false);
        accPanel.add(secLabel("ACCIONES"), BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(2, 2, 6, 6));
        grid.setOpaque(false);
        btnLanzarHechizo = accionBtn("Lanzar Hechizo",new Color(100, 40, 140));
        btnUsarPocion = accionBtn("Usar Pocion", new Color(30, 100, 60));
        btnDescubrirSecreto = accionBtn("Descubrir Secreto",new Color(40, 70, 120));
        btnAsistirClase  = accionBtn("Asistir a Clase",new Color(80, 60, 20));
        grid.add(btnLanzarHechizo);
        grid.add(btnUsarPocion);
        grid.add(btnDescubrirSecreto);
        grid.add(btnAsistirClase);
        accPanel.add(grid, BorderLayout.CENTER);
        p.add(accPanel, BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildRight()
    {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG_PANEL);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        p.add(secLabel("ESCENARIOS"));
        p.add(Box.createVerticalStrut(4));
        JPanel escCard = darkCard();
        escCard.setLayout(new GridLayout(4, 1, 0, 3));
        String[] locs = {"Gran Salon","Torre Gryffindor","Salon de Clases","Bosque Prohibido"};
        for (String loc : locs)
        {
            JLabel l = tinyLabel("  " + loc);
            l.setOpaque(true);
            l.setBackground(BG_DARK);
            l.setBorder(new EmptyBorder(3, 6, 3, 6));
            escCard.add(l);
        }
        p.add(escCard);

        p.add(Box.createVerticalStrut(10));
        p.add(secLabel("ESTADO"));
        p.add(Box.createVerticalStrut(4));
        JPanel estCard = darkCard();
        estCard.setLayout(new GridLayout(3, 2, 4, 4));
        estCard.add(tinyLabel("Turno:"));
        lblTurnoVal = tinyLabel("1");
        estCard.add(lblTurnoVal);
        estCard.add(tinyLabel("Puntaje:"));
        lblPuntajeVal = tinyLabel("0");
        estCard.add(lblPuntajeVal);
        estCard.add(tinyLabel("Nivel magia:"));
        lblNivelMagiaVal = tinyLabel("1");
        estCard.add(lblNivelMagiaVal);
        p.add(estCard);

        p.add(Box.createVerticalStrut(10));
        btnNuevoJuego = accionBtn("Nuevo Juego", new Color(50, 40, 70));
        btnNuevoJuego.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        p.add(btnNuevoJuego);
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel buildStatus()
    {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(14, 10, 24));
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_C));
        lblStatus = new JLabel("  Bienvenido a Hogwarts   |   MVC: Modelo · Vista · Controlador");
        lblStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblStatus.setForeground(TEXT_DIM);
        bar.add(lblStatus, BorderLayout.WEST);
        return bar;
    }

    // ── Metodos publicos para el Controlador ─────────────────────

    public void mostrarJuego()
    {
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "juego");
    }

    public void agregarLog(String msg)
    {
        txtLog.append(msg + "\n");
        txtLog.setCaretPosition(txtLog.getDocument().getLength());
    }

    public void actualizarJugador(int salud, int magia, int nivelMagia, String casa)
    {
        barSaludJugador.setValue(salud);
        barSaludJugador.setForeground(salud > 50 ? GREEN_HP : salud > 25 ? new Color(200, 150, 0) : RED_BAD);
        lblSaludJugadorVal.setText(salud + "/" + Personaje.SALUD_MAX);
        barMagiaJugador.setValue(magia);
        lblMagiaJugadorVal.setText(magia + "/" + Personaje.MAGIA_MAX);
        lblNivelMagiaVal.setText(String.valueOf(nivelMagia));
        lblCasaVal.setText(casa);
    }

    public void actualizarRival(String nombre, String tipo, int salud, int saludMax)
    {
        lblNombreRivalVal.setText(nombre);
        lblTipoRivalVal.setText(tipo);
        barSaludRival.setMaximum(saludMax);
        barSaludRival.setValue(salud);
        lblSaludRivalVal.setText(salud + "/" + saludMax);
    }

    public void actualizarHUD(int turno, int puntaje, String escenario)
    {
        lblTurnoVal.setText(String.valueOf(turno));
        lblPuntajeVal.setText(String.valueOf(puntaje));
        lblEscenarioVal.setText(escenario);
    }

    public void setStatus(String msg)       { lblStatus.setText("  " + msg); }
    public void habilitarAcciones(boolean b)
    {
        btnLanzarHechizo.setEnabled(b);
        btnUsarPocion.setEnabled(b);
        btnIniciarDuelo.setEnabled(b);
    }

    // ── Helpers de construccion ───────────────────────────────────

    //rowPanel() == Crea un JPanel con un FlowLayout (Los componentes se alinean a la izquierda,6 píxeles de separación horizontal,0 píxeles de separación vertical)
    //p.setOpaque(false); ==  panel transparente
    private JPanel rowPanel()
    {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        p.setOpaque(false);
        return p;
    }
    
    //barRow(String label) == Crea una fila para mostrar una etiqueta junto a una barra. 
    //BorderLayout.WEST = colocar el texto a la izquierda
    private JPanel barRow(String label)
    {
        JPanel r = new JPanel(new BorderLayout());
        r.setOpaque(false);
        r.add(tinyLabel(label), BorderLayout.WEST);
        return r;
    }
    //tarjeta oscura y le asigna un fondo con el background
    // con emptyBorder crea un espacio interno con 8 pixeles de separacion a cada lado
    // c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 250)); == crea un tamaño max pero verticalmeten de no mas de 250px
    private JPanel darkCard()
    {
        JPanel c = new JPanel();
        c.setBackground(BG_CARD);
        c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER_C, 1),new EmptyBorder(8, 8, 8, 8)));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 250));
        return c;
    }

    private JLabel iconCircle(String letter, Color bg)
    {
        JLabel l = new JLabel(letter, SwingConstants.CENTER)
        {
            @Override
            protected void paintComponent(Graphics g)
            {
                g.setColor(bg);
                g.fillOval(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        l.setOpaque(false);
        l.setForeground(Color.WHITE);
        l.setFont(new Font("SansSerif", Font.BOLD, 14));
        l.setPreferredSize(new Dimension(32, 32));
        return l;
    }

    private JLabel secLabel(String txt)
    {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.BOLD, 10));
        l.setForeground(new Color(110, 90, 160));
        return l;
    }

    private JLabel cardName(String txt)
    {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("Serif", Font.BOLD, 13));
        l.setForeground(TEXT_MAIN);
        return l;
    }

    private JLabel cardSub(String txt)
    {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.PLAIN, 10));
        l.setForeground(TEXT_DIM);
        return l;
    }

    private JLabel tinyLabel(String txt)
    {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.PLAIN, 11));
        l.setForeground(TEXT_DIM);
        return l;
    }

    private JProgressBar makeBar(Color color, int value, int max)
    {
        JProgressBar b = new JProgressBar(0, max);
        b.setValue(value);
        b.setStringPainted(false);
        b.setForeground(color);
        b.setBackground(new Color(30, 20, 50));
        b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(0, 6));
        return b;
    }

    private JButton pillButton(String txt)
    {
        JButton b = new JButton(txt);
        b.setFont(new Font("SansSerif", Font.PLAIN, 11));
        b.setBackground(new Color(60, 45, 90));
        b.setForeground(GOLD);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GOLD, 1),
                new EmptyBorder(3, 10, 3, 10)));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JButton accionBtn(String txt, Color bg)
    {
        JButton b = new JButton(txt);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setBackground(bg);
        b.setForeground(new Color(230, 225, 245));
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(bg.brighter(), 1),
                new EmptyBorder(7, 8, 7, 8)));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}
