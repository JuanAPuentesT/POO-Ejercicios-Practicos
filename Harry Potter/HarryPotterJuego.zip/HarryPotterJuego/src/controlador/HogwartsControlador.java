package controlador;

import modelo.*;
import vista.VistaHPSwing;
import java.util.List;


public class HogwartsControlador
{
    private Escuela       escuela;
    private VistaHPSwing  vista;
    private Personaje     rivalActual;
    private Duelo         dueloActual;

    private static final String[] ESCENARIOS =
    {
        "Gran Salon", "Torre Gryffindor", "Salon de Clases", "Bosque Prohibido"
    };

    public HogwartsControlador()
    {
        vista   = new VistaHPSwing();
        escuela = null; // se crea cuando el jugador hace clic en Comenzar
        conectarSetup();
    }

    public void iniciar()
    {
        vista.setVisible(true);
    }

    // ── Setup inicial ─────────────────────────────────────────────
    private void conectarSetup()
    {
        vista.btnComenzar.addActionListener(e ->
        {
            String nombre = vista.txtNombreJugador.getText().trim();
            if (nombre.isEmpty()) nombre = "Harry Potter";
            Casa casa = Casa.valueOf((String) vista.cmbCasaInicial.getSelectedItem());
            iniciarJuego(nombre, casa);
        });
    }

    private void iniciarJuego(String nombre, Casa casa)
    {
        escuela = new Escuela("Hogwarts", new Usuario(nombre, casa));
        conectarBotones();
        cargarRivalesEnCombo();
        cargarHechizosEnCombo();
        sincronizarVista();
        vista.mostrarJuego();
        vista.agregarLog("Bienvenido a Hogwarts, " + nombre + " [" + casa + "]!");
        vista.agregarLog("Tu aventura comienza en el Gran Salon.");
    }

    private void conectarBotones()
    {
        vista.btnLanzarHechizo.addActionListener(e -> accionLanzarHechizo());
        vista.btnUsarPocion.addActionListener(e -> accionUsarPocion());
        vista.btnDescubrirSecreto.addActionListener(e -> accionDescubrirSecreto());
        vista.btnAsistirClase.addActionListener(e -> accionAsistirClase());
        vista.btnIniciarDuelo.addActionListener(e -> accionIniciarDuelo());
        vista.btnNuevoJuego.addActionListener(e -> accionNuevoJuego());
    }

    private void cargarRivalesEnCombo()
    {
        vista.cmbRivales.removeAllItems();
        for (Profesores p : escuela.getProfesores())
            vista.cmbRivales.addItem(p.getNombre());
        for (Estudiantes e : escuela.getEstudiantes())
            vista.cmbRivales.addItem(e.getNombre());
        for (Criaturas c : escuela.getCriaturas())
            vista.cmbRivales.addItem(c.getNombre());
    }

    private void cargarHechizosEnCombo()
    {
        vista.cmbHechizos.removeAllItems();
        for (Hechizo h : escuela.getJugador().getHechizos())
            vista.cmbHechizos.addItem(h.getNombre() + " (" + h.getDanio() + " dmg)");
    }

    // ── Acciones ──────────────────────────────────────────────────

    private void accionLanzarHechizo()
    {
        if (dueloActual == null || !dueloActual.isActivo())
        {
            vista.agregarLog("Debes iniciar un duelo primero.");
            return;
        }
        int idx = vista.cmbHechizos.getSelectedIndex();
        List<Hechizo> hechizos = escuela.getJugador().getHechizos();
        if (idx < 0 || idx >= hechizos.size()) return;

        Hechizo hJugador = hechizos.get(idx);
        
        // El rival usa su primer hechizo disponible
        Hechizo hRival = rivalActual.getHechizos().isEmpty() ? null: rivalActual.getHechizos().get(0);

        String evento = dueloActual.ejecutarTurno(hJugador, hRival);
        vista.agregarLog(evento);

        escuela.avanzarTurno();
        sincronizarVista();
        verificarFinDuelo();
    }

    private void accionUsarPocion()
    {
        Usuario jugador = escuela.getJugador();
        for (ObjetoMagico o : jugador.getInventario())
        {
            if (o.getTipo() == TipoObjeto.CURATIVO && o.estaDisponible())
            {
                jugador.usarObjeto(o);
                vista.agregarLog(jugador.getNombre() + " usa " + o.getNombre()+ ": +" + o.getValor() + " HP. Salud: " + jugador.getSalud());
                sincronizarVista();
                return;
            }
        }
        vista.agregarLog("No tienes pociones disponibles.");
    }

    private void accionDescubrirSecreto()
    {
        escuela.getJugador().descubrirSecretos();
        vista.agregarLog("Descubriste un secreto de Hogwarts! +10 puntos.");
        escuela.avanzarTurno();
        sincronizarVista();
    }

    private void accionAsistirClase()
    {
        escuela.getJugador().asistirAClases();
        vista.agregarLog(escuela.getJugador().getNombre()+ " asiste a Magia Avanzada. Nivel magia: "+ escuela.getJugador().getLvlMagia());
        escuela.avanzarTurno();
        sincronizarVista();
    }

    private void accionIniciarDuelo()
    {
        String nombreRival = (String) vista.cmbRivales.getSelectedItem();
        if (nombreRival == null) return;

        rivalActual = escuela.buscarPersonaje(nombreRival);
        if (rivalActual == null) { vista.agregarLog("Rival no encontrado."); return; }

        dueloActual = escuela.iniciarDuelo(rivalActual);
        vista.agregarLog("¡Duelo iniciado! " + escuela.getJugador().getNombre()+ " vs " + rivalActual.getNombre());
        vista.habilitarAcciones(true);
        sincronizarVista();
    }

    private void accionNuevoJuego()
    {
        String nombre = vista.txtNombreJugador.getText().trim();
        if (nombre.isEmpty()) nombre = "Harry Potter";
        Casa casa = Casa.valueOf((String) vista.cmbCasaInicial.getSelectedItem());
        escuela.reiniciar(nombre, casa);
        dueloActual = null;
        rivalActual = null;
        cargarRivalesEnCombo();
        cargarHechizosEnCombo();
        sincronizarVista();
        vista.txtLog.setText("");
        vista.habilitarAcciones(true);
        vista.setStatus("Nuevo juego iniciado. Bienvenido de vuelta a Hogwarts!");
        vista.agregarLog("— Nuevo juego iniciado —");
        vista.agregarLog("Bienvenido de nuevo, " + escuela.getJugador().getNombre() + "!");
    }

    // ── Helpers ───────────────────────────────────────────────────

    private void verificarFinDuelo()
    {
        if (!dueloActual.isActivo())
        {
            Personaje ganador = dueloActual.getGanador();
            if (ganador != null && ganador == escuela.getJugador())
            {
                escuela.getJugador().addPuntaje(50);
                vista.agregarLog("Victoria! Has derrotado a " + rivalActual.getNombre() + ". +50 puntos.");
            }
            else
            {
                vista.agregarLog("Has sido derrotado por " + rivalActual.getNombre() + ".");
                vista.habilitarAcciones(false);
                escuela.terminarJuego();
            }
            dueloActual = null;
            rivalActual = null;
            cargarRivalesEnCombo();
            sincronizarVista();
        }
    }

    private void sincronizarVista()
    {
        if (escuela == null) return;
        Usuario  jug = escuela.getJugador();
        int turno = escuela.getTurno();
        String esc = ESCENARIOS[turno % ESCENARIOS.length];

        vista.actualizarJugador(jug.getSalud(), jug.getMagia(),jug.getLvlMagia(), jug.getCasa().name());

        vista.actualizarHUD(turno, jug.getPuntaje(), esc);
        vista.lblEscenarioVal.setText(esc);

        if (rivalActual != null)
        {
            String tipo = rivalActual instanceof Profesores ? "Profesor" :rivalActual instanceof Criaturas  ? "Criatura" : "Estudiante";
            vista.actualizarRival(rivalActual.getNombre(), tipo,rivalActual.getSalud(), Personaje.SALUD_MAX + 50);
        }
        else
        {
            vista.lblNombreRivalVal.setText("(ninguno)");
            vista.lblTipoRivalVal.setText("Selecciona un rival");
            vista.barSaludRival.setValue(0);
            vista.lblSaludRivalVal.setText("—");
        }
    }
}
