/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.time.LocalDate;

public class Cuidador extends Personal {

    private int añosExp;
    private LocalDate disponibleDesde; // fecha desde la que está disponible
    private String especialidad;       // raza que atiende

    public Cuidador(String nombre, String cedula, String edad, int añosExp, LocalDate disponibleDesde, String especialidad) {
        super(nombre, cedula, edad);
        this.añosExp = añosExp;
        this.disponibleDesde = disponibleDesde;
        this.especialidad = especialidad;
    }

    public int getAñosExp() {
        return añosExp;
    }

    public void setAñosExp(int añosExp) {
        this.añosExp = añosExp;
    }

    public LocalDate getDisponibleDesde() {
        return disponibleDesde;
    }

    public void setDisponibleDesde(LocalDate disponibleDesde) {
        this.disponibleDesde = disponibleDesde;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    // Verifica si el cuidador está disponible hoy o antes
    public boolean estaDisponible() {
        return !LocalDate.now().isBefore(disponibleDesde);
    }

    public void atenderMascota() {
        System.out.println("Cuidador " + getNombre() + " está atendiendo una mascota.");
    }

    public void verificarDisponibilidad() {
        if (estaDisponible()) {
            System.out.println(getNombre() + " está disponible desde " + disponibleDesde);
        } else {
            System.out.println(getNombre() + " estará disponible el " + disponibleDesde);
        }
    }
}
