/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Cliente extends Usuario {

    private List<Mascota> mascotas;
    private List<Reserva> reservas;

    public Cliente() {
        this.mascotas = new ArrayList<>();
        this.reservas = new ArrayList<>();
    }

    public Cliente(String nombre, String cedula, String edad) {
        super(nombre, cedula, edad);
        this.mascotas = new ArrayList<>();
        this.reservas = new ArrayList<>();
    }

    public List<Mascota> getMascotas() {
        return mascotas;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    // Verifica si el cliente tiene mascotas registradas
    public boolean validarDueño() {
        return !mascotas.isEmpty();
    }

    public void registrarMascota(Mascota mascota) {
        mascotas.add(mascota);
        System.out.println("Mascota " + mascota.getNombreMascota() + " registrada para " + getNombre());
    }

    public void hacerReserva(Reserva reserva) {
        reservas.add(reserva);
        System.out.println("Reserva registrada para " + getNombre());
    }

    public void verReserva() {
        if (reservas.isEmpty()) {
            System.out.println("No hay reservas registradas.");
        } else {
            for (Reserva r : reservas) {
                r.mostrarReserva();
            }
        }
    }

    // Para mostrar el nombre en el cmbBoxDueño del Frame 2
    @Override
    public String toString() {
        return getNombre() + " - " + getCedula();
    }
}