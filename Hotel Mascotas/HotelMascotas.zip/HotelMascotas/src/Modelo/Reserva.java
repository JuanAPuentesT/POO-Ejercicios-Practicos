/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Reserva {

    private LocalDate fechaIngreso;
    private LocalDate fechaSalida;
    private int diasEstadia;
    private List<Servicio> serviciosADD;

    public Reserva() {
        this.serviciosADD = new ArrayList<>();
    }

    public Reserva(LocalDate fechaIngreso, int diasEstadia) {
        this.fechaIngreso = fechaIngreso;
        this.diasEstadia = diasEstadia;
        this.serviciosADD = new ArrayList<>();
        calcularFechaSalida(); // se calcula automáticamente al crear
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public LocalDate getFechaSalida() {
        return fechaSalida;
    }

    public int getDiasEstadia() {
        return diasEstadia;
    }

    public void setDiasEstadia(int diasEstadia) {
        this.diasEstadia = diasEstadia;
    }

    public List<Servicio> getServiciosAdd() {
        return serviciosADD;
    }

    // LocalDate maneja correctamente los meses y años automáticamente
    public void calcularFechaSalida() {
        if (fechaIngreso != null) {
            this.fechaSalida = fechaIngreso.plusDays(diasEstadia);
        }
    }

    public void agregarServicio(Servicio servicio) {
        serviciosADD.add(servicio);
    }

    // Verifica si la reserva sigue activa (fecha de salida no ha llegado)
    public boolean estaActiva() {
        return fechaSalida != null && LocalDate.now().isBefore(fechaSalida);
    }

    public void mostrarReserva() {
        System.out.println("Ingreso: " + fechaIngreso);
        System.out.println("Dias de estadia: " + diasEstadia);
        System.out.println("Salida: " + fechaSalida);
        System.out.println("Servicios: " + serviciosADD);
    }

    // Retorna la info como String para mostrar en el área de texto del frame
    public String getInfoReserva() {
        return "Ingreso: " + fechaIngreso +
               "\nDías: " + diasEstadia +
               "\nSalida: " + fechaSalida +
               "\nServicios: " + serviciosADD;
    }
}
    

 
