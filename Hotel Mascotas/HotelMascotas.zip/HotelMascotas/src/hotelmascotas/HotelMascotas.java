/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hotelmascotas;

import Vista.JFSistemaHotel;
import Controlador.ControladorSistemaHotel;

public class HotelMascotas {
    public static void main(String[] args) {
        JFSistemaHotel frame = new JFSistemaHotel();
        frame.setVisible(true);
        new ControladorSistemaHotel(frame);
    }
}
