/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.JFReserva;
import Modelo.Cliente;
import Modelo.Cuidador;
import Modelo.Mascota;
import Modelo.Reserva;
import Modelo.Servicio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

public class ControladorReserva implements ActionListener {

    private JFReserva frmReserva;
    private ArrayList<Cliente> listaClientes;
    private ArrayList<Cuidador> listaCuidadores;
    private ArrayList<Reserva> listaReservas;

    private DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public ControladorReserva(JFReserva frmReserva, ArrayList<Cliente> listaClientes,
                               ArrayList<Cuidador> listaCuidadores, ArrayList<Reserva> listaReservas) {
        this.frmReserva = frmReserva;
        this.listaClientes = listaClientes;
        this.listaCuidadores = listaCuidadores;
        this.listaReservas = listaReservas;

        this.frmReserva.btnGuardar.addActionListener(this);
        this.frmReserva.btnVolverCliente.addActionListener(this);

        cargarComboDueño();
        cargarComboNecesidades();
        configurarEventos();
    }

    // Carga los clientes en el cmbBoxDueño "Nombre - Cedula"
    public void cargarComboDueño() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        for (Cliente c : listaClientes) {
            modelo.addElement(c.toString()); 
        }
        frmReserva.cmbBoxDueño.setModel(modelo);
    }

    // Carga los servicios disponibles
    public void cargarComboNecesidades() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        modelo.addElement("Ninguno");
        for (Servicio s : Servicio.values()) {
            modelo.addElement(s.name());
        }
        frmReserva.cmbBoxNecesidades.setModel(modelo);
    }

    // Calcula la fecha de salida automáticamente cuando se escribe la de ingreso
    //addFocusListener == sirve para detectar cuando un componente: gana el foco o pierde el foco.. El foco significa: el componente que el usuario está usando actualmente.
    public void configurarEventos() {
        frmReserva.txtFechaIngreso.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                calcularFechaSalidaEnPantalla();
            }
        });
    }

    private void calcularFechaSalidaEnPantalla() {
        try {
            String textoFecha = frmReserva.txtFechaIngreso.getText().trim(); // trim == sirve para eliminar espacios al inicio y al final de un String.
            String textoEdad  = frmReserva.txtEdadPerro.getText().trim(); 
            if (textoFecha.isEmpty()) return;

            LocalDate ingreso = LocalDate.parse(textoFecha, formato);
            //Si hay días de estadía ingresados, calcular salida
            //asumimos 3 días si no hay un campo específico
            int dias = 3;
            LocalDate salida = ingreso.plusDays(dias);
            frmReserva.txtFechaSalida.setText(salida.format(formato));

        } catch (DateTimeParseException ex) {
            frmReserva.AreaAnimal.setText("Formato de fecha incorrecto. Use DD/MM/YYYY.");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmReserva.btnGuardar)       guardarMascotaYReserva();
        if (e.getSource() == frmReserva.btnVolverCliente) volverAtras();
    }

    private void guardarMascotaYReserva() {
        try {
            //Verificamos que el dueño esté seleccionado y exista
            Cliente clienteSeleccionado = obtenerClienteSeleccionado();
            if (clienteSeleccionado == null) {
                frmReserva.AreaAnimal.setText("No se encontró el cliente seleccionado.");
                return;
            }

            //Validamos los campos de la mascota
            String nombreMascota = frmReserva.txtNameMascota.getText().trim();
            String raza          = frmReserva.txtRaza.getText().trim();
            String edad          = frmReserva.txtEdadPerro.getText().trim();
            String necesidades   = (String) frmReserva.cmbBoxNecesidades.getSelectedItem();

            if (nombreMascota.isEmpty() || raza.isEmpty() || edad.isEmpty()) {
                frmReserva.AreaAnimal.setText("Complete todos los datos de la mascota.");
                return;
            }

            //Validamos la fecha de ingreso
            String textoFecha = frmReserva.txtFechaIngreso.getText().trim();
            if (textoFecha.isEmpty()) {
                frmReserva.AreaAnimal.setText("Ingrese la fecha de ingreso.");
                return;
            }
            LocalDate fechaIngreso = LocalDate.parse(textoFecha, formato);

            //buscamos un cuidador disponible según la raza
            Cuidador cuidadorAsignado = buscarCuidador(raza);
            if (cuidadorAsignado == null) {
                frmReserva.AreaAnimal.setText("No hay cuidador disponible para la raza: " + raza + "\n" +"No se puede realizar la reserva por falta de personal.");
                return;
            }

            //creamos la mascota y registrarla al cliente
            Mascota mascota = new Mascota(nombreMascota, raza, edad, necesidades);
            clienteSeleccionado.registrarMascota(mascota);

            //creamos la reserva (de 3 días por defecto)
            Reserva reserva = new Reserva(fechaIngreso, 3);
            if (!necesidades.equals("Ninguno")) {
                reserva.agregarServicio(Servicio.valueOf(necesidades));
            }
            clienteSeleccionado.hacerReserva(reserva);
            listaReservas.add(reserva);

            //Marcamos el cuidador como ocupado hasta que termine la reserva
            cuidadorAsignado.setDisponibleDesde(reserva.getFechaSalida());

            //Mostramos confirmación
            frmReserva.AreaAnimal.setText("✓ Reserva registrada con éxito\n\n" +"Cliente: " + clienteSeleccionado.getNombre()  + "\n" +"Mascota: " + nombreMascota + " (" + raza + ")\n" +"Cuidador: " + cuidadorAsignado.getNombre()     + "\n" +"Ingreso: "+ fechaIngreso.format(formato)     + "\n" +"Salida: "+ reserva.getFechaSalida().format(formato)
            );

            limpiarCampos();

        } catch (DateTimeParseException ex) {
            frmReserva.AreaAnimal.setText("Formato de fecha incorrecto. Use DD/MM/YYYY.");
        } catch (Exception ex) {
            frmReserva.AreaAnimal.setText("Error al guardar: " + ex.getMessage());
        }
    }

    // Buscamos el cliente seleccionado en el cmbBoxDueño dentro de listaClientes
    private Cliente obtenerClienteSeleccionado() {
        String seleccion = (String) frmReserva.cmbBoxDueño.getSelectedItem();
        if (seleccion == null) return null;

        // El formato es "Nombre - Cedula", extraemos la cédula
        String cedula = seleccion.split(" - ")[1].trim();
        for (Cliente c : listaClientes) {
            if (c.getCedula().equals(cedula)) {
                return c;
            }
        }
        return null;
    }

    // Buscamos un cuidador disponible hoy que tenga la especialidad de esa raza
    private Cuidador buscarCuidador(String raza) {
        for (Cuidador c : listaCuidadores) {
            if (c.getEspecialidad().equalsIgnoreCase(raza) && c.estaDisponible()) {
                return c;
            }
        }
        return null; // no hay cuidador para esa raza o no está disponible
    }

    private void volverAtras() {
        frmReserva.dispose();
    }

    private void limpiarCampos() {
        frmReserva.txtNameMascota.setText("");
        frmReserva.txtRaza.setText("");
        frmReserva.txtEdadPerro.setText("");
        frmReserva.txtFechaIngreso.setText("");
        frmReserva.txtFechaSalida.setText("");
        frmReserva.cmbBoxNecesidades.setSelectedIndex(0);
    }
}
