/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.JFSistemaHotel;
import Vista.JFReserva;
import Modelo.Cliente;
import Modelo.Cuidador;
import Modelo.Mascota;
import Modelo.Reserva;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;

public class ControladorSistemaHotel implements ActionListener {

    private JFSistemaHotel frmSistemaHotel;
    private ArrayList<Cliente> listaClientes;
    private ArrayList<Cuidador> listaCuidadores;
    private ArrayList<Reserva> listaReservas;

    public ControladorSistemaHotel(JFSistemaHotel frmSistemaHotel) {
        this.frmSistemaHotel = frmSistemaHotel;
        this.listaClientes = new ArrayList<>();
        this.listaCuidadores = new ArrayList<>();
        this.listaReservas = new ArrayList<>();

        this.frmSistemaHotel.btnGuardarCliente.addActionListener(this);
        this.frmSistemaHotel.btnFinalizarProgram.addActionListener(this);
        this.frmSistemaHotel.btnRegistrarMascota.addActionListener(this);
        this.frmSistemaHotel.btnReservasActivas.addActionListener(this);
        this.frmSistemaHotel.btnPersonalDisponible.addActionListener(this);
        this.frmSistemaHotel.btnMostrarReservas.addActionListener(this);

        cargarCuidadores();
        cargarClientesConMascotas();
    }

    // ─── Cuidadores precargados ───
    public void cargarCuidadores() {
        // disponibleDesde = hoy -> ya están disponibles
        // disponibleDesde = fecha futura -> aún no estan disponibles
        LocalDate hoy = LocalDate.now();

        listaCuidadores.add(new Cuidador("Carlos Ruiz",    "1001", "30", 5, hoy,                        "Labrador"));
        listaCuidadores.add(new Cuidador("Maria Lopez",    "1002", "28", 3, hoy,                        "Bulldog"));
        listaCuidadores.add(new Cuidador("Pedro Gomez",    "1003", "35", 7, hoy.plusDays(5),             "Poodle"));// disponible en 5 días
        listaCuidadores.add(new Cuidador("Ana Torres",     "1004", "26", 2, hoy,                        "Chihuahua"));
        listaCuidadores.add(new Cuidador("Luis Perez",     "1005", "32", 4, hoy,                        "Golden Retriever"));
        listaCuidadores.add(new Cuidador("Sofia Diaz",     "1006", "29", 6, hoy.plusDays(2),             "Beagle"));// disponible en 2 días
        listaCuidadores.add(new Cuidador("Jorge Mora",     "1007", "40", 10,hoy,                        "Pastor Alemán"));
        listaCuidadores.add(new Cuidador("Laura Vega",     "1008", "24", 1, hoy,                        "Shih Tzu"));
        listaCuidadores.add(new Cuidador("Miguel Castro",  "1009", "33", 5, hoy,                        "Dálmata"));
        listaCuidadores.add(new Cuidador("Daniela Rios",   "1010", "27", 3, hoy.plusDays(10),            "Boxer"));// disponible en 10 días
        listaCuidadores.add(new Cuidador("Andres Silva",   "1011", "31", 4, hoy,                        "Schnauzer"));
        listaCuidadores.add(new Cuidador("Camila Ortiz",   "1012", "25", 2, hoy,                        "Yorkshire"));
    }

    // ─── Clientes precargados con sus mascotas ───
    public void cargarClientesConMascotas() {
        // Cliente 1 con 2 mascotas
        Cliente c1 = new Cliente("Juan Garcia",   "111", "35");
        c1.registrarMascota(new Mascota("Rex",    "Labrador",        "3", "Ninguna"));
        c1.registrarMascota(new Mascota("Luna",   "Beagle",          "2", "Alérgico al pollo"));

        // Cliente 2 con 1 mascota
        Cliente c2 = new Cliente("Sara Medina",   "222", "28");
        c2.registrarMascota(new Mascota("Rocky",  "Bulldog",         "5", "Problemas de cadera"));

        // Cliente 3 con 2 mascotas
        Cliente c3 = new Cliente("Carlos Peña",   "333", "42");
        c3.registrarMascota(new Mascota("Lola",   "Chihuahua",       "1", "Ninguna"));
        c3.registrarMascota(new Mascota("Max",    "Pastor Alemán",   "4", "Dieta especial"));

        // Cliente 4 con 1 mascota
        Cliente c4 = new Cliente("Diana Rojas",   "444", "31");
        c4.registrarMascota(new Mascota("Toby",   "Golden Retriever","6", "Ninguna"));

        // Cliente 5 con 1 mascota
        Cliente c5 = new Cliente("Mario Vega",    "555", "25");
        c5.registrarMascota(new Mascota("Coco",   "Poodle",          "2", "Ansioso con extraños"));

        listaClientes.add(c1);
        listaClientes.add(c2);
        listaClientes.add(c3);
        listaClientes.add(c4);
        listaClientes.add(c5);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmSistemaHotel.btnGuardarCliente)guardarCliente();
        if (e.getSource() == frmSistemaHotel.btnMostrarReservas)mostrarReservas();
        if (e.getSource() == frmSistemaHotel.btnReservasActivas)mostrarReservasActivas();
        if (e.getSource() == frmSistemaHotel.btnPersonalDisponible)mostrarPersonalDisponible();
        if (e.getSource() == frmSistemaHotel.btnRegistrarMascota)abrirFrameReserva();
        if (e.getSource() == frmSistemaHotel.btnFinalizarProgram)finalizarPrograma();
    }

    private void guardarCliente() {
        try {
            String nombre = frmSistemaHotel.txtNombreCliente.getText().trim();
            String cedula = frmSistemaHotel.txtCedulaCliente.getText().trim();
            String edad   = frmSistemaHotel.txtEdadCliente.getText().trim();

            if (nombre.isEmpty() || cedula.isEmpty() || edad.isEmpty()) {
                frmSistemaHotel.AreaResultsCliente.setText("Complete todos los campos obligatorios.");
                return;
            }

            for (Cliente c : listaClientes) {
                if (c.getCedula().equals(cedula)) {
                    frmSistemaHotel.AreaResultsCliente.setText("Ya existe un cliente con esa cédula.");
                    return;
                }
            }

            Cliente nuevo = new Cliente(nombre, cedula, edad);
            listaClientes.add(nuevo);
            frmSistemaHotel.AreaResultsCliente.setText("Cliente registrado:\n" +"Nombre: " + nombre + "\n" +"Cédula: " + cedula + "\n" +"Registrado el: " + LocalDate.now());
            limpiarCampos();

        } catch (Exception e) {
            frmSistemaHotel.AreaResultsCliente.setText("Error al guardar el cliente.");
        }
    }

    private void mostrarReservas() {
        if (listaReservas.isEmpty()) {
            frmSistemaHotel.AreaResultsCliente.setText("No hay reservas registradas.");
            return;
        }
        frmSistemaHotel.AreaResultsCliente.setText("=== Todas las Reservas ===\n");
        for (Reserva r : listaReservas) {
            frmSistemaHotel.AreaResultsCliente.append(r.getInfoReserva() + "\n---\n");
        }
    }

    private void mostrarReservasActivas() {
        frmSistemaHotel.AreaResultsCliente.setText("=== Reservas Activas ===\n");
        boolean hayActivas = false;
        for (Reserva r : listaReservas) {
            if (r.estaActiva()) { 
                frmSistemaHotel.AreaResultsCliente.append(r.getInfoReserva() + "\n---\n");
                hayActivas = true;
            }
        }
        if (!hayActivas) {
            frmSistemaHotel.AreaResultsCliente.setText("No hay reservas activas en este momento.");
        }
    }

    private void mostrarPersonalDisponible() {
        frmSistemaHotel.AreaResultsCliente.setText("=== Personal Disponible Hoy ===\n");
        boolean hayDisponible = false;
        for (Cuidador c : listaCuidadores) {
            if (c.estaDisponible()) {  // Esto compara con LocalDate.now()
                frmSistemaHotel.AreaResultsCliente.append("Nombre: " + c.getNombre()+ "\n" +"Especialidad: " + c.getEspecialidad()+ "\n" +"Experiencia: "  + c.getAñosExp()+ " años\n" +"Disponible desde: " + c.getDisponibleDesde() + "\n---\n");
                hayDisponible = true;
            }
        }
        if (!hayDisponible) {
            frmSistemaHotel.AreaResultsCliente.setText("No hay personal disponible hoy.");
        }
    }

    private void abrirFrameReserva() {
        if (listaClientes.isEmpty()) {
            frmSistemaHotel.AreaResultsCliente.setText("Registre al menos un cliente antes de continuar.");
            return;
        }
        JFReserva frmReserva = new JFReserva();
        frmReserva.setVisible(true);
        new ControladorReserva(frmReserva, listaClientes, listaCuidadores, listaReservas);
    }

    private void finalizarPrograma() {
        System.exit(0);
    }

    private void limpiarCampos() {
        frmSistemaHotel.txtNombreCliente.setText("");
        frmSistemaHotel.txtCedulaCliente.setText("");
        frmSistemaHotel.txtEdadCliente.setText("");
        frmSistemaHotel.txtTlfCliente.setText("");
    }

    public ArrayList<Cliente> getListaClientes() {
        return listaClientes;
    }

    public void agregarReserva(Reserva reserva) {
        listaReservas.add(reserva);
    }
}
