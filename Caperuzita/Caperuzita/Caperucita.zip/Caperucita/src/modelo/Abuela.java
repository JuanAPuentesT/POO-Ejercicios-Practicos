package modelo;

public class Abuela extends Personaje {
    private int age;
    private boolean salud;
    private boolean rescatada;

    public Abuela(String id, String nombre, String tipo,int age, boolean salud, boolean rescatada) {
        super(id, nombre, tipo);
        this.age = age;
        this.salud = salud;
        this.rescatada = rescatada;
    }

    public void gritar() {
        // señal de auxilio — el controlador muestra el mensaje
    }

    public String getGrito() {
        return getNombre() + " grita: ¡Auxilio, el lobo está aquí!";
    }

    public int getAge(){ return age; }
    public boolean isSalud(){ return salud; }
    public boolean isRescatada(){ return rescatada; }
    public void setSalud(boolean salud){ this.salud     = salud; }
    public void setRescatada(boolean rescatada){ this.rescatada = rescatada; }
}
