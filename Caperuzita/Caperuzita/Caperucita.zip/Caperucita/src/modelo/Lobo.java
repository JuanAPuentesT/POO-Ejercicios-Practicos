package modelo;

public class Lobo extends Personaje {
    private boolean vivo;

    public Lobo(String id, String nombre, String tipo, boolean vivo) {
        super(id, nombre, tipo);
        this.vivo = vivo;
    }

    public String talk(){ return getNombre() + " dice: ¡Qué orejas más grandes tienes, abuelita!"; }
    public String disfrazar() { return getNombre() + " se está disfrazando de abuela..."; }
    public String run(){ return getNombre() + " corre veloz por el bosque."; }
    public String swallow() { return getNombre() + " se tragó a la abuelita de un bocado."; }

    public boolean isVivo()              { return vivo; }
    public void    setVivo(boolean vivo) { this.vivo = vivo; }
}
