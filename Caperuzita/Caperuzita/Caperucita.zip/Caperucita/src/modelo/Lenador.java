package modelo;

public class Lenador extends Personaje {

    public Lenador(String id, String nombre, String tipo) {
        super(id, nombre, tipo);
    }

    public String rescatar() {
        return getNombre() + " llega corriendo con su hacha y salva a todos.";
    }

    public boolean abrirPanza(Lobo lobo) {
        return lobo != null && lobo.isVivo();
    }

    public boolean rellenarPanza(Lobo lobo) {
        if (lobo != null) {
            lobo.setVivo(false);
            return true;
        }
        return false;
    }
}
