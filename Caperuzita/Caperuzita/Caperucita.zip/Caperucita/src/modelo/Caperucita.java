package modelo;

public class Caperucita extends Personaje {
    private boolean rescatada;
    private Cesta   cesta;

    public Caperucita(String id, String nombre, String tipo, boolean rescatada) {
        super(id, nombre, tipo);
        this.rescatada = rescatada;
        this.cesta = new Cesta(false, false);
    }

    public boolean visitarGranMother() {
        return cesta.full();
    }

    public boolean isRescatada(){ return rescatada; }
    public void setRescatada(boolean r){ this.rescatada = r; }
    public Cesta getCesta(){ return cesta; }
    public void setCesta(Cesta c) { this.cesta = c; }
}
