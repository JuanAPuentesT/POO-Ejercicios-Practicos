package Main;

import controlador.CaperucitaControlador;
import javax.swing.SwingUtilities;

public class Juego {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(CaperucitaControlador::new);
    }
}
