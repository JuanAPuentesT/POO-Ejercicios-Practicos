package controlador;

import modelo.*;
import vista.VistaCaperucita;

public class CaperucitaControlador {

    // ── Modelo ────
    private Caperucita caperucita;
    private Abuela     abuela;
    private Lobo       lobo;
    private Lenador    lenador;
    private Bosque     bosque;

    // ── Vista ────
    private VistaCaperucita vista;

    // ── Estado del cuento ────
    private boolean enBosque    = false;
    private boolean abuelaViva  = true;   // panza del lobo = no viva
    private boolean rescateHecho = false;

    public CaperucitaControlador() {
        inicializarModelo();
        vista = new VistaCaperucita();
        conectarBotones();
        sincronizarVista();
        vista.agregarLog("Érase una vez… comienza el cuento de Caperucita Roja.");
        vista.setVisible(true);
    }

    // ── Inicialización ──
    private void inicializarModelo() {
        Arbol pino = new Arbol("arbol-1", "Pino");
        bosque = new Bosque(500, 300, pino);
        caperucita = new Caperucita("cap-1", "Caperucita", "protagonista", false);
        abuela = new Abuela("abu-1", "Abuela Rosa", "familiar", 72, true, false);
        lobo = new Lobo("lobo-1", "Lobo Feroz", "villano", true);
        lenador = new Lenador("len-1", "Leñador Pedro", "auxiliar");
    }

    // ── Botones ───
    private void conectarBotones() {
        vista.btnCargarCesta.addActionListener(e -> accionCargarCesta());
        vista.btnIrAlBosque.addActionListener(e -> accionIrAlBosque());
        vista.btnLoboHabla.addActionListener(e -> accionLoboHabla());
        vista.btnLoboDisfraz.addActionListener(e -> accionLoboDisfraz());
        vista.btnLoboTraga.addActionListener(e -> accionLoboTraga());
        vista.btnAbuelaGrita.addActionListener(e -> accionAbuelaGrita());
        vista.btnLenadorRescata.addActionListener(e -> accionLenadorRescata());
        vista.btnNueva.addActionListener(e -> accionNueva());
    }

    // ── Acciones ───
    private void accionCargarCesta() {
        if (enBosque) { vista.agregarLog("Ya estás en camino, no puedes cargar la cesta."); return; }
        Cesta c = caperucita.getCesta();
        c.setBebida(true);
        c.setComida(true);
        vista.agregarLog("Caperucita llena la cesta con comida y bebida para la abuela.");
        sincronizarVista();
    }

    private void accionIrAlBosque() {
        if (!caperucita.getCesta().full()) {
            vista.agregarLog("La cesta está vacía. ¡Llénala antes de partir!");
            return;
        }
        enBosque = true;
        vista.agregarLog("Caperucita entra al bosque (alto=" + bosque.getAlto()
                + ", ancho=" + bosque.getAncho() + ").");
        vista.agregarLog("Entre los árboles hay un " + bosque.getArbol().getTipo() + ".");
        if (caperucita.visitarGranMother()) {
            vista.agregarLog("La cesta está lista: ¡Caperucita puede visitar a la abuela!");
        }
        sincronizarVista();
    }

    private void accionLoboHabla() {
        if (!enBosque) { vista.agregarLog("El lobo aparece solo en el bosque."); return; }
        vista.agregarLog(lobo.talk());
    }

    private void accionLoboDisfraz() {
        if (!enBosque) { vista.agregarLog("El lobo aún no está en el bosque."); return; }
        vista.agregarLog(lobo.disfrazar());
        vista.agregarLog(lobo.run() + " Llega antes que Caperucita a casa de la abuela.");
        abuelaViva = false;
        abuela.setSalud(false);
        sincronizarVista();
    }

    private void accionLoboTraga() {
        if (!enBosque || abuelaViva) {
            vista.agregarLog("El lobo debe disfrazarse primero."); return;
        }
        vista.agregarLog(lobo.swallow());
        vista.agregarLog("La abuela quedó atrapada en la panza del lobo.");
        sincronizarVista();
    }

    private void accionAbuelaGrita() {
        if (abuela.isSalud()) { vista.agregarLog("La abuela está bien, no necesita gritar."); return; }
        abuela.gritar();
        vista.agregarLog(abuela.getGrito());
        vista.agregarLog("El leñador escucha el grito desde el bosque…");
    }

    private void accionLenadorRescata() {
        if (rescateHecho) { vista.agregarLog("El rescate ya fue hecho."); return; }
        if (abuela.isSalud())   { vista.agregarLog("No hay nadie que rescatar aún."); return; }

        vista.agregarLog(lenador.rescatar());

        boolean abierta = lenador.abrirPanza(lobo);
        if (abierta) {
            vista.agregarLog("El leñador abre la panza del lobo. ¡La abuela sale sana y salva!");
            abuela.setSalud(true);
            abuela.setRescatada(true);
            caperucita.setRescatada(true);
        }

        boolean rellena = lenador.rellenarPanza(lobo);
        if (rellena) {
            vista.agregarLog("El leñador rellena la panza con piedras. El lobo ya no está vivo.");
        }

        rescateHecho = true;
        sincronizarVista();
        vista.agregarLog("🎉 ¡Fin del cuento! Todos vivieron felices para siempre.");
    }

    private void accionNueva() {
        inicializarModelo();
        enBosque     = false;
        abuelaViva   = true;
        rescateHecho = false;
        vista.limpiarLog();
        sincronizarVista();
        vista.agregarLog("Érase una vez… comienza el cuento de Caperucita Roja.");
    }

    // ── Sincronizar vista ───
    private void sincronizarVista() {
        Cesta c = caperucita.getCesta();

        vista.lblCaperucitaEstado.setText("<html>"+ "Nombre: " + caperucita.getNombre() + "<br>"+ "En bosque: " + (enBosque ? "Sí" : "No") + "<br>"+ "Rescatada: " + (caperucita.isRescatada() ? "Sí" : "No")+ "</html>");

        vista.lblAbuelaEstado.setText("<html>"+ "Nombre: " + abuela.getNombre() + "<br>"+ "Edad: " + abuela.getAge() + "<br>"+ "Salud: " + (abuela.isSalud() ? "Bien ✔" : "En peligro ✘") + "<br>"+ "Rescatada: " + (abuela.isRescatada() ? "Sí ✔" : "No")+ "</html>");

        vista.lblLoboEstado.setText("<html>"+ "Nombre: " + lobo.getNombre() + "<br>"+ "Vivo: " + (lobo.isVivo() ? "Sí 🐺" : "No (detenido)")+ "</html>");

        vista.lblCestaEstado.setText("<html>"+ "Comida: " + (c.isComida() ? "✔" : "✘") + "<br>"+ "Bebida: " + (c.isBebida() ? "✔" : "✘") + "<br>"+ "Llena: "  + (c.full()     ? "Sí ✔" : "No")+ "</html>");
    }
}
