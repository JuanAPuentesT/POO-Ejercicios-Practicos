package vista;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class VistaCaperucita extends JFrame {

    // ── Paneles de estado ───
    public JLabel lblCaperucitaEstado;
    public JLabel lblAbuelaEstado;
    public JLabel lblLoboEstado;
    public JLabel lblCestaEstado;

    // ── Botones de acción ───
    public JButton btnCargarCesta;
    public JButton btnIrAlBosque;
    public JButton btnLoboHabla;
    public JButton btnLoboDisfraz;
    public JButton btnLoboTraga;
    public JButton btnAbuelaGrita;
    public JButton btnLenadorRescata;
    public JButton btnNueva;

    // ── Log ───
    public JTextArea txtLog;

    // ── Colores temáticos ───
    private static final Color ROJO      = new Color(180, 30,  30);
    private static final Color VERDE     = new Color(34,  90,  34);
    private static final Color CREMA     = new Color(255, 248, 220);
    private static final Color MARRON    = new Color(101, 67,  33);
    private static final Color GRIS_LOG  = new Color(245, 245, 235);

    public VistaCaperucita() {
        super("Caperucita Roja — El Cuento");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(820, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(CREMA);
        setLayout(new BorderLayout(10, 10));

        add(crearPanelTitulo(),   BorderLayout.NORTH);
        add(crearPanelCentro(),   BorderLayout.CENTER);
        add(crearPanelAcciones(), BorderLayout.EAST);
        add(crearPanelLog(),      BorderLayout.SOUTH);
    }

    // ── Título ───
    private JPanel crearPanelTitulo() {
        JPanel p = new JPanel();
        p.setBackground(ROJO);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));
        JLabel lbl = new JLabel("🍎  Caperucita Roja  🐺", SwingConstants.CENTER);
        lbl.setFont(new Font("Serif", Font.BOLD, 24));
        lbl.setForeground(Color.WHITE);
        p.add(lbl);
        return p;
    }

    // ── Panel central: estado de personajes ───
    private JPanel crearPanelCentro() {
        JPanel p = new JPanel(new GridLayout(2, 2, 10, 10));
        p.setBackground(CREMA);
        p.setBorder(new EmptyBorder(10, 15, 5, 5));

        lblCaperucitaEstado = crearTarjeta(p, "🧒 Caperucita",ROJO);
        lblAbuelaEstado = crearTarjeta(p, "👵 Abuela",MARRON);
        lblLoboEstado = crearTarjeta(p, "🐺 Lobo",new Color(60, 60, 60));
        lblCestaEstado = crearTarjeta(p, "🧺 Cesta",VERDE);

        return p;
    }

    private JLabel crearTarjeta(JPanel parent, String titulo, Color color) {
        JPanel tarjeta = new JPanel(new BorderLayout(4, 4));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(color, 2, true),
                new EmptyBorder(8, 10, 8, 10)));

        JLabel cabecera = new JLabel(titulo);
        cabecera.setFont(new Font("Serif", Font.BOLD, 14));
        cabecera.setForeground(color);

        JLabel estado = new JLabel("—");
        estado.setFont(new Font("SansSerif", Font.PLAIN, 12));
        estado.setForeground(Color.DARK_GRAY);

        tarjeta.add(cabecera, BorderLayout.NORTH);
        tarjeta.add(estado,   BorderLayout.CENTER);
        parent.add(tarjeta);
        return estado;
    }

    // ── Panel de acciones ───
    private JPanel crearPanelAcciones() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(CREMA);
        p.setBorder(new EmptyBorder(10, 5, 10, 15));

        agregarSeparador(p, "Caperucita");
        btnCargarCesta = boton("Cargar cesta",ROJO);
        btnIrAlBosque = boton("Ir al bosque",VERDE);
        p.add(btnCargarCesta);  p.add(Box.createVerticalStrut(4));
        p.add(btnIrAlBosque);   p.add(Box.createVerticalStrut(10));

        agregarSeparador(p, "Lobo");
        btnLoboHabla = boton("Lobo: hablar", new Color(60,60,60));
        btnLoboDisfraz = boton("Lobo: disfrazarse", new Color(60,60,60));
        btnLoboTraga = boton("Lobo: tragar abuela", new Color(130,0,0));
        p.add(btnLoboHabla);   p.add(Box.createVerticalStrut(4));
        p.add(btnLoboDisfraz); p.add(Box.createVerticalStrut(4));
        p.add(btnLoboTraga);   p.add(Box.createVerticalStrut(10));

        agregarSeparador(p, "Rescate");
        btnAbuelaGrita = boton("Abuela grita",MARRON);
        btnLenadorRescata = boton("Leñador rescata",VERDE);
        p.add(btnAbuelaGrita);p.add(Box.createVerticalStrut(4));
        p.add(btnLenadorRescata); p.add(Box.createVerticalStrut(10));

        p.add(Box.createVerticalGlue());
        btnNueva = boton("Nueva historia", new Color(100, 100, 180));
        p.add(btnNueva);

        return p;
    }

    private JButton boton(String texto, Color color) {
        JButton b = new JButton(texto);
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setMaximumSize(new Dimension(160, 30));
        b.setPreferredSize(new Dimension(160, 30));
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setBorder(BorderFactory.createCompoundBorder(new LineBorder(color.darker(), 1, true),new EmptyBorder(3, 8, 3, 8)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void agregarSeparador(JPanel p, String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        lbl.setFont(new Font("Serif", Font.ITALIC, 11));
        lbl.setForeground(Color.GRAY);
        p.add(lbl);
        p.add(Box.createVerticalStrut(3));
    }

    // ── Log ──
    private JPanel crearPanelLog() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(CREMA);
        p.setBorder(new EmptyBorder(0, 15, 10, 15));

        txtLog = new JTextArea(5, 50);
        txtLog.setEditable(false);
        txtLog.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtLog.setBackground(GRIS_LOG);
        txtLog.setForeground(new Color(40, 40, 40));
        txtLog.setLineWrap(true);
        txtLog.setWrapStyleWord(true);
        txtLog.setBorder(new EmptyBorder(5, 8, 5, 8));

        JScrollPane scroll = new JScrollPane(txtLog);
        scroll.setBorder(new LineBorder(MARRON, 1, true));
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── Helpers públicos ───
    public void agregarLog(String msg) {
        txtLog.append("▸ " + msg + "\n");
        txtLog.setCaretPosition(txtLog.getDocument().getLength());
    }

    public void limpiarLog() {
        txtLog.setText("");
    }
}
