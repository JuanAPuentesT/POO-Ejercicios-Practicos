/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

import vista.JFFigurasGeometricas;

public class FigurasGeometricas {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new JFFigurasGeometricas().setVisible(true);
        });
    }
}
