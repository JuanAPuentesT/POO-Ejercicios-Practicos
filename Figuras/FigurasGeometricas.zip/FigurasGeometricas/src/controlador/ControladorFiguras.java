/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Circulo;
import modelo.Cuadrado;
import modelo.Figura;
import modelo.Triangulo;

public class ControladorFiguras {

    private Figura figuraActual;

    public ControladorFiguras() {}

    public Figura crearCirculo(double radio, String codigo, String color) {
        figuraActual = new Circulo(radio, codigo, color, 0, 0);
        return figuraActual;
    }

    public Figura crearCuadrado(double lado, String codigo, String color) {
        figuraActual = new Cuadrado(lado, codigo, color, 0, 0);
        return figuraActual;
    }

    public Figura crearTriangulo(double ladoA, double ladoB, double ladoC,
                                  double base, double altura,
                                  String codigo, String color) {
        figuraActual = new Triangulo(ladoA, ladoB, ladoC, base, altura, codigo, color, 0, 0);
        return figuraActual;
    }

    public Figura getFiguraActual() {
        return figuraActual;
    }

    public String getArea() {
        if (figuraActual == null) return "0.00";
        return String.format("%.2f", figuraActual.calcularArea());
    }

    public String getPerimetro() {
        if (figuraActual == null) return "0.00";
        return String.format("%.2f", figuraActual.calcularPerimetro());
    }

    public boolean esNumeroValido(String texto) {
        try {
            return Double.parseDouble(texto.trim()) > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
