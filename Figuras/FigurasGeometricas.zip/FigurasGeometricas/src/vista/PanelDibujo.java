/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import modelo.Circulo;
import modelo.Cuadrado;
import modelo.Figura;
import modelo.Triangulo;

import javax.swing.JPanel;
import java.awt.*;

public class PanelDibujo extends JPanel {

    private Figura figura;

    public PanelDibujo() {
    setBackground(Color.WHITE);
    setBorder(javax.swing.BorderFactory.createTitledBorder("Vista Previa"));
    setPreferredSize(new java.awt.Dimension(300, 400));
    setMinimumSize(new java.awt.Dimension(300, 400));
}

    // Llama esto desde el controlador/vista para dibujar una figura
    public void dibujar(Figura f) {
        this.figura = f;
        repaint(); // le dice a Java que vuelva a pintar el panel
    }

    public void limpiar() {
        this.figura = null;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // limpia el fondo primero — SIEMPRE va aquí
        if (figura == null) return;

        Graphics2D g2 = (Graphics2D) g;
        // Activa el suavizado de bordes
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Centro del panel
        int cx = getWidth() / 2;
        int cy = getHeight() / 2;
        int maxSize = Math.min(getWidth(), getHeight()) - 60;

        // Intentar usar el color ingresado (ej: "red", "#FF0000")
        try {
            g2.setColor(Color.decode(figura.getColor()));
        } catch (Exception e) {
            g2.setColor(new Color(70, 130, 180)); // azul por defecto
        }

        if (figura instanceof Circulo) {
            double radio = ((Circulo) figura).getRadio();
            int r = (int) Math.min(radio * 10, maxSize / 2.0);

            // Relleno
            g2.fillOval(cx - r, cy - r, r * 2, r * 2);
            // Borde
            g2.setColor(Color.DARK_GRAY);
            g2.setStroke(new BasicStroke(2));
            g2.drawOval(cx - r, cy - r, r * 2, r * 2);
            // Etiqueta radio
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawLine(cx, cy, cx + r, cy);
            g2.drawString("r = " + radio, cx + r / 2 - 10, cy - 5);

        } else if (figura instanceof Cuadrado) {
            double lado = ((Cuadrado) figura).getLado();
            int s = (int) Math.min(lado * 10, (double) maxSize);

            g2.fillRect(cx - s / 2, cy - s / 2, s, s);
            g2.setColor(Color.DARK_GRAY);
            g2.setStroke(new BasicStroke(2));
            g2.drawRect(cx - s / 2, cy - s / 2, s, s);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("lado = " + lado, cx - s / 2, cy - s / 2 - 6);

        } else if (figura instanceof Triangulo) {
            Triangulo t = (Triangulo) figura;
            int b = (int) Math.min(t.getBase()   * 10, (double) maxSize);
            int h = (int) Math.min(t.getAltura() * 10, (double) maxSize);

            int[] xs = { cx - b / 2, cx + b / 2, cx };
            int[] ys = { cy + h / 2, cy + h / 2, cy - h / 2 };

            g2.fillPolygon(xs, ys, 3);
            g2.setColor(Color.DARK_GRAY);
            g2.setStroke(new BasicStroke(2));
            g2.drawPolygon(xs, ys, 3);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("base = " + t.getBase(),   cx - b / 2, cy + h / 2 + 18);
            g2.drawString("h = "   + t.getAltura(),  cx + 6,     cy);
        }
    }
}
