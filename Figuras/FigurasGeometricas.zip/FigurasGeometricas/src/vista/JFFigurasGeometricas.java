package vista;


public class JFFigurasGeometricas extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger =
        java.util.logging.Logger.getLogger(JFFigurasGeometricas.class.getName());


    public JFFigurasGeometricas() {
    initComponents();

    cmbBoxFiguras.addItem("Círculo");
    cmbBoxFiguras.addItem("Cuadrado");
    cmbBoxFiguras.addItem("Triángulo");

    btnCalcular.addActionListener(e -> calcularYDibujar());

    cmbBoxFiguras.addActionListener(e -> {
        Jpanel2.limpiar();
        AreaResults.setText("");
        actualizarCampos();
    });
    actualizarCampos();
}

    
    private void calcularYDibujar() {
    String fig    = (String) cmbBoxFiguras.getSelectedItem();
    String codigo = txtCodigo.getText().trim();
    String color  = txtColor.getText().trim();

    if (codigo.isEmpty() || color.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this,
            "Ingresa código y color.", "Faltan datos",
            javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    controlador.ControladorFiguras ctrl = new controlador.ControladorFiguras();
    modelo.Figura figura = null;

    try {
        switch (fig) {
            case "Círculo": {
                double radio = Double.parseDouble(txtRadio.getText().trim());
                figura = ctrl.crearCirculo(radio, codigo, color);
                break;
            }
            case "Cuadrado": {
                double lado = Double.parseDouble(txtBase.getText().trim());
                figura = ctrl.crearCuadrado(lado, codigo, color);
                break;
            }
            case "Triángulo": {
                double base   = Double.parseDouble(txtBase.getText().trim());
                double altura = Double.parseDouble(txtAltura.getText().trim());
                double hip    = Math.sqrt(base * base + altura * altura);
                figura = ctrl.crearTriangulo(base, altura, hip, base, altura, codigo, color);
                break;
            }
        }
    } catch (NumberFormatException ex) {
        javax.swing.JOptionPane.showMessageDialog(this,
            "Verifica que los valores numéricos sean válidos.", "Error",
            javax.swing.JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (figura != null) {
        AreaResults.setText(
            "Figura:    " + fig + "\n" +
            "Código:    " + figura.getCodigo() + "\n" +
            "Color:     " + figura.getColor() + "\n" +
            "Área:      " + String.format("%.2f", figura.calcularArea()) + "\n" +
            "Perímetro: " + String.format("%.2f", figura.calcularPerimetro())
        );
        Jpanel2.dibujar(figura);
    }
}
    private void actualizarCampos() {
    String fig = (String) cmbBoxFiguras.getSelectedItem();
    if (fig == null) return;

    switch (fig) {
        case "Círculo":
            // Activos: Radio
            lblRadio.setEnabled(true);  txtRadio.setEnabled(true);
            txtRadio.setText("");
            // Desactivados: Base y Altura
            lblBase.setEnabled(false);  txtBase.setEnabled(false);
            txtBase.setText("");
            lblAltura.setEnabled(false); txtAltura.setEnabled(false);
            txtAltura.setText("");
            break;

        case "Cuadrado":
            // Activos: Base (la usamos como "lado")
            lblBase.setEnabled(true);  txtBase.setEnabled(true);
            txtBase.setText("");
            // Desactivados: Radio y Altura
            lblRadio.setEnabled(false); txtRadio.setEnabled(false);
            txtRadio.setText("");
            lblAltura.setEnabled(false); txtAltura.setEnabled(false);
            txtAltura.setText("");
            break;

        case "Triángulo":
            // Activos: Base y Altura
            lblBase.setEnabled(true);  txtBase.setEnabled(true);
            txtBase.setText("");
            lblAltura.setEnabled(true); txtAltura.setEnabled(true);
            txtAltura.setText("");
            // Desactivados: Radio
            lblRadio.setEnabled(false); txtRadio.setEnabled(false);
            txtRadio.setText("");
            break;
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jPanel1 = new javax.swing.JPanel();
        lblFigura = new javax.swing.JLabel();
        cmbBoxFiguras = new javax.swing.JComboBox<>();
        txtCodigo = new javax.swing.JTextField();
        btnCalcular = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        AreaResults = new javax.swing.JTextArea();
        lblCodigo = new javax.swing.JLabel();
        lblColor = new javax.swing.JLabel();
        lblRadio = new javax.swing.JLabel();
        lblBase = new javax.swing.JLabel();
        lblAltura = new javax.swing.JLabel();
        txtColor = new javax.swing.JTextField();
        txtRadio = new javax.swing.JTextField();
        txtBase = new javax.swing.JTextField();
        txtAltura = new javax.swing.JTextField();
        Jpanel2 = new vista.PanelDibujo();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)), "Panel de Datos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Yu Gothic UI Semibold", 0, 18))); // NOI18N

        lblFigura.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lblFigura.setText("Figura:");

        cmbBoxFiguras.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N

        txtCodigo.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N

        btnCalcular.setBackground(new java.awt.Color(0, 153, 255));
        btnCalcular.setFont(new java.awt.Font("Monospaced", 1, 12)); // NOI18N
        btnCalcular.setForeground(new java.awt.Color(255, 255, 255));
        btnCalcular.setText("Calcular y Dibujar");

        AreaResults.setColumns(20);
        AreaResults.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        AreaResults.setRows(5);
        jScrollPane1.setViewportView(AreaResults);

        lblCodigo.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lblCodigo.setText("Codigo:");

        lblColor.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lblColor.setText("Color:");

        lblRadio.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lblRadio.setText("Radio:");

        lblBase.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lblBase.setText("Base:");

        lblAltura.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lblAltura.setText("Altura:");

        txtColor.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N

        txtRadio.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N

        txtBase.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N

        txtAltura.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(btnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblAltura)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtAltura, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(lblBase)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtBase, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(lblRadio)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtRadio, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(lblColor)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtColor, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(lblCodigo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                                .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblFigura)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cmbBoxFiguras, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(48, 48, 48))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFigura)
                    .addComponent(cmbBoxFiguras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCodigo))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblColor)
                    .addComponent(txtColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRadio)
                    .addComponent(txtRadio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBase)
                    .addComponent(txtBase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAltura)
                    .addComponent(txtAltura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );

        javax.swing.GroupLayout Jpanel2Layout = new javax.swing.GroupLayout(Jpanel2);
        Jpanel2.setLayout(Jpanel2Layout);
        Jpanel2Layout.setHorizontalGroup(
            Jpanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 255, Short.MAX_VALUE)
        );
        Jpanel2Layout.setVerticalGroup(
            Jpanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(Jpanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(139, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Jpanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(71, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new JFFigurasGeometricas().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea AreaResults;
    public vista.PanelDibujo Jpanel2;
    public javax.swing.JButton btnCalcular;
    public javax.swing.JComboBox<String> cmbBoxFiguras;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JLabel lblAltura;
    public javax.swing.JLabel lblBase;
    public javax.swing.JLabel lblCodigo;
    public javax.swing.JLabel lblColor;
    public javax.swing.JLabel lblFigura;
    public javax.swing.JLabel lblRadio;
    public javax.swing.JTextField txtAltura;
    public javax.swing.JTextField txtBase;
    public javax.swing.JTextField txtCodigo;
    public javax.swing.JTextField txtColor;
    public javax.swing.JTextField txtRadio;
    // End of variables declaration//GEN-END:variables
}
