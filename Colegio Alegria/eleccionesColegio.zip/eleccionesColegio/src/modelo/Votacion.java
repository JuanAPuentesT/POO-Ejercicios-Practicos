package Modelo;

import java.util.ArrayList;

public class Votacion {

    private int votosNulos;
    private int votosBlancos;
    private ArrayList<CandidatoPersonero> candidatosPersonero;
    private ArrayList<CandidatoRepresentante> candidatosRepresentante;

    public Votacion() {
        this.votosNulos = 0;
        this.votosBlancos = 0;
        this.candidatosPersonero = new ArrayList<>();
        this.candidatosRepresentante = new ArrayList<>();
    }

    public int getVotosNulos() {
        return votosNulos;
    }

    public void setVotosNulos(int votosNulos) {
        this.votosNulos = votosNulos;
    }

    public int getVotosBlancos() {
        return votosBlancos;
    }

    public void setVotosBlancos(int votosBlancos) {
        this.votosBlancos = votosBlancos;
    }

    public ArrayList<CandidatoPersonero> getCandidatosPersonero() {
        return candidatosPersonero;
    }

    public void setCandidatosPersonero(ArrayList<CandidatoPersonero> candidatosPersonero) {
        this.candidatosPersonero = candidatosPersonero;
    }

    public ArrayList<CandidatoRepresentante> getCandidatosRepresentante() {
        return candidatosRepresentante;
    }

    public void setCandidatosRepresentante(ArrayList<CandidatoRepresentante> candidatosRepresentante) {
        this.candidatosRepresentante = candidatosRepresentante;
    }
    

    public void agregarPersonero(CandidatoPersonero c) {
        candidatosPersonero.add(c);
    }

    public void agregarRepresentante(CandidatoRepresentante c) {
        candidatosRepresentante.add(c);
    }

    public void registrarVotoPersonero(CandidatoPersonero c) {
        c.recibirVoto();
    }

    public void registrarVotoRepresentante(CandidatoRepresentante c) {
        c.recibirVoto();
    }

    public void registrarVotoBlanco() {
        this.votosBlancos++;
    }

    public void registrarVotoNulo() {
        this.votosNulos++;
    }

    public CandidatoPersonero obtenerGanadorPersonero() {
        if (candidatosPersonero.isEmpty()) return null;
        CandidatoPersonero ganador = candidatosPersonero.get(0);
        for (CandidatoPersonero c : candidatosPersonero) {
            if (c.obtenerVotos() > ganador.obtenerVotos()) ganador = c;
        }
        return ganador;
    }

    public CandidatoPersonero obtenerMenorVotacionPersonero() {
        if (candidatosPersonero.isEmpty()) return null;
        CandidatoPersonero menor = candidatosPersonero.get(0);
        for (CandidatoPersonero c : candidatosPersonero) {
            if (c.obtenerVotos() < menor.obtenerVotos()) menor = c;
        }
        return menor;
    }

    public int calcularPoblacionElectoral() {
        int total = 0;
        for (CandidatoPersonero c : candidatosPersonero) total += c.obtenerVotos();
        for (CandidatoRepresentante c : candidatosRepresentante) total += c.obtenerVotos();
        return total + votosNulos + votosBlancos;
    }

}