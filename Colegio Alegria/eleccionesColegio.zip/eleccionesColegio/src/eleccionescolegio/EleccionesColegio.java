package eleccionescolegio;

import Controlador.ControladorRegistrarCandidato;
import vista.JFRegistrarCandidato;

public class EleccionesColegio {

    public static void main(String[] args) {
        JFRegistrarCandidato frame = new JFRegistrarCandidato();
        frame.setVisible(true);
        new ControladorRegistrarCandidato(frame);
    }
}