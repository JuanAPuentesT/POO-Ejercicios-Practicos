
package Controlador;

import Modelo.Acuatico;
import Modelo.Aereo;
import Modelo.Animal;
import Modelo.CandidatoPersonero;
import Modelo.Terrestre;
import vista.JFAnimal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

public class ControladorAnimal implements ActionListener {

    private JFAnimal frmAnimal;
    private ArrayList<CandidatoPersonero> listaPersoneros;
    private ArrayList<Animal> listaAnimales;

    public ControladorAnimal(JFAnimal frmAnimal,ArrayList<CandidatoPersonero> listaPersoneros,ArrayList<Animal> listaAnimales) {
        this.frmAnimal = frmAnimal;
        this.listaPersoneros = listaPersoneros;
        this.listaAnimales = listaAnimales;

        this.frmAnimal.btnGuardar.addActionListener(this);
        this.frmAnimal.btnLimpiar.addActionListener(this);
        this.frmAnimal.btnVolverAnimal.addActionListener(this);

        cargarComboCandidatos();
        // Los animales ya vienen cargados por eso no cargamos el cmbobox
    }

    // Llena el combo con los candidatos personeros que aun no tienen una mascota
    public void cargarComboCandidatos() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        for (CandidatoPersonero cp : listaPersoneros) {
            if (cp.getMascota() == null) {
                //Esto muestra los candidatos sin mascotas
                modelo.addElement(cp.getNombre() + " " + cp.getApellido() + " - T#" + cp.getNumeroTarjeton());
            }
        }
        // Si todos ya tienen mascota el combo queda vacío
        if (modelo.getSize() == 0) {
            modelo.addElement("Todos los candidatos ya tienen mascota");
        }
        frmAnimal.cmbBoxCandidatoAnimal.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmAnimal.btnGuardar)guardarAnimal();
        if (e.getSource() == frmAnimal.btnLimpiar)limpiarCampos();
        if (e.getSource() == frmAnimal.btnVolverAnimal)volverAtras();
    }

    private void guardarAnimal() {
        try {
            String textoId    = frmAnimal.txtIdentificacionAnimal.getText().trim();
            String nombre     = frmAnimal.txtNombreAnimal.getText().trim();
            String genero     = frmAnimal.txtGeneroAnimal.getText().trim();
            String textoEdad  = frmAnimal.txtEdadAnimal.getText().trim();
            String cualidades = frmAnimal.txtCualidadesAimal.getText().trim();

            if (textoId.isEmpty() || nombre.isEmpty() || genero.isEmpty()
                    || textoEdad.isEmpty() || cualidades.isEmpty()) {
                frmAnimal.AreaAnimales.setText("Complete todos los campos del animal.");
                return;
            }

            int identificacion = Integer.parseInt(textoId);
            int edad           = Integer.parseInt(textoEdad);

            // Elegir tipo de animal creando un array
            //showOptionDialog = muestra una ventana emergente y permite escoger opciones y devuelve un int
            String[] opciones = {"Aéreo", "Terrestre", "Acuático"};
            int seleccion = javax.swing.JOptionPane.showOptionDialog(frmAnimal, "¿Qué tipo de animal es?", "Tipo de Animal",javax.swing.JOptionPane.DEFAULT_OPTION,javax.swing.JOptionPane.QUESTION_MESSAGE,null, opciones, opciones[0]);
            if (seleccion == -1) return;

            // Polimorfismo: variable Animal apunta a la subclase correspondiente
            Animal nuevoAnimal;
            switch (seleccion) {
                case 0:  nuevoAnimal = new Aereo(identificacion, nombre, genero, edad, cualidades);     break;
                case 1:  nuevoAnimal = new Terrestre(identificacion, nombre, genero, edad, cualidades); break;
                default: nuevoAnimal = new Acuatico(identificacion, nombre, genero, edad, cualidades);  break;
            }

            // Asignar al candidato seleccionado en el combo
            CandidatoPersonero candidato = obtenerCandidatoSeleccionado();
            if (candidato == null) {
                frmAnimal.AreaAnimales.setText("No hay candidatos disponibles para asignar.");
                return;
            }
            candidato.setMascota(nuevoAnimal);
            listaAnimales.add(nuevoAnimal);

            frmAnimal.AreaAnimales.setText("Animal registrado y asignado:\n" +"Tipo: "+ opciones[seleccion] + "\n" +"ID: " + identificacion + "\n" +"Nombre: "+ nombre + "\n" +"Género: " + genero + "\n" +"Edad: " + edad + " años\n"+"Cualidades: " + cualidades + "\n" +"Asignado a: " + candidato.getNombre()+ " " + candidato.getApellido());

            // Actualizamos el combo apra que desaparezcan los candidatos guardados
            cargarComboCandidatos();
            limpiarCampos();

        } catch (NumberFormatException ex) {
            frmAnimal.AreaAnimales.setText("La identificación y la edad deben ser números enteros.");
        }
    }

    // Busca el candidato en la lista según el índice del combo
    // Solo entre los que no tienen mascota (los que muestra el combo)
    private CandidatoPersonero obtenerCandidatoSeleccionado() {
        int comboIndex = frmAnimal.cmbBoxCandidatoAnimal.getSelectedIndex();
        int contador = 0;
        for (CandidatoPersonero cp : listaPersoneros) {
            if (cp.getMascota() == null) {
                if (contador == comboIndex) return cp;
                contador++;
            }
        }
        return null;
    }

    private void limpiarCampos() {
        frmAnimal.txtIdentificacionAnimal.setText("");
        frmAnimal.txtNombreAnimal.setText("");
        frmAnimal.txtGeneroAnimal.setText("");
        frmAnimal.txtEdadAnimal.setText("");
        frmAnimal.txtCualidadesAimal.setText("");
    }

    private void volverAtras() {
        frmAnimal.dispose();
    }
}
