package Controlador;

import Modelo.Acuatico;
import Modelo.Aereo;
import Modelo.Animal;
import Modelo.CandidatoPersonero;
import Modelo.CandidatoRepresentante;
import Modelo.Estudiante;
import Modelo.Terrestre;
import vista.JFRegistrarCandidato;
import vista.JFAnimal;
import vista.JFFormula;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

public class ControladorRegistrarCandidato implements ActionListener {

    private JFRegistrarCandidato frmCandidato;
    private ArrayList<CandidatoPersonero> listaPersoneros;
    private ArrayList<CandidatoRepresentante> listaRepresentantes;
    private ArrayList<Animal> listaAnimales;
    private int numEstudiantesVotan;

    public ControladorRegistrarCandidato(JFRegistrarCandidato frmCandidato) {
        this.frmCandidato = frmCandidato;
        this.listaPersoneros = new ArrayList<>();
        this.listaRepresentantes = new ArrayList<>();
        this.listaAnimales = new ArrayList<>();

        this.frmCandidato.btnGuardarCandidato.addActionListener(this);
        this.frmCandidato.btnRegistrarAnimal.addActionListener(this);
        this.frmCandidato.btnRegistraFormula.addActionListener(this);
        this.frmCandidato.btnIniciarVotacion.addActionListener(this);

        cargarComboCandidato();
        cargarDatosPrecargados(); // con esto cargamos candidatos y animales ya enlazados
    }

    public void cargarComboCandidato() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        modelo.addElement("Personero");
        modelo.addElement("Representante");
        frmCandidato.cmbBoxTipoCandidato.setModel(modelo);
    }

    public void cargarDatosPrecargados() {
        //Animales para personero
        Animal aguila = new Aereo(1,    "Aguila Real","Macho",4,"Vista aguda y liderazgo");
        Animal leon = new Terrestre(2,"Leon","Macho",6, "Fuerza y valentía");
        Animal delfin = new Acuatico(3, "Delfin","Hembra", 3,"Inteligencia y agilidad");
        Animal condor = new Aereo(4,"Condor","Macho",  5,"Libertad y visión");
        Animal tigre = new Terrestre(5,"Tigre","Macho",4, "Velocidad y determinación");

        listaAnimales.add(aguila);
        listaAnimales.add(leon);
        listaAnimales.add(delfin);
        listaAnimales.add(condor);
        listaAnimales.add(tigre);

        // Candidatos a personero con mascota
        CandidatoPersonero p1 = new CandidatoPersonero("Sofia", "Ramirez", 11, "A", "Juntos somos más", 1, aguila);
        CandidatoPersonero p2 = new CandidatoPersonero("Carlos", "Mendez", 10, "B", "El cambio empieza hoy", 2, leon);
        CandidatoPersonero p3 = new CandidatoPersonero("Valentina", "Torres", 11, "C", "Unidos por la educación", 3, delfin);
        CandidatoPersonero p4 = new CandidatoPersonero("Andres", "Lopez", 10, "A", "Voz estudiantil", 4, condor);
        CandidatoPersonero p5 = new CandidatoPersonero("Mariana", "Gomez", 9, "B", "Tu opinión importa", 5, tigre);

        listaPersoneros.add(p1);
        listaPersoneros.add(p2);
        listaPersoneros.add(p3);
        listaPersoneros.add(p4);
        listaPersoneros.add(p5);

        // Estudiantes de fórmula para representantes
        Estudiante e1 = new Estudiante("Luis",    "Perez",   11, "A");
        Estudiante e2 = new Estudiante("Daniela", "Castro",  10, "B");
        Estudiante e3 = new Estudiante("Miguel",  "Vargas",  9,  "C");

        // Candidatos representantes con su formula
        CandidatoRepresentante r1 = new CandidatoRepresentante("Juan", "Rios", 11, "A", "Grado 11 primero", 6, e1);
        CandidatoRepresentante r2 = new CandidatoRepresentante("Laura", "Silva", 10, "B", "Por un mejor grado 10", 7, e2);
        CandidatoRepresentante r3 = new CandidatoRepresentante("Diego", "Mora", 9, "C", "Grado 9 con fuerza", 8, e3);

        listaRepresentantes.add(r1);
        listaRepresentantes.add(r2);
        listaRepresentantes.add(r3);

        // Mostrar resumen en el área
        frmCandidato.ResultadosCandidatos.setText("Datos precargados:\n" +listaPersoneros.size()     + " candidatos a personero\n" +listaRepresentantes.size() + " candidatos representantes\n" +listaAnimales.size()       + " animales registrados\n\n" +"Puede registrar nuevos candidatos o iniciar la votación.");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmCandidato.btnGuardarCandidato)guardarCandidato();
        if (e.getSource() == frmCandidato.btnRegistrarAnimal)abrirFrameAnimal();
        if (e.getSource() == frmCandidato.btnRegistraFormula)abrirFrameFormula();
        if (e.getSource() == frmCandidato.btnIniciarVotacion)iniciarVotacion();
    }

    private void guardarCandidato() {
        try {
            String nombre  = frmCandidato.txtxNombreCandidato.getText().trim();
            String apellido= frmCandidato.txtApellidoCandidato.getText().trim();
            String lema    = frmCandidato.txtLemaCandidato.getText().trim();
            String tipo    = (String) frmCandidato.cmbBoxTipoCandidato.getSelectedItem();

            int grado      = Integer.parseInt(frmCandidato.txtGradoCandidato.getText().trim());
            String grupo   = frmCandidato.txtCursoCandidato2.getText().trim();
            int tarjeton   = Integer.parseInt(frmCandidato.txtNumTarjeton.getText().trim());

            if (nombre.isEmpty() || apellido.isEmpty() || lema.isEmpty() || grupo.isEmpty()) {
                frmCandidato.ResultadosCandidatos.setText("Complete todos los campos.");
                return;
            }

            // Verificar que el número de tarjetón no exista ya
            for (CandidatoPersonero cp : listaPersoneros) {
                if (cp.getNumeroTarjeton() == tarjeton) {
                    frmCandidato.ResultadosCandidatos.setText("Ya existe un candidato con ese número de tarjetón.");
                    return;
                }
            }
            for (CandidatoRepresentante cr : listaRepresentantes) {
                if (cr.getNumeroTarjeton() == tarjeton) {
                    frmCandidato.ResultadosCandidatos.setText("Ya existe un candidato con ese número de tarjetón.");
                    return;
                }
            }

            if (tipo.equals("Personero")) {
                // mascota esta vacia ya q se le asigna en JFAnimal
                CandidatoPersonero nuevo = new CandidatoPersonero(nombre, apellido, grado, grupo, lema, tarjeton, null);
                listaPersoneros.add(nuevo);
                frmCandidato.ResultadosCandidatos.setText("Personero registrado: " + nombre + " " + apellido + "\n" +"Recuerde asignarle un animal desde 'Registrar Animal'.");
            } else {
                // formula esta vacia tmb porque se le asiga en el otro frame
                CandidatoRepresentante nuevo = new CandidatoRepresentante(nombre, apellido, grado, grupo, lema, tarjeton, null);
                listaRepresentantes.add(nuevo);
                frmCandidato.ResultadosCandidatos.setText("Representante registrado: " + nombre + " " + apellido + "\n" +"Recuerde asignarle una fórmula desde 'Registrar Fórmula'.");
            }
            limpiarCampos();

        } catch (NumberFormatException ex) {
            frmCandidato.ResultadosCandidatos.setText("Grado y número de tarjetón deben ser números.");
        }
    }

    // Esto abre JFanimal
    private void abrirFrameAnimal() {
        if (listaPersoneros.isEmpty()) {
            frmCandidato.ResultadosCandidatos.setText("Primero registre al menos un candidato a personero.");
            return;
        }
        JFAnimal frmAnimal = new JFAnimal();
        frmAnimal.setVisible(true);
        new ControladorAnimal(frmAnimal, listaPersoneros, listaAnimales);
    }

    // Esto abre JFFormula
    private void abrirFrameFormula() {
        if (listaRepresentantes.isEmpty()) {
            frmCandidato.ResultadosCandidatos.setText("Primero registre al menos un candidato representante.");
            return;
        }
        JFFormula frmFormula = new JFFormula();
        frmFormula.setVisible(true);
        new ControladorFormula(frmFormula, listaRepresentantes);
    }

    //Validaciones antes de empezar a votar
    private void iniciarVotacion() {
        // Verificar número de estudiantes
        String textoEst = frmCandidato.txtNumEstudiantesVotan.getText().trim();
        if (textoEst.isEmpty()) {
            frmCandidato.ResultadosCandidatos.setText("Ingrese el número de estudiantes que votan.");
            return;
        }

        try {
            numEstudiantesVotan = Integer.parseInt(textoEst);
        } catch (NumberFormatException ex) {
            frmCandidato.ResultadosCandidatos.setText("El número de estudiantes debe ser un entero.");
            return;
        }

        // Validar que cada personero tenga mascota
        StringBuilder faltantes = new StringBuilder();
        for (CandidatoPersonero cp : listaPersoneros) {
            if (cp.getMascota() == null) {
                faltantes.append("Personero ").append(cp.getNombre()).append(" ").append(cp.getApellido()).append(" sin mascota\n");
            }
        }

        // Validar que cada representante tenga formula
        for (CandidatoRepresentante cr : listaRepresentantes) {
            if (cr.getFormula() == null) {
                faltantes.append("Representante ").append(cr.getNombre()).append(" ").append(cr.getApellido()).append(" sin fórmula\n");
            }
        }

        // Si hay faltantes, no deja continuar
        if (faltantes.length() > 0) {
            frmCandidato.ResultadosCandidatos.setText("No se puede iniciar la votación. Faltan:\n" + faltantes.toString());
            return;
        }

        // Todo completo: abrir frame de votación
        vista.JFVotacion frmVotacion = new vista.JFVotacion();
        frmVotacion.setVisible(true);
        new ControladorVotacion(frmVotacion, listaPersoneros, listaRepresentantes, numEstudiantesVotan);
    }

    private void limpiarCampos() {
        frmCandidato.txtxNombreCandidato.setText("");
        frmCandidato.txtApellidoCandidato.setText("");
        frmCandidato.txtLemaCandidato.setText("");
        frmCandidato.txtGradoCandidato.setText("");
        frmCandidato.txtCursoCandidato2.setText("");
        frmCandidato.txtNumTarjeton.setText("");
        frmCandidato.cmbBoxTipoCandidato.setSelectedIndex(0);
    }

    // Getters para que el main acceda a las listas 
    public ArrayList<CandidatoPersonero> getListaPersoneros() {
        return listaPersoneros;
    }

    public ArrayList<CandidatoRepresentante> getListaRepresentantes() {
        return listaRepresentantes;
    }

    public ArrayList<Animal> getListaAnimales() {
        return listaAnimales;
    }
}
