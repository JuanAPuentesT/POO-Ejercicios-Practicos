
package Controlador;

import Modelo.CandidatoPersonero;
import Modelo.CandidatoRepresentante;
import Modelo.Votacion;
import vista.JFVotacion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

public class ControladorVotacion implements ActionListener {

    private JFVotacion frmVotacion;
    private Votacion votacion;
    private int numEstudiantesVotan;
    private int votosRegistrados; // lleva la cuenta de cuántos han votado ya

    public ControladorVotacion(JFVotacion frmVotacion,ArrayList<CandidatoPersonero> listaPersoneros, ArrayList<CandidatoRepresentante> listaRepresentantes,int numEstudiantesVotan) {
        this.frmVotacion = frmVotacion;
        this.numEstudiantesVotan  = numEstudiantesVotan;
        this.votosRegistrados  = 0;

        // Creamos Votacion y le pasamos las listas
        this.votacion = new Votacion();
        for (CandidatoPersonero cp : listaPersoneros)votacion.agregarPersonero(cp);
        for (CandidatoRepresentante cr : listaRepresentantes) votacion.agregarRepresentante(cr);

        this.frmVotacion.btnVotar.addActionListener(this);
        this.frmVotacion.btnMostarResultados.addActionListener(this);

        cargarComboCandidatos();
    }

    // Llenamos el combo con los candidatos y opcion blanco o nulo
    public void cargarComboCandidatos() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();

        for (CandidatoPersonero cp : votacion.getCandidatosPersonero()) {
            modelo.addElement("P - " + cp.getNombre() + " " + cp.getApellido() +" | Tarjetón #" + cp.getNumeroTarjeton() +" | Lema: " + cp.getLema());
        }
        for (CandidatoRepresentante cr : votacion.getCandidatosRepresentante()) {
            modelo.addElement("R - " + cr.getNombre() + " " + cr.getApellido() +" | Tarjetón #" + cr.getNumeroTarjeton() +" | Grado: " + cr.getGrado());
        }

        modelo.addElement("--- VOTO EN BLANCO ---");
        modelo.addElement("--- VOTO NULO ---");

        frmVotacion.cmbBoxCandidatos.setModel(modelo);

        // Mostramos cuantos pueden votar
        frmVotacion.ResultadosVotacion.setText("Votación iniciada.\n" +"Estudiantes habilitados: " + numEstudiantesVotan + "\n" +"Seleccione un candidato y presione Votar.");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmVotacion.btnVotar)registrarVoto();
        if (e.getSource() == frmVotacion.btnMostarResultados)mostrarResultados();
    }

    private void registrarVoto() {
        // Verificamos que no se haya superado el num de estudiantes habilitados para votar
        if (votosRegistrados >= numEstudiantesVotan) {
            frmVotacion.ResultadosVotacion.setText( "Votación cerrada.\n" +"Ya votaron los " + numEstudiantesVotan + " estudiantes habilitados.\n" +"Presione 'Mostrar Resultados' para ver los resultados.");
            this.frmVotacion.btnVotar.setEnabled(false);
            return;
        }

        int indice = frmVotacion.cmbBoxCandidatos.getSelectedIndex();
        int totalPersoneros     = votacion.getCandidatosPersonero().size();
        int totalRepresentantes = votacion.getCandidatosRepresentante().size();

        if (indice < totalPersoneros) {
            // Lee el voto a un personero
            CandidatoPersonero cp = votacion.getCandidatosPersonero().get(indice);
            votacion.registrarVotoPersonero(cp);
            frmVotacion.ResultadosVotacion.setText(
                "Voto registrado para personero: " + cp.getNombre() + " " + cp.getApellido()
            );

        } else if (indice < totalPersoneros + totalRepresentantes) {
            // lee el voto a un representante
            int idx = indice - totalPersoneros;
            CandidatoRepresentante cr = votacion.getCandidatosRepresentante().get(idx);
            votacion.registrarVotoRepresentante(cr);
            frmVotacion.ResultadosVotacion.setText(
                "Voto registrado para representante: " + cr.getNombre() + " " + cr.getApellido()
            );

        } else if (indice == totalPersoneros + totalRepresentantes) {
            // lee el voto en blanco
            votacion.registrarVotoBlanco();
            frmVotacion.ResultadosVotacion.setText("Voto en blanco registrado.");

        } else {
            // lee el voto en nulo
            votacion.registrarVotoNulo();
            frmVotacion.ResultadosVotacion.setText("Voto nulo registrado.");
        }

        votosRegistrados++;
        frmVotacion.ResultadosVotacion.append(
            "\n\nVotos registrados: " + votosRegistrados + " / " + numEstudiantesVotan
        );
    }

    private void mostrarResultados() {
        StringBuilder sb = new StringBuilder();
        sb.append("======= RESULTADOS FINALES =======\n\n");

        sb.append("--- Votos por Personero ---\n");
        for (CandidatoPersonero cp : votacion.getCandidatosPersonero()) {
            sb.append("  ").append(cp.getNombre()).append(" ").append(cp.getApellido())
              .append(" | T#").append(cp.getNumeroTarjeton())
              .append(" | Votos: ").append(cp.obtenerVotos())
              .append(" | Mascota: ").append(cp.getMascota().getNombre()).append("\n");
        }

        sb.append("\n--- Votos por Representante ---\n");
        for (CandidatoRepresentante cr : votacion.getCandidatosRepresentante()) {
            sb.append("  ").append(cr.getNombre()).append(" ").append(cr.getApellido()).append(" | T#").append(cr.getNumeroTarjeton()).append(" | Grado: ").append(cr.getGrado()).append(" | Votos: ").append(cr.obtenerVotos()).append(" | Fórmula: ").append(cr.getFormula().getNombre()).append("\n");
        }

        CandidatoPersonero ganador = votacion.obtenerGanadorPersonero();
        sb.append("\n---Personero Elegido ---\n");
        if (ganador != null) {
            sb.append("  ").append(ganador.getNombre()).append(" ").append(ganador.getApellido()).append(" con ").append(ganador.obtenerVotos()).append(" votos\n");
        }

        CandidatoPersonero menor = votacion.obtenerMenorVotacionPersonero();
        sb.append("\n--- Menor Votación ---\n");
        if (menor != null) {
            sb.append("  ").append(menor.getNombre()).append(" ").append(menor.getApellido()).append(" con ").append( menor.obtenerVotos()).append(" votos\n");
        }

        sb.append("\n--- Población Electoral ---\n");
        sb.append("  Votos en blanco: ").append(votacion.getVotosBlancos()).append("\n");
        sb.append("  Votos nulos: ").append(votacion.getVotosNulos()).append("\n");
        sb.append("  Total población: ").append(votacion.calcularPoblacionElectoral()).append("\n");

        frmVotacion.ResultadosVotacion.setText(sb.toString());
    }
}
