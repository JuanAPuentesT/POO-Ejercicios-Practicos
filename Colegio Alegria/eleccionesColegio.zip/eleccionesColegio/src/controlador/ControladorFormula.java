
package Controlador;

import Modelo.CandidatoRepresentante;
import Modelo.Estudiante;
import vista.JFFormula;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

public class ControladorFormula implements ActionListener {

    private JFFormula frmFormula;
    private ArrayList<CandidatoRepresentante> listaRepresentantes;

    public ControladorFormula(JFFormula frmFormula,ArrayList<CandidatoRepresentante> listaRepresentantes) {
        this.frmFormula = frmFormula;
        this.listaRepresentantes = listaRepresentantes;

        this.frmFormula.btnGuardarFormula.addActionListener(this);
        this.frmFormula.btnLimpiar.addActionListener(this);
        this.frmFormula.BtnVolverFormula.addActionListener(this);

        cargarComboRepresentantes();
    }

    // Solo muestra representantes que aun no tienen formula
    public void cargarComboRepresentantes() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        for (CandidatoRepresentante cr : listaRepresentantes) {
            if (cr.getFormula() == null) {
                modelo.addElement(cr.getNombre() + " " + cr.getApellido() + " - T#" + cr.getNumeroTarjeton());
            }
        }
        if (modelo.getSize() == 0) {
            modelo.addElement("Todos los representantes ya tienen fórmula");
        }
        frmFormula.cmbBoxFormula.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmFormula.btnGuardarFormula)guardarFormula();
        if (e.getSource() == frmFormula.btnLimpiar)limpiarCampos();
        if (e.getSource() == frmFormula.BtnVolverFormula)volverAtras();
    }

    private void guardarFormula() {
        try {
            String nombre  = frmFormula.txtNameCandidato.getText().trim();
            String apellido= frmFormula.txtApellidoFormula.getText().trim();
            String textoGrado = frmFormula.txtGradoFormula.getText().trim();
            String grupo   = frmFormula.txtGrupoFormula.getText().trim();

            if (nombre.isEmpty() || apellido.isEmpty() || textoGrado.isEmpty() || grupo.isEmpty()) {
                frmFormula.ResultadosFormula.setText("Complete todos los campos de la fórmula.");
                return;
            }

            int grado = Integer.parseInt(textoGrado);

            // Buscamos el representante seleccionado es decir solo el que no tienen formula
            CandidatoRepresentante representante = obtenerRepresentanteSeleccionado();
            if (representante == null) {
                frmFormula.ResultadosFormula.setText("No hay representantes disponibles para asignar fórmula.");
                return;
            }

            // Creamos el estudiante formula y los asignamos
            Estudiante formula = new Estudiante(nombre, apellido, grado, grupo);
            representante.setFormula(formula);

            frmFormula.ResultadosFormula.setText("Fórmula asignada:\n" +"Representante: " + representante.getNombre() + " " + representante.getApellido() + "\n" +"Fórmula: "+ nombre + " " + apellido + "\n" +"Grado: "+ grado + " | Grupo: " + grupo);

            // ctualizamos el combo apra que desaparezcan los representantes guardados ya con formulas
            cargarComboRepresentantes();
            limpiarCampos();

        } catch (NumberFormatException ex) {
            frmFormula.ResultadosFormula.setText("El grado debe ser un número entero.");
        }
    }

    // Busca el representante correcto contando solo los que no tienen formula
    private CandidatoRepresentante obtenerRepresentanteSeleccionado() {
        int comboIndex = frmFormula.cmbBoxFormula.getSelectedIndex();
        int contador = 0;
        for (CandidatoRepresentante cr : listaRepresentantes) {
            if (cr.getFormula() == null) {
                if (contador == comboIndex) return cr;
                contador++;
            }
        }
        return null;
    }

    private void limpiarCampos() {
        frmFormula.txtNameCandidato.setText("");
        frmFormula.txtApellidoFormula.setText("");
        frmFormula.txtGradoFormula.setText("");
        frmFormula.txtGrupoFormula.setText("");
    }

    private void volverAtras() {
        frmFormula.dispose();
    }
}
