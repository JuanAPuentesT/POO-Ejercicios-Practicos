package recomendarpelicula;

import Controlador.ControladorLogin;
import Modelo.SistemaRecomendacion;
import Vista.JFLogin;

/**
 * Clase principal - punto de entrada del programa.
 */
public class RecomendarPelicula {

    public static void main(String[] args) {
        // Crear el sistema central (contiene peliculas precargadas)
        SistemaRecomendacion sistema = new SistemaRecomendacion();

        // Abrir el frame de login
        JFLogin frmLogin = new JFLogin();
        new ControladorLogin(frmLogin, sistema);
        frmLogin.setVisible(true);
    }
}
