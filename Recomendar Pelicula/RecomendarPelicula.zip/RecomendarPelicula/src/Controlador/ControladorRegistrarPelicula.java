package Controlador;

import Modelo.*;
import Vista.JFRegistrarPelicula;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 * ControladorRegistrarPelicula - gestiona el registro de nuevas películas.
 */
public class ControladorRegistrarPelicula implements ActionListener {

    private JFRegistrarPelicula frmRegistrar;
    private SistemaRecomendacion sistema;
    private ControladorPrincipal controladorPrincipal;

    private static final String[] GENEROS = {
        "Acción", "Drama", "Comedia", "Terror", "Romance",
        "Ciencia Ficción", "Animación", "Thriller", "Documental"
    };

    public ControladorRegistrarPelicula(JFRegistrarPelicula frmRegistrar,
            SistemaRecomendacion sistema,
            ControladorPrincipal controladorPrincipal) {
        this.frmRegistrar = frmRegistrar;
        this.sistema = sistema;
        this.controladorPrincipal = controladorPrincipal;

        this.frmRegistrar.btnGuardar.addActionListener(this);
        this.frmRegistrar.btnLimpiar.addActionListener(this);
        this.frmRegistrar.btnCerrar.addActionListener(this);

        cargarGeneros();
    }

    private void cargarGeneros() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        for (String g : GENEROS) {
            modelo.addElement(g);
        }
        frmRegistrar.cmbGenero.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmRegistrar.btnGuardar) {
            guardarPelicula();
        }
        if (e.getSource() == frmRegistrar.btnLimpiar) {
            limpiarCampos();
        }
        if (e.getSource() == frmRegistrar.btnCerrar) {
            frmRegistrar.dispose();
        }
    }

    private void guardarPelicula() {
        try {
            String titulo = frmRegistrar.txtTitulo.getText().trim();
            String autor = frmRegistrar.txtAutor.getText().trim();
            int año = Integer.parseInt(frmRegistrar.txtAño.getText().trim());
            int duracion = Integer.parseInt(frmRegistrar.txtDuracion.getText().trim());
            String genero = (String) frmRegistrar.cmbGenero.getSelectedItem();

            if (titulo.isEmpty() || autor.isEmpty()) {
                frmRegistrar.areaInfo.setText("El título y el director son obligatorios.");
                return;
            }

            Pelicula nueva = new Pelicula(titulo, duracion, autor, año, genero);
            sistema.getPeliculas().add(nueva);

            frmRegistrar.areaInfo.setText("✅ Película registrada con éxito:\n"+ "Título:   " + titulo + "\n"+ "Director: " + autor  + "\n"+ "Año:      " + año    + "\n"+ "Duración: " + duracion + " min\n"+ "Género:   " + genero);

            limpiarCampos();

        } catch (NumberFormatException ex) {
            frmRegistrar.areaInfo.setText("⚠ El año y la duración deben ser números enteros.");
        }
    }

    private void limpiarCampos() {
        frmRegistrar.txtTitulo.setText("");
        frmRegistrar.txtAutor.setText("");
        frmRegistrar.txtAño.setText("");
        frmRegistrar.txtDuracion.setText("");
    }
}
