package Controlador;

import Modelo.*;
import Vista.JFPrincipal;
import Vista.JFRegistrarPelicula;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class ControladorPrincipal implements ActionListener {

    private JFPrincipal frmPrincipal;
    private SistemaRecomendacion sistema;
    private Usuario usuarioActivo;

    private static final String[] TIPOS_BUSQUEDA = {"Por Título", "Por Género", "Por Director"};

    public ControladorPrincipal(JFPrincipal frmPrincipal,
        SistemaRecomendacion sistema,
        Usuario usuarioActivo) {
        this.frmPrincipal = frmPrincipal;
        this.sistema = sistema;
        this.usuarioActivo = usuarioActivo;

        this.frmPrincipal.btnBuscar.addActionListener(this);
        this.frmPrincipal.btnRecomendar.addActionListener(this);
        this.frmPrincipal.btnVerHistorial.addActionListener(this);
        this.frmPrincipal.btnCalificar.addActionListener(this);
        this.frmPrincipal.btnRegistrarPelicula.addActionListener(this);
        this.frmPrincipal.btnSalir.addActionListener(this);

        cargarCombosBusqueda();
        frmPrincipal.lblUsuarioActivo.setText("Usuario: " + usuarioActivo.getNombre()+ "  |  Email: " + usuarioActivo.getEmail());

        // Mostrar todas las películas al abrir
        mostrarTodasLasPeliculas();
    }

    private void cargarCombosBusqueda() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        for (String t : TIPOS_BUSQUEDA) {
            modelo.addElement(t);
        }
        frmPrincipal.cmbTipoBusqueda.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmPrincipal.btnBuscar)buscarPelicula();
        if (e.getSource() == frmPrincipal.btnRecomendar)recomendarPeliculas();
        if (e.getSource() == frmPrincipal.btnVerHistorial)verHistorial();
        if (e.getSource() == frmPrincipal.btnCalificar)calificarPelicula();
        if (e.getSource() == frmPrincipal.btnRegistrarPelicula)abrirRegistrarPelicula();
        if (e.getSource() == frmPrincipal.btnSalir)System.exit(0);
    }

    // ── Buscar ───
    private void buscarPelicula() {
        String texto = frmPrincipal.txtBuscar.getText().trim();
        if (texto.isEmpty()) {
            mostrarTodasLasPeliculas();
            return;
        }

        String tipo = (String) frmPrincipal.cmbTipoBusqueda.getSelectedItem();
        ArrayList<Pelicula> resultados;

        switch (tipo) {
            case "Por Título":
                resultados = sistema.BusquedabyTittle(texto);
                break;
            case "Por Género":
                resultados = sistema.BusquedaByGenre(texto);
                break;
            default:
                resultados = sistema.BusquedaByAuthor(texto);
                break;
        }

        if (resultados.isEmpty()) {
            frmPrincipal.areaResultados.setText("No se encontraron películas con ese criterio.");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("🔍 Resultados para \"").append(texto).append("\" (").append(tipo).append("):\n");
            sb.append("─".repeat(55)).append("\n");
            for (Pelicula p : resultados) {
                sb.append(formatearPelicula(p)).append("\n");
            }
            frmPrincipal.areaResultados.setText(sb.toString());
        }
    }

    // ── Recomendar ───
    private void recomendarPeliculas() {
        ArrayList<Pelicula> recomendadas = sistema.recomendar(usuarioActivo);

        if (recomendadas.isEmpty()) {
            frmPrincipal.areaResultados.setText("No hay recomendaciones disponibles.\n"+ "Tip: ya viste todas las películas de tus géneros preferidos,\n"+ "o no hay películas con calificación ≥ 4.0 sin ver.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("⭐ Recomendaciones para ").append(usuarioActivo.getNombre()).append(":\n");
        sb.append("─".repeat(55)).append("\n");
        for (Pelicula p : recomendadas) {
            sb.append(formatearPelicula(p)).append("\n");
        }
        frmPrincipal.areaResultados.setText(sb.toString());

        // Notificación
        Notificacion notif = new Notificacion(
            "Tienes " + recomendadas.size() + " película(s) recomendada(s).",
            obtenerFechaHoy()
        );
        frmPrincipal.areaResultados.append("\n📢 " + notif.enviar());
    }

    // ── Historial ──
    private void verHistorial() {
        ArrayList<HistorialPelicula> historial = usuarioActivo.getHistorial();

        if (historial.isEmpty()) {
            frmPrincipal.areaResultados.setText("Tu historial está vacío.\n"+ "Usa 'Calificar' para registrar una película vista.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("📋 Historial de ").append(usuarioActivo.getNombre()).append(":\n");
        sb.append("─".repeat(55)).append("\n");
        for (HistorialPelicula h : historial) {
            sb.append("• ").append(h.getPelicula().getTitulo())
              .append(" — visto el ").append(h.getFechaVista().toString())
              .append(" (").append(h.getTiempoVisto()).append(" min)\n");
        }
        frmPrincipal.areaResultados.setText(sb.toString());
    }

    // ── Calificar ───
    private void calificarPelicula() {
        // Elegir película
        ArrayList<Pelicula> peliculas = sistema.getPeliculas();
        String[] titulos = new String[peliculas.size()];
        for (int i = 0; i < peliculas.size(); i++) {
            titulos[i] = peliculas.get(i).getTitulo();
        }

        String seleccion = (String) JOptionPane.showInputDialog(
            frmPrincipal, "Selecciona la película que viste:",
            "Calificar Película", JOptionPane.QUESTION_MESSAGE,
            null, titulos, titulos[0]);

        if (seleccion == null) return;

        Pelicula pelicula = null;
        for (Pelicula p : peliculas) {
            if (p.getTitulo().equals(seleccion)) { pelicula = p; break; }
        }

        // Puntajes
        String puntajeStr = JOptionPane.showInputDialog(frmPrincipal,
            "Puntuación (0.0 a 5.0):");
        if (puntajeStr == null) return;

        // comentarios
        String comentario = JOptionPane.showInputDialog(frmPrincipal,
            "Comentario (opcional):");
        if (comentario == null) comentario = "";

        try {
            double puntuacion = Double.parseDouble(puntajeStr.replace(",", "."));
            if (puntuacion < 0 || puntuacion > 5) {
                frmPrincipal.areaResultados.setText("⚠ La puntuación debe estar entre 0.0 y 5.0.");
                return;
            }

            usuarioActivo.calificar(pelicula, puntuacion, comentario);
            usuarioActivo.verHistorial(pelicula, pelicula.getDuracion());

            frmPrincipal.areaResultados.setText("✅ Calificación registrada:\n"+ "Película:     " + pelicula.getTitulo() + "\n"+ "Puntuación:   " + puntuacion + " / 5.0\n"+ "Comentario:   " + comentario + "\n"+ "Nuevo promedio de la película: "+ String.format("%.2f", pelicula.getCalificacionPromedio()));

        } catch (NumberFormatException ex) {
            frmPrincipal.areaResultados.setText("⚠ Ingresa un número válido para la puntuación.");
        }
    }

    // ── Registrar película ───
    private void abrirRegistrarPelicula() {
        JFRegistrarPelicula frm = new JFRegistrarPelicula();
        new ControladorRegistrarPelicula(frm, sistema, this);
        frm.setVisible(true);
    }

    // ── Mostrar catálogo completo ───
    private void mostrarTodasLasPeliculas() {
        StringBuilder sb = new StringBuilder();
        sb.append("🎬 Catálogo completo (").append(sistema.getPeliculas().size()).append(" películas):\n");
        sb.append("─".repeat(55)).append("\n");
        for (Pelicula p : sistema.getPeliculas()) {
            sb.append(formatearPelicula(p)).append("\n");
        }
        frmPrincipal.areaResultados.setText(sb.toString());
    }

    // ── Helpers ───
    private String formatearPelicula(Pelicula p) {
        return String.format("• %-35s | %s | %d min | ★ %.1f",
            p.getTitulo(), p.getGenero(), p.getDuracion(), p.getCalificacionPromedio());
    }

    private Fecha obtenerFechaHoy() {
        java.time.LocalDate hoy = java.time.LocalDate.now();
        return new Fecha(hoy.getDayOfMonth(), hoy.getMonthValue(), hoy.getYear());
    }
}
