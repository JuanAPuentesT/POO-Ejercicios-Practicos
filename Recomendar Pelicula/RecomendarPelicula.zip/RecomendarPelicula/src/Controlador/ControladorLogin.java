package Controlador;

import Modelo.*;
import Vista.JFLogin;
import Vista.JFPrincipal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 * ControladorLogin -
 */
public class ControladorLogin implements ActionListener {

    private JFLogin frmLogin;
    private SistemaRecomendacion sistema;

    private static final String[] GENEROS_DISPONIBLES = {
        "Acción", "Drama", "Comedia", "Terror", "Romance",
        "Ciencia Ficción", "Animación", "Thriller", "Documental"
    };

    public ControladorLogin(JFLogin frmLogin, SistemaRecomendacion sistema) {
        this.frmLogin = frmLogin;
        this.sistema  = sistema;

        this.frmLogin.btnIniciar.addActionListener(this);
        this.frmLogin.btnRegistrar.addActionListener(this);

        cargarGeneros();
    }

    private void cargarGeneros() {
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        for (String g : GENEROS_DISPONIBLES) {
            modelo.addElement(g);
        }
        frmLogin.cmbGeneroPreferido.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmLogin.btnRegistrar) {
            registrarUsuario();
        }
        if (e.getSource() == frmLogin.btnIniciar) {
            iniciarSesion();
        }
    }

    private void registrarUsuario() {
        String nombre     = frmLogin.txtNombre.getText().trim();
        String email      = frmLogin.txtEmail.getText().trim();
        String contrasena = new String(frmLogin.txtContrasena.getPassword()).trim();
        String generoSel  = (String) frmLogin.cmbGeneroPreferido.getSelectedItem();

        if (nombre.isEmpty() || email.isEmpty() || contrasena.isEmpty()) {
            frmLogin.lblMensaje.setText("Completa todos los campos.");
            return;
        }

        if (sistema.buscarUsuarioPorEmail(email) != null) {
            frmLogin.lblMensaje.setText("Ya existe un usuario con ese email.");
            return;
        }

        Usuario nuevo = new Usuario(nombre, email, contrasena);

        // Agregar preferencia de género seleccionada
        Genero genero = new Genero(generoSel);
        Preferencia pref = new Preferencia(genero);
        nuevo.getPreferencias().add(pref);

        sistema.agregarUsuario(nuevo);
        frmLogin.lblMensaje.setText("");
        JOptionPane.showMessageDialog(frmLogin,"Usuario registrado con éxito. Ahora puedes iniciar sesión.","Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
    }

    private void iniciarSesion() {
        String email = frmLogin.txtEmail.getText().trim();
        String contrasena = new String(frmLogin.txtContrasena.getPassword()).trim();

        if (email.isEmpty() || contrasena.isEmpty()) {
            frmLogin.lblMensaje.setText("Ingresa email y contraseña.");
            return;
        }

        Usuario usuario = sistema.buscarUsuarioPorEmail(email);
        if (usuario == null || !usuario.getContrasena().equals(contrasena)) {
            frmLogin.lblMensaje.setText("Email o contraseña incorrectos.");
            return;
        }

        // Abrir frame principal
        JFPrincipal frmPrincipal = new JFPrincipal();
        new ControladorPrincipal(frmPrincipal, sistema, usuario);
        frmPrincipal.setVisible(true);
        frmLogin.dispose();
    }
}
