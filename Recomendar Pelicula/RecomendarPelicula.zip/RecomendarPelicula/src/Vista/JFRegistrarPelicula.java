package Vista;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * Frame secundario para registrar nuevas películas en el sistema.
 * Diseño con colores coherente con JFPrincipal.
 */
public class JFRegistrarPelicula extends JFrame {

    // Paleta
    private static final Color COLOR_FONDO = new Color(20, 20, 35);
    private static final Color COLOR_PANEL = new Color(30, 30, 50);
    private static final Color COLOR_HEADER = new Color(0, 120, 180);
    private static final Color COLOR_TEXTO = new Color(240, 240, 240);
    private static final Color COLOR_CAMPO = new Color(45, 45, 68);
    private static final Color COLOR_AREA = new Color(15, 15, 28);
    private static final Color COLOR_BTN_GUAR = new Color(0, 153, 80);
    private static final Color COLOR_BTN_LIMP = new Color(180, 140, 0);
    private static final Color COLOR_BTN_CER = new Color(229, 9, 20);

    public JTextField txtTitulo;
    public JTextField txtAutor;
    public JTextField txtAño;
    public JTextField txtDuracion;
    public JComboBox<String> cmbGenero;
    public JButton btnGuardar;
    public JButton btnLimpiar;
    public JButton btnCerrar;
    public JTextArea areaInfo;

    public JFRegistrarPelicula() {
        initComponents();
    }

    private void initComponents() {
        setTitle("CineMatch - Registrar Nueva Película");
        setSize(450, 420);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(COLOR_FONDO);

        // ── Encabezado ───
        JPanel pnlHeader = new JPanel(null);
        pnlHeader.setBounds(0, 0, 450, 50);
        pnlHeader.setBackground(COLOR_HEADER);

        JLabel lblIcono = new JLabel("🎥");
        lblIcono.setFont(new Font("Arial", Font.PLAIN, 22));
        lblIcono.setBounds(10, 10, 34, 30);
        pnlHeader.add(lblIcono);

        JLabel lblTitulo = new JLabel("Registrar Nueva Película");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 15));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setBounds(50, 13, 280, 24);
        pnlHeader.add(lblTitulo);
        add(pnlHeader);

        // ── Panel del formulario ───
        JPanel pnlForm = new JPanel(null);
        pnlForm.setBounds(15, 60, 420, 230);
        pnlForm.setBackground(COLOR_PANEL);
        pnlForm.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(70, 70, 110), 1),
            "Datos de la Película",
            TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 12),
            new Color(200, 200, 255)));

        int y = 22;
        addLabel(pnlForm, "Título:",         10, y);
        txtTitulo = addCampo(pnlForm, 120, y, 285);

        y += 36;
        addLabel(pnlForm, "Director:",       10, y);
        txtAutor = addCampo(pnlForm, 120, y, 285);

        y += 36;
        addLabel(pnlForm, "Año:",             10, y);
        txtAño = addCampo(pnlForm, 120, y, 100);

        addLabel(pnlForm, "Duración (min):", 230, y);
        txtDuracion = addCampo(pnlForm, 350, y, 55);

        y += 36;
        addLabel(pnlForm, "Género:",         10, y);
        cmbGenero   = new JComboBox<>();
        cmbGenero.setBounds(120, y, 185, 27);
        cmbGenero.setBackground(COLOR_CAMPO);
        cmbGenero.setForeground(COLOR_TEXTO);
        cmbGenero.setFont(new Font("Arial", Font.PLAIN, 12));
        pnlForm.add(cmbGenero);

        y += 48;
        btnGuardar = crearBoton("💾 Guardar",  COLOR_BTN_GUAR);
        btnGuardar.setBounds(10, y, 125, 32);
        pnlForm.add(btnGuardar);

        btnLimpiar = crearBoton("🗑 Limpiar",  COLOR_BTN_LIMP);
        btnLimpiar.setBounds(142, y, 125, 32);
        pnlForm.add(btnLimpiar);

        btnCerrar  = crearBoton("✖ Cerrar",   COLOR_BTN_CER);
        btnCerrar.setBounds(274, y, 125, 32);
        pnlForm.add(btnCerrar);

        add(pnlForm);

        // ── Área de info ──
        JLabel lblInfo = new JLabel("Información:");
        lblInfo.setFont(new Font("Arial", Font.BOLD, 12));
        lblInfo.setForeground(new Color(200, 200, 255));
        lblInfo.setBounds(15, 298, 130, 20);
        add(lblInfo);

        areaInfo = new JTextArea();
        areaInfo.setEditable(false);
        areaInfo.setFont(new Font("Monospaced", Font.PLAIN, 11));
        areaInfo.setBackground(COLOR_AREA);
        areaInfo.setForeground(new Color(180, 255, 180));
        areaInfo.setMargin(new Insets(6, 8, 6, 8));
        areaInfo.setLineWrap(true);
        JScrollPane scroll = new JScrollPane(areaInfo);
        scroll.setBounds(15, 320, 420, 72);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 90), 1));
        add(scroll);
    }

    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y + 4, 108, 20);
        lbl.setFont(new Font("Arial", Font.BOLD, 12));
        lbl.setForeground(COLOR_TEXTO);
        panel.add(lbl);
    }

    private JTextField addCampo(JPanel panel, int x, int y, int w) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, w, 27);
        tf.setBackground(COLOR_CAMPO);
        tf.setForeground(COLOR_TEXTO);
        tf.setCaretColor(COLOR_TEXTO);
        tf.setFont(new Font("Arial", Font.PLAIN, 12));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(90, 90, 130), 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)));
        panel.add(tf);
        return tf;
    }

    private JButton crearBoton(String texto, Color bg) {
        JButton btn = new JButton(texto);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
