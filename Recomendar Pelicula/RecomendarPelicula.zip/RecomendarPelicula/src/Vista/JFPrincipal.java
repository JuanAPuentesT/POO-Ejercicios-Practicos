package Vista;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * Frame principal del sistema de recomendación de películas.
 * Diseño oscuro con colores tipo streaming.
 */
public class JFPrincipal extends JFrame {

    // Paleta
    private static final Color COLOR_FONDO = new Color(20, 20, 35);
    private static final Color COLOR_PANEL = new Color(30, 30, 50);
    private static final Color COLOR_HEADER = new Color(229, 9, 20);
    private static final Color COLOR_BARRA = new Color(25, 25, 40);
    private static final Color COLOR_TEXTO = new Color(240, 240, 240);
    private static final Color COLOR_CAMPO = new Color(45, 45, 68);
    private static final Color COLOR_BTN_BUSCAR = new Color(229, 9, 20);
    private static final Color COLOR_BTN_RECOMEN = new Color(255, 160, 0);
    private static final Color COLOR_BTN_HISTORIAL = new Color(0, 153, 80);
    private static final Color COLOR_BTN_CALIFICAR = new Color(100, 80, 200);
    private static final Color COLOR_BTN_NUEVA = new Color(0, 120, 180);
    private static final Color COLOR_BTN_SALIR = new Color(90, 90, 100);
    private static final Color COLOR_AREA = new Color(15, 15, 28);
    private static final Color COLOR_AREA_TEXTO = new Color(200, 255, 200);

    // ── Búsqueda ──────────────────────────────────────────────────────────────
    public JLabel lblBuscar;
    public JTextField txtBuscar;
    public JComboBox<String> cmbTipoBusqueda;
    public JButton btnBuscar;
    public JButton btnRecomendar;
    public JButton btnVerHistorial;
    public JButton btnRegistrarPelicula;
    public JButton btnCalificar;
    public JButton btnSalir;

    // ── Resultados ───
    public JTextArea  areaResultados;
    public JScrollPane scrollResultados;

    // ── Usuario activo ───
    public JLabel lblUsuarioActivo;

    public JFPrincipal() {
        initComponents();
    }

    private void initComponents() {
        setTitle("CineMatch - Sistema de Recomendación de Películas");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(760, 580);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(COLOR_FONDO);

        // ── Encabezado ──
        JPanel pnlHeader = new JPanel(null);
        pnlHeader.setBounds(0, 0, 760, 55);
        pnlHeader.setBackground(COLOR_HEADER);

        JLabel lblIcono = new JLabel("🎬");
        lblIcono.setFont(new Font("Arial", Font.PLAIN, 24));
        lblIcono.setBounds(12, 10, 36, 36);
        pnlHeader.add(lblIcono);

        JLabel lblTitulo = new JLabel("CineMatch  —  Sistema de Recomendación");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 17));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setBounds(54, 14, 420, 26);
        pnlHeader.add(lblTitulo);

        lblUsuarioActivo = new JLabel("Usuario: (ninguno)");
        lblUsuarioActivo.setFont(new Font("Arial", Font.ITALIC, 11));
        lblUsuarioActivo.setForeground(new Color(255, 200, 200));
        lblUsuarioActivo.setBounds(480, 18, 270, 20);
        pnlHeader.add(lblUsuarioActivo);
        add(pnlHeader);

        // ── Barra de búsqueda ───
        JPanel pnlBusqueda = new JPanel(null);
        pnlBusqueda.setBounds(10, 65, 740, 50);
        pnlBusqueda.setBackground(COLOR_BARRA);
        pnlBusqueda.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 90), 1));

        lblBuscar = new JLabel("Buscar:");
        lblBuscar.setBounds(10, 14, 60, 22);
        lblBuscar.setFont(new Font("Arial", Font.BOLD, 12));
        lblBuscar.setForeground(COLOR_TEXTO);
        pnlBusqueda.add(lblBuscar);

        txtBuscar = new JTextField();
        txtBuscar.setBounds(75, 11, 310, 28);
        estilizarCampo(txtBuscar);
        pnlBusqueda.add(txtBuscar);

        cmbTipoBusqueda = new JComboBox<>();
        cmbTipoBusqueda.setBounds(395, 11, 155, 28);
        cmbTipoBusqueda.setBackground(COLOR_CAMPO);
        cmbTipoBusqueda.setForeground(COLOR_TEXTO);
        cmbTipoBusqueda.setFont(new Font("Arial", Font.PLAIN, 12));
        pnlBusqueda.add(cmbTipoBusqueda);

        btnBuscar = crearBoton("🔍 Buscar", COLOR_BTN_BUSCAR);
        btnBuscar.setBounds(560, 11, 165, 28);
        pnlBusqueda.add(btnBuscar);

        add(pnlBusqueda);

        // ── Barra de acciones ──
        JPanel pnlAcciones = new JPanel(null);
        pnlAcciones.setBounds(10, 125, 740, 48);
        pnlAcciones.setBackground(COLOR_FONDO);

        btnRecomendar = crearBoton("⭐ Recomendar", COLOR_BTN_RECOMEN);
        btnRecomendar.setBounds(0, 6, 145, 36);
        pnlAcciones.add(btnRecomendar);

        btnVerHistorial = crearBoton("📋 Historial", COLOR_BTN_HISTORIAL);
        btnVerHistorial.setBounds(152, 6, 138, 36);
        pnlAcciones.add(btnVerHistorial);

        btnCalificar = crearBoton("★ Calificar", COLOR_BTN_CALIFICAR);
        btnCalificar.setBounds(297, 6, 130, 36);
        pnlAcciones.add(btnCalificar);

        btnRegistrarPelicula = crearBoton("➕ Nueva Película", COLOR_BTN_NUEVA);
        btnRegistrarPelicula.setBounds(434, 6, 155, 36);
        pnlAcciones.add(btnRegistrarPelicula);

        btnSalir = crearBoton("⏻ Salir", COLOR_BTN_SALIR);
        btnSalir.setBounds(596, 6, 144, 36);
        pnlAcciones.add(btnSalir);

        add(pnlAcciones);

        // ── Separador y etiqueta de resultados ──
        JLabel lblResultados = new JLabel("Resultados:");
        lblResultados.setFont(new Font("Arial", Font.BOLD, 13));
        lblResultados.setForeground(new Color(255, 200, 0));
        lblResultados.setBounds(15, 176, 150, 22);
        add(lblResultados);

        JSeparator sep = new JSeparator();
        sep.setBounds(10, 200, 740, 2);
        sep.setForeground(new Color(80, 80, 120));
        add(sep);

        // ── Área de resultados ───
        areaResultados = new JTextArea();
        areaResultados.setEditable(false);
        areaResultados.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaResultados.setBackground(COLOR_AREA);
        areaResultados.setForeground(COLOR_AREA_TEXTO);
        areaResultados.setCaretColor(COLOR_TEXTO);
        areaResultados.setMargin(new Insets(8, 10, 8, 10));
        areaResultados.setLineWrap(true);
        areaResultados.setWrapStyleWord(true);

        scrollResultados = new JScrollPane(areaResultados);
        scrollResultados.setBounds(10, 205, 740, 335);
        scrollResultados.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 90), 1));
        scrollResultados.getVerticalScrollBar().setBackground(COLOR_PANEL);
        add(scrollResultados);
    }

    private void estilizarCampo(JTextField tf) {
        tf.setBackground(COLOR_CAMPO);
        tf.setForeground(COLOR_TEXTO);
        tf.setCaretColor(COLOR_TEXTO);
        tf.setFont(new Font("Arial", Font.PLAIN, 12));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(90, 90, 130), 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)));
    }

    private JButton crearBoton(String texto, Color bg) {
        JButton btn = new JButton(texto);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
