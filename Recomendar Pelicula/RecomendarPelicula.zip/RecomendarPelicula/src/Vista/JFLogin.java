package Vista;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * Frame de inicio de sesión y registro de usuarios.
 * Diseño con colores inspirados en plataformas de streaming.
 */
public class JFLogin extends JFrame {

    // Paleta de colores
    private static final Color COLOR_FONDO = new Color(20, 20, 35);
    private static final Color COLOR_PANEL = new Color(30, 30, 50);
    private static final Color COLOR_ACENTO = new Color(229, 9, 20);   // rojo Netflix
    private static final Color COLOR_ACENTO2 = new Color(255, 180, 0);  // dorado
    private static final Color COLOR_TEXTO = new Color(240, 240, 240);
    private static final Color COLOR_CAMPO = new Color(50, 50, 70);
    private static final Color COLOR_BTN_PRIMARIO = new Color(229, 9, 20);
    private static final Color COLOR_BTN_SEC = new Color(60, 60, 90);
    private static final Font  FUENTE_TITULO = new Font("Arial", Font.BOLD, 20);
    private static final Font  FUENTE_LABEL = new Font("Arial", Font.BOLD, 12);
    private static final Font  FUENTE_CAMPO = new Font("Arial", Font.PLAIN, 12);

    public JTextField txtNombre;
    public JTextField txtEmail;
    public JPasswordField txtContrasena;
    public JComboBox<String> cmbGeneroPreferido;
    public JButton btnIniciar;
    public JButton btnRegistrar;
    public JLabel  lblMensaje;

    public JFLogin() {
        initComponents();
    }

    private void initComponents() {
        setTitle("CineMatch - Inicio de Sesión");
        setSize(420, 380);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(COLOR_FONDO);

        // ── Encabezado ───
        JPanel pnlHeader = new JPanel(null);
        pnlHeader.setBounds(0, 0, 420, 60);
        pnlHeader.setBackground(COLOR_ACENTO);

        JLabel lblIcono = new JLabel("🎬");
        lblIcono.setFont(new Font("Arial", Font.PLAIN, 26));
        lblIcono.setBounds(15, 12, 40, 36);
        pnlHeader.add(lblIcono);

        JLabel lblTitulo = new JLabel("CineMatch");
        lblTitulo.setFont(FUENTE_TITULO);
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setBounds(60, 10, 200, 30);
        pnlHeader.add(lblTitulo);

        JLabel lblSub = new JLabel("Sistema de Recomendación de Películas");
        lblSub.setFont(new Font("Arial", Font.PLAIN, 10));
        lblSub.setForeground(new Color(255, 200, 200));
        lblSub.setBounds(60, 38, 280, 16);
        pnlHeader.add(lblSub);
        add(pnlHeader);

        // ── Panel del formulario ───
        JPanel pnlForm = new JPanel(null);
        pnlForm.setBounds(20, 75, 380, 270);
        pnlForm.setBackground(COLOR_PANEL);
        pnlForm.setBorder(BorderFactory.createLineBorder(new Color(70, 70, 100), 1));

        int y = 15;
        addLabel(pnlForm, "Nombre:", 15, y);
        txtNombre    = addCampo(pnlForm, 150, y, 215);

        y += 38;
        addLabel(pnlForm, "Email:", 15, y);
        txtEmail     = addCampo(pnlForm, 150, y, 215);

        y += 38;
        addLabel(pnlForm, "Contraseña:", 15, y);
        txtContrasena = new JPasswordField();
        estilizarCampo(txtContrasena, 150, y, 215, pnlForm);

        y += 38;
        addLabel(pnlForm, "Género preferido:", 15, y);
        cmbGeneroPreferido = new JComboBox<>();
        cmbGeneroPreferido.setBounds(150, y, 215, 27);
        cmbGeneroPreferido.setBackground(COLOR_CAMPO);
        cmbGeneroPreferido.setForeground(COLOR_TEXTO);
        cmbGeneroPreferido.setFont(FUENTE_CAMPO);
        pnlForm.add(cmbGeneroPreferido);

        y += 48;
        btnRegistrar = crearBoton("Registrarse", COLOR_BTN_SEC, 15, y, 168);
        pnlForm.add(btnRegistrar);

        btnIniciar = crearBoton("Iniciar Sesión", COLOR_BTN_PRIMARIO, 193, y, 172);
        pnlForm.add(btnIniciar);

        y += 42;
        lblMensaje = new JLabel("");
        lblMensaje.setForeground(COLOR_ACENTO2);
        lblMensaje.setFont(new Font("Arial", Font.ITALIC, 11));
        lblMensaje.setBounds(15, y, 350, 20);
        pnlForm.add(lblMensaje);

        add(pnlForm);
    }

    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y + 4, 130, 20);
        lbl.setFont(FUENTE_LABEL);
        lbl.setForeground(COLOR_TEXTO);
        panel.add(lbl);
    }

    private JTextField addCampo(JPanel panel, int x, int y, int w) {
        JTextField tf = new JTextField();
        estilizarCampo(tf, x, y, w, panel);
        return tf;
    }

    private void estilizarCampo(JTextField tf, int x, int y, int w, JPanel panel) {
        tf.setBounds(x, y, w, 27);
        tf.setBackground(COLOR_CAMPO);
        tf.setForeground(COLOR_TEXTO);
        tf.setCaretColor(COLOR_TEXTO);
        tf.setFont(FUENTE_CAMPO);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(90, 90, 130), 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)));
        panel.add(tf);
    }

    private JButton crearBoton(String texto, Color bg, int x, int y, int w) {
        JButton btn = new JButton(texto);
        btn.setBounds(x, y, w, 32);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
