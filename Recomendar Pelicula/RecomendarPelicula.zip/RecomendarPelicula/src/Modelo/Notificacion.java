package Modelo;

/**
 * Clase Notificacion - crea mensajes con fecha para el usuario.
 */
public class Notificacion {

    private String mensaje;
    private Fecha fecha;

    public Notificacion() {
    }

    public Notificacion(String mensaje, Fecha fecha) {
        this.mensaje = mensaje;
        this.fecha = fecha;
    }

    /**
     * Devuelve el texto formateado de la notificación.
     */
    public String enviar() {
        return "[" + fecha.toString() + "] " + mensaje;
    }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }

    public Fecha getFecha() { return fecha; }
    public void setFecha(Fecha fecha) { this.fecha = fecha; }
}
