package Modelo;

import java.util.ArrayList;

/**
 * Clase SistemaRecomendacion - núcleo del sistema.
 * Contiene listas de usuarios y películas.
 */
public class SistemaRecomendacion {

    private ArrayList<Usuario> usuarios;
    private ArrayList<Pelicula> peliculas;
    private AlgoritmoRecomendacion algoritmo;

    public SistemaRecomendacion() {
        this.usuarios = new ArrayList<>();
        this.peliculas = new ArrayList<>();
        this.algoritmo = new AlgoritmoRecomendacion();
        cargarPeliculasIniciales();
    }

    /**
     * Carga datos de ejemplo para no empezar vacío.
     */
    private void cargarPeliculasIniciales() {
        peliculas.add(new Pelicula("El Padrino", 175, "Francis Ford Coppola", 1972, "Drama"));
        peliculas.add(new Pelicula("Inception", 148, "Christopher Nolan", 2010, "Ciencia Ficción"));
        peliculas.add(new Pelicula("Interstellar", 169, "Christopher Nolan", 2014, "Ciencia Ficción"));
        peliculas.add(new Pelicula("El Rey León", 88, "Roger Allers", 1994, "Animación"));
        peliculas.add(new Pelicula("Titanic", 195, "James Cameron", 1997, "Romance"));
        peliculas.add(new Pelicula("Avengers: Endgame", 181, "Anthony Russo", 2019, "Acción"));
        peliculas.add(new Pelicula("The Dark Knight", 152, "Christopher Nolan", 2008, "Acción"));
        peliculas.add(new Pelicula("Forrest Gump", 142, "Robert Zemeckis", 1994, "Drama"));
        peliculas.add(new Pelicula("Toy Story", 81, "John Lasseter", 1995, "Animación"));
        peliculas.add(new Pelicula("Matrix", 136, "Wachowski", 1999, "Ciencia Ficción"));
    }

    // ── Búsquedas (delegadas a SistBusqueda via Pelicula) ───

    public ArrayList<Pelicula> BusquedabyTittle(String titulo) {
        Pelicula buscador = new Pelicula();
        return buscador.buscarPorTitulo(peliculas, titulo);
    }

    public ArrayList<Pelicula> BusquedaByGenre(String genero) {
        Pelicula buscador = new Pelicula();
        return buscador.buscarPorGenero(peliculas, genero);
    }

    public ArrayList<Pelicula> BusquedaByAuthor(String autor) {
        Pelicula buscador = new Pelicula();
        return buscador.buscarPorDirector(peliculas, autor);
    }

    // ── Recomendación ──

    public ArrayList<Pelicula> recomendar(Usuario usuario) {
        return algoritmo.GenerarRecomendacion(usuario, peliculas);
    }

    // ── Gestión de usuarios ──

    public void agregarUsuario(Usuario u) { usuarios.add(u); }

    public Usuario buscarUsuarioPorEmail(String email) {
        for (Usuario u : usuarios) {
            if (u.getEmail().equalsIgnoreCase(email)) return u;
        }
        return null;
    }

    // Getters y Setters
    public ArrayList<Usuario> getUsuarios() { return usuarios; }
    public void setUsuarios(ArrayList<Usuario> usuarios) { this.usuarios = usuarios; }

    public ArrayList<Pelicula> getPeliculas() { return peliculas; }
    public void setPeliculas(ArrayList<Pelicula> peliculas) { this.peliculas = peliculas; }
}
