package Modelo;

import java.util.ArrayList;

/**
 * Clase Usuario - tiene historial, preferencias y calificaciones.
 */
public class Usuario {

    private String nombre;
    private String email;
    private String contrasena;

    private ArrayList<HistorialPelicula> historial;
    private ArrayList<Preferencia> preferencias;
    private ArrayList<Calificacion> calificaciones;

    public Usuario() {
        this.historial = new ArrayList<>();
        this.preferencias = new ArrayList<>();
        this.calificaciones = new ArrayList<>();
    }

    public Usuario(String nombre, String email, String contrasena) {
        this.nombre = nombre;
        this.email = email;
        this.contrasena = contrasena;
        this.historial = new ArrayList<>();
        this.preferencias = new ArrayList<>();
        this.calificaciones = new ArrayList<>();
    }

    /**
     * Registra una calificación para una película y la asocia a este usuario.
     */
    public void calificar(Pelicula pelicula, double puntuacion, String comentario) {
        Fecha hoy = obtenerFechaHoy();
        Calificacion c = new Calificacion(puntuacion, comentario, hoy);
        calificaciones.add(c);
        pelicula.agregarCalificacion(c);
    }

    /**
     * Agrega una película al historial del usuario.
     */
    public void verHistorial(Pelicula pelicula, int tiempoVisto) {
        Fecha hoy = obtenerFechaHoy();
        HistorialPelicula entrada = new HistorialPelicula(hoy, tiempoVisto, pelicula);
        historial.add(entrada);
    }

    /**
     * Devuelve una Fecha con la fecha del sistema actual.
     */
    private Fecha obtenerFechaHoy() {
        java.time.LocalDate hoy = java.time.LocalDate.now();
        return new Fecha(hoy.getDayOfMonth(), hoy.getMonthValue(), hoy.getYear());
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public ArrayList<HistorialPelicula> getHistorial() { return historial; }
    public void setHistorial(ArrayList<HistorialPelicula> historial) { this.historial = historial; }

    public ArrayList<Preferencia> getPreferencias() { return preferencias; }
    public void setPreferencias(ArrayList<Preferencia> preferencias) { this.preferencias = preferencias; }

    public ArrayList<Calificacion> getCalificaciones() { return calificaciones; }
    public void setCalificaciones(ArrayList<Calificacion> calificaciones) { this.calificaciones = calificaciones; }

    @Override
    public String toString() {
        return nombre + " <" + email + ">";
    }
}
