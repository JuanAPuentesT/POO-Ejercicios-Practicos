package Modelo;

import java.util.ArrayList;

public class Pelicula extends SistBusqueda {

    private String titulo;
    private int duracion;       // en minutos
    private String autor;       // director
    private int año;
    private double calificacionPromedio;
    private String genero;
    private ArrayList<Genero> generos;
    private ArrayList<Calificacion> calificaciones;

    public Pelicula() {
        this.generos = new ArrayList<>();
        this.calificaciones = new ArrayList<>();
    }

    public Pelicula(String titulo, int duracion, String autor, int año, String genero) {
        this.titulo = titulo;
        this.duracion = duracion;
        this.autor = autor;
        this.año = año;
        this.genero = genero;
        this.calificacionPromedio = 0.0;
        this.generos = new ArrayList<>();
        this.calificaciones = new ArrayList<>();
    }

    /**
     * Recalcula el promedio de calificaciones de esta película.
     */
    public void actualizarPromedio() {
        if (calificaciones.isEmpty()) {
            this.calificacionPromedio = 0.0;
            return;
        }
        double suma = 0;
        for (Calificacion c : calificaciones) {
            suma += c.getPuntuacion();
        }
        this.calificacionPromedio = suma / calificaciones.size();
    }

    public void agregarCalificacion(Calificacion c) {
        calificaciones.add(c);
        actualizarPromedio();
    }

    // Getters y Setters
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public int getDuracion() { return duracion; }
    public void setDuracion(int duracion) { this.duracion = duracion; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public int getAño() { return año; }
    public void setAño(int año) { this.año = año; }

    public double getCalificacionPromedio() { return calificacionPromedio; }
    public void setCalificacionPromedio(double calificacionPromedio) { this.calificacionPromedio = calificacionPromedio; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public ArrayList<Genero> getGeneros() { return generos; }
    public void setGeneros(ArrayList<Genero> generos) { this.generos = generos; }

    public ArrayList<Calificacion> getCalificaciones() { return calificaciones; }
    public void setCalificaciones(ArrayList<Calificacion> calificaciones) { this.calificaciones = calificaciones; }

    @Override
    public String toString() {
        return titulo + " (" + año + ") - " + autor;
    }
}
