package Modelo;

import java.util.ArrayList;

public class SistBusqueda {

    /**
     * Busca películas por título en la lista dada.
     */
    public ArrayList<Pelicula> buscarPorTitulo(ArrayList<Pelicula> lista, String titulo) {
        ArrayList<Pelicula> resultado = new ArrayList<>();
        for (Pelicula p : lista) {
            if (p.getTitulo().toLowerCase().contains(titulo.toLowerCase())) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    /**
     * Busca películas por género en la lista dada.
     */
    public ArrayList<Pelicula> buscarPorGenero(ArrayList<Pelicula> lista, String genero) {
        ArrayList<Pelicula> resultado = new ArrayList<>();
        for (Pelicula p : lista) {
            if (p.getGenero().toLowerCase().contains(genero.toLowerCase())) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    /**
     * Busca películas por director/autor en la lista dada.
     */
    public ArrayList<Pelicula> buscarPorDirector(ArrayList<Pelicula> lista, String director) {
        ArrayList<Pelicula> resultado = new ArrayList<>();
        for (Pelicula p : lista) {
            if (p.getAutor().toLowerCase().contains(director.toLowerCase())) {
                resultado.add(p);
            }
        }
        return resultado;
    }
}
