package Modelo;

import java.util.ArrayList;

/**
 * Clase AlgoritmoRecomendacion - genera recomendaciones personalizadas.
 */
public class AlgoritmoRecomendacion {

    /**
     * Genera una lista de películas recomendadas para un usuario
     * basándose en sus preferencias de género y excluyendo las ya vistas.
     */
    public ArrayList<Pelicula> GenerarRecomendacion(Usuario usuario, ArrayList<Pelicula> todasLasPeliculas) {
        ArrayList<Pelicula> recomendadas = new ArrayList<>();

        // Obtener géneros preferidos del usuario
        ArrayList<String> generosPreferidos = new ArrayList<>();
        for (Preferencia pref : usuario.getPreferencias()) {
            if (pref.getGeneroPreferido() != null) {
                generosPreferidos.add(pref.getGeneroPreferido().getNombre().toLowerCase());
            }
        }

        // Obtener títulos ya vistos por el usuario
        ArrayList<String> yaVistas = new ArrayList<>();
        for (HistorialPelicula h : usuario.getHistorial()) {
            yaVistas.add(h.getPelicula().getTitulo());
        }

        // Si el usuario no tiene preferencias, recomienda por calificación promedio
        if (generosPreferidos.isEmpty()) {
            for (Pelicula p : todasLasPeliculas) {
                if (!yaVistas.contains(p.getTitulo()) && p.getCalificacionPromedio() >= 4.0) {
                    recomendadas.add(p);
                }
            }
        } else {
            // Recomienda películas que coincidan con géneros preferidos y no estén vistas
            for (Pelicula p : todasLasPeliculas) {
                if (!yaVistas.contains(p.getTitulo())
                        && generosPreferidos.contains(p.getGenero().toLowerCase())) {
                    recomendadas.add(p);
                }
            }
        }

        return recomendadas;
    }
}
